import Finite

/-! Replay sign brackets found by a separate integer search. -/

namespace A056777Bounded

-- Every index is less than 2^18. A zero upper field represents a negative peak.
def signCertificate (p q data : ℕ) : Bool :=
  let L := sumCoeff p q
  let M := pairCoeff p q
  let C := productCoeff p q
  let a : ℤ := (data % 262144 : ℕ)
  let high := data / 262144
  decide (6*(p:ℤ) ≤ L) &&
    if high = 0 then
      decide (a+1 ≤ p ∧ cubic L M C a < 0 ∧
        0 ≤ slope L M (a-1) a ∧ slope L M a (a+1) ≤ 0)
    else
      let b : ℤ := high
      decide (a+1 ≤ b ∧ b+1 ≤ p ∧ cubic L M C a < 0 ∧ 0 < cubic L M C (a+1) ∧
        0 < cubic L M C b ∧ cubic L M C (b+1) < 0)

theorem signCertificate_sound {p q x data : ℕ} (hc : signCertificate p q data = true)
    (hx : x ≤ p) : cubic (sumCoeff p q) (pairCoeff p q) (productCoeff p q) x ≠ 0 := by
  unfold signCertificate at hc
  simp only [Bool.and_eq_true, decide_eq_true_eq] at hc
  obtain ⟨hL,hc⟩ := hc
  have hxp : (x:ℤ) ≤ (p:ℤ) := by exact_mod_cast hx
  split at hc
  next _ =>
    simp only [decide_eq_true_eq] at hc
    exact no_root_below_peak hL hc.1 hxp hc.2.1 hc.2.2.1 hc.2.2.2
  next _ =>
    simp only [decide_eq_true_eq] at hc
    exact no_root_between hL hc.1 hc.2.1 hxp hc.2.2.1 hc.2.2.2.1 hc.2.2.2.2.1 hc.2.2.2.2.2

def candidateP (q p : ℕ) : Bool :=
  decide (2*q < p ∧ p*p < q^3 ∧ p%3 ≠ q%3) && possiblePrime p

def candidateList (q low count : ℕ) : List ℕ :=
  ((List.range count).flatMap fun i =>
    [20*(low+i)+3,20*(low+i)+7]).filter (candidateP q)

def checkList (q : ℕ) : List ℕ → List ℕ → Bool
  | [], [] => true
  | p::ps, data::rest => signCertificate p q data && checkList q ps rest
  | _, _ => false

theorem checkList_sound {q p : ℕ} {ps data : List ℕ} (h : checkList q ps data = true)
    (hp : p ∈ ps) : ∃ d, signCertificate p q d = true := by
  induction ps generalizing data with
  | nil => simp at hp
  | cons a as ih =>
    cases data with
    | nil => simp [checkList] at h
    | cons d ds =>
      simp only [checkList,Bool.and_eq_true] at h
      rcases List.mem_cons.mp hp with rfl | hpas
      · exact ⟨d,h.1⟩
      · exact ih h.2 hpas

theorem candidateP_mem {p q lo c : ℕ} (hp : p.Prime)
    (hpLo : 2*q < p) (hpHi : p^2 < q^3) (hmod : p%3 ≠ q%3) (hmod20 : p%20=3 ∨ p%20=7)
    (hlo : lo ≤ p/20) (hhi : p/20 < lo+c) : p ∈ candidateList q lo c := by
  unfold candidateList
  apply List.mem_filter.mpr
  constructor
  · apply List.mem_flatMap.mpr
    refine ⟨p/20-lo, List.mem_range.mpr (by omega), ?_⟩
    obtain h3|h7 := hmod20
    · have he : 20*(lo+(p/20-lo))+3=p := by omega
      simp [he]
    · have he : 20*(lo+(p/20-lo))+7=p := by omega
      simp [he]
  · unfold candidateP
    simp only [Bool.and_eq_true]
    exact ⟨decide_eq_true ⟨hpLo,by simpa only [pow_two] using hpHi,hmod⟩,
      prime_possiblePrime hp⟩

theorem bounded_of_signCertificates
    (checks : ∀ p q : ℕ, p.Prime → q.Prime → q<4000 → q%8=3 → q%5=2 →
      p%4=3 → (p%5=2 ∨ p%5=3) → 2*q<p → p^2<q^3 → p%3≠q%3 →
      ∃ d, signCertificate p q d = true) :
    OMA.R_OeisA56777_comesFromPrimeQuadruple_of_a_R2_H2_R1_H2_R1.H1 := by
  intro p q x hp hq _ hp4 hq8 _ hpLo hmod hpHi hp5 hq5 hqMax _ _ hx _
  dsimp only
  intro _ hrec _
  obtain ⟨d,hd⟩ := checks p q hp hq hqMax hq8 hq5 hp4 hp5 hpLo hpHi hmod
  apply signCertificate_sound hd (le_of_lt hx)
  simp only [cubic, pairCoeff, sumCoeff, productCoeff]
  linear_combination -hrec

end A056777Bounded
