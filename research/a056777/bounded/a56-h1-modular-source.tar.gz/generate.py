"""Generate integer sign brackets. Lean rechecks the brackets and candidate coverage."""
from math import isqrt
from pathlib import Path
import sys

root = Path(__file__).resolve().parent
sieve_divisors = (2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61)
base = 262144

def passes_sieve(n):
    return all(n <= d or n % d != 0 for d in sieve_divisors)

def bisect_boundary(predicate, lower, upper):
    while lower < upper:
        middle = (lower + upper) // 2
        if predicate(middle):
            lower = middle + 1
        else:
            upper = middle
    return lower

def make_certificate(p, q):
    L = (p*p + p + 1) * (q + 1) + 2*p**3
    M = 2*p**3 * (p + q - 1) + L - 2
    C = 2 * (p**4*q + 12)
    def cubic(x):
        return ((2*x - L)*x + M)*x - C
    def slope(x):
        return (6*x + 6 - 2*L)*x + 2 - L + M
    assert 6*p <= L
    peak = bisect_boundary(lambda x: slope(x) > 0, q, p - 1)
    if cubic(peak) < 0:
        assert peak + 1 <= p
        assert slope(peak - 1) >= 0 and slope(peak) <= 0
        assert 0 <= peak < base
        return peak
    left = bisect_boundary(lambda x: cubic(x) < 0, q, peak) - 1
    right = bisect_boundary(lambda x: cubic(x) > 0, peak, p - 1) - 1
    assert left + 1 <= right and right + 1 <= p
    assert cubic(left) < 0 < cubic(left + 1)
    assert cubic(right + 1) < 0 < cubic(right)
    assert 0 <= left < base and 0 < right < base
    return left + base*right

def certificates(q, start, count):
    for j in range(start, start + count):
        for p in (20*j + 3, 20*j + 7):
            if 2*q < p and p*p < q**3 and p % 3 != q % 3 and passes_sieve(p):
                yield make_certificate(p, q)

def module_for(index, chunk_size):
    q = 40*index + 27
    assert passes_sieve(q)
    count = isqrt(q**3)//20 + 1
    chunks = [(start, min(chunk_size, count-start)) for start in range(0, count, chunk_size)]
    out = ["import Witness", "", "namespace A056777Bounded", "",
           "set_option maxRecDepth 30000", "set_option maxHeartbeats 0", ""]
    for n, (start, size) in enumerate(chunks):
        data = list(certificates(q, start, size))
        text = ",\n  ".join(", ".join(map(str, data[i:i+14])) for i in range(0, len(data), 14))
        out += [f"private def signData{n} : List ℕ := [{text}]",
                f"private theorem replay{n} : checkList {q} (candidateList {q} {start} {size}) "
                f"signData{n} = true := by decide +kernel", ""]
    out += [
        f"theorem checked{index:02d} {{p : ℕ}} (hp : p.Prime) (hlo : 2*{q} < p)",
        f"    (hhi : p^2 < {q}^3) (hmod : p%3 ≠ {q}%3) (hres : p%20=3 ∨ p%20=7) :",
        f"    ∃ d, signCertificate p {q} d = true := by",
        f"  have hs : p*p ≤ {q}^3 := by simpa only [pow_two] using le_of_lt hhi",
        f"  have hpBound := Nat.le_sqrt.mpr hs",
        f"  have hb : p/20 < {count} := by",
        f"    have hc : ({q}^3 : ℕ).sqrt = {isqrt(q**3)} := by decide +kernel",
        f"    rw [hc] at hpBound",
        f"    omega",
    ]
    if len(chunks)>1:
        out += [f"  set j := p/20/{chunk_size} with hj",
                f"  have jBound : j < {len(chunks)} := by omega",
                "  interval_cases j"]
        for n, _ in enumerate(chunks):
            out.append(f"  · exact checkList_sound replay{n} "
                       f"(candidateP_mem hp hlo hhi hmod hres (by omega) (by omega))")
    else:
        out.append("  exact checkList_sound replay0 "
                   "(candidateP_mem hp hlo hhi hmod hres (by omega) (by omega))")
    out += ["", "end A056777Bounded", ""]
    (root / f"Cert{index:02d}.lean").write_text("\n".join(out))

def generate_main():
    indices = [i for i in range(100) if passes_sieve(40*i + 27)]
    out = [f"import Cert{i:02d}" for i in indices]
    out += ["", "namespace A056777Bounded", "",
            f"private def validIndices : List ℕ := {indices}", "",
            "private theorem checkedIndices : (List.range 100).all",
            "    (fun i => !possiblePrime (qFromIndex i) || validIndices.contains i) = true := by",
            "  decide +kernel", "",
            "private theorem index_mem {i : ℕ} (hi : i<100) (hq : (qFromIndex i).Prime) :",
            "    i ∈ validIndices := by",
            "  have h := List.all_eq_true.mp checkedIndices i (List.mem_range.mpr hi)",
            "  have hs := prime_possiblePrime hq",
            "  simpa [hs] using h", "",
            "private theorem check_for_index {p i : ℕ} (hp : p.Prime) (hi : i<100)",
            "    (hq : (qFromIndex i).Prime) (hlo : 2*qFromIndex i<p)",
            "    (hhi : p^2<(qFromIndex i)^3) (hmod : p%3≠qFromIndex i%3)",
            "    (hres : p%20=3 ∨ p%20=7) :",
            "    ∃ d, signCertificate p (qFromIndex i) d = true := by",
            "  have hvalid := index_mem hi hq",
            "  simp only [validIndices, List.mem_cons, List.not_mem_nil, or_false] at hvalid",
            "  rcases hvalid with " + " | ".join("rfl" for _ in indices)]
    out += [f"  · exact checked{i:02d} hp hlo hhi hmod hres" for i in indices]
    out += ["",
            "theorem bounded : OMA.R_OeisA56777_comesFromPrimeQuadruple_of_a_R2_H2_R1_H2_R1.H1 := by",
            "  apply bounded_of_signCertificates",
            "  intro p q hp hq hqBound hq8 hq5 hp4 hp5 hlo hhi hmod",
            "  have hqValue := q_index_eq hq8 hq5",
            "  have hi : q/40 < 100 := by omega",
            "  have hqPrime : (qFromIndex (q/40)).Prime := by rwa [hqValue]",
            "  have hlo' : 2*qFromIndex (q/40)<p := by rwa [hqValue]",
            "  have hhi' : p^2<(qFromIndex (q/40))^3 := by rwa [hqValue]",
            "  have hmod' : p%3≠qFromIndex (q/40)%3 := by rwa [hqValue]",
            "  have h := check_for_index hp hi hqPrime hlo' hhi' hmod' (p_mod_twenty hp4 hp5)",
            "  rwa [hqValue] at h",
            "", "#print axioms bounded", "", "end A056777Bounded", ""]
    (root / "Bounded.lean").write_text("\n".join(out))

if __name__ == "__main__":
    if len(sys.argv) > 1:
        module_for(int(sys.argv[1]), int(sys.argv[2]) if len(sys.argv) > 2 else 256)
    else:
        for i in range(100):
            if passes_sieve(40*i + 27):
                module_for(i, 256)
    generate_main()
