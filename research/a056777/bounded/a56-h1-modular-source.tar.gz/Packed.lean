import Witness

/-! The packed fields are only search hints. Lean checks the decoded signs. -/

namespace A056777Bounded

def expandSign (p q field : ℕ) : ℕ :=
  let lower := q + field % 4096
  let upperOffset := field / 4096
  let upper := if upperOffset = 0 then 0 else p-upperOffset
  lower + 262144*upper

def checkPacked (q : ℕ) : List ℕ → ℕ → Bool
  | [], data => decide (data = 0)
  | p::ps, data =>
    signCertificate p q (expandSign p q (data % 16777216)) &&
      checkPacked q ps (data / 16777216)

theorem checkPacked_sound {q p : ℕ} {ps : List ℕ} {data : ℕ}
    (h : checkPacked q ps data = true) (hp : p ∈ ps) :
    ∃ d, signCertificate p q d = true := by
  induction ps generalizing data with
  | nil => simp at hp
  | cons a as ih =>
    simp only [checkPacked,Bool.and_eq_true] at h
    rcases List.mem_cons.mp hp with rfl | hpas
    · exact ⟨_,h.1⟩
    · exact ih h.2 hpas

end A056777Bounded
