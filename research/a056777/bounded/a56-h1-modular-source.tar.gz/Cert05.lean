import Witness

namespace A056777Bounded

set_option maxRecDepth 30000
set_option maxHeartbeats 0

private def signData0 : List ℕ := [277, 289, 308, 320, 114295049, 126091521, 151257334, 168558834, 178520304, 195035374, 201588973, 218104043, 243794154, 250347753,
  260047081, 308019431, 314310887, 340000998, 346292454, 355729638, 371720421, 378011877, 393740517, 403439845, 419168485, 425459941, 435159269, 457179364,
  488898788, 514064612, 529793252, 545784036, 567804132, 583532772, 592969956, 614990052, 624689380, 662438115, 671875299, 678166755, 693895395, 703332579,
  725352675, 772800739, 797966563, 804258019, 835715299, 845152483]
private theorem replay0 : checkList 227 (candidateList 227 0 172) signData0 = true := by decide +kernel

theorem checked05 {p : ℕ} (hp : p.Prime) (hlo : 2*227 < p)
    (hhi : p^2 < 227^3) (hmod : p%3 ≠ 227%3) (hres : p%20=3 ∨ p%20=7) :
    ∃ d, signCertificate p 227 d = true := by
  have hs : p*p ≤ 227^3 := by simpa only [pow_two] using le_of_lt hhi
  have hpBound := Nat.le_sqrt.mpr hs
  have hb : p/20 < 172 := by
    have hc : (227^3 : ℕ).sqrt = 3420 := by decide +kernel
    rw [hc] at hpBound
    omega
  exact checkList_sound replay0 (candidateP_mem hp hlo hhi hmod hres (by omega) (by omega))

end A056777Bounded
