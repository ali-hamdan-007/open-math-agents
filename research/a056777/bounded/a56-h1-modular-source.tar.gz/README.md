# Kernel certificate for the bounded A056777 prime-root divisor case

The target is H1 of the prime-root divisor reduction #6850. That child has
`q < 4000`. The certificate proves a stronger statement on the indexed
prime candidates: the associated cubic has no integral root at or below
`p`. It therefore does not need the lower spacing bounds on the prime root
or the additional polynomial divisor test in H1.

## Why the integer certificate works

Write the cubic as `F(x) = 2x^3 - Lx^2 + Mx - C` with the given
coefficients. Its secant factor is
`S(x,y) = 2(x^2+xy+y^2) - L(x+y) + M`, so that
`F(y)-F(x)=(y-x)S(x,y)`. Under the separately verified inequality
`6p ≤ L`, `S` is decreasing in both coordinates on coordinates ≤ `p`.

The records have one of two shapes. A negative peak gives an integer
`a` with `F(a)<0`, left secant nonnegative, and right secant
nonpositive. The whole interval is then negative. Otherwise the record
gives four consecutive-bracket signs
`F(a)<0<F(a+1)` and `F(b)>0>F(b+1)` with `a+1≤b<p`.
The secant ordering makes values outside the bracket negative and
values in the closed middle interval positive. Every integer is covered.

The Lean indexing proves that every prime `q` can occur only at a
certified index `q=40i+27`, and every candidate prime `p` occurs in a
certified `p/20` chunk. A short small-factor sieve is sound for primes.
The checker recomputes eligible candidate rows, replays each sign record,
and rejects an incomplete row list. It therefore does not trust Python to
enumerate primes, find signs, or cover the input range.

## Rebuild

1. Run `python generate.py` to reproduce the ordinary separated Lean
   certificate modules.
2. Run `./replay.sh` to build those modules and audit `Bounded.bounded`.
   The default runs two processes. Use `REPLAY_JOBS=1` on a low-memory
   executor. An interrupted run reuses successfully compiled modules.
3. Run `python pack.py` to create the single-file OMA proof. It stores
   `a-q` and either zero (negative peak) or `p-b` in two 12-bit fields.
   Lean independently replays the decoded brackets. The standalone proof
   is under the 512 KiB limit and was tested with project lint.

The full generic proof and actual sign replays use only `decide +kernel`.
The optional exploratory Python search outside this directory is not a
Lean dependency. No Lean native axiom is used.

The scripts assume the pinned Lean 4.33.1 toolchain and the exact parent
module from the parallel verification workspace. The exported standalone
proof uses only the official parent import. Its replay is CPU-bound.
The largest separated `q` module took about 82 seconds on this executor.
