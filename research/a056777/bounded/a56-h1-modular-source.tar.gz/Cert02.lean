import Witness

namespace A056777Bounded

set_option maxRecDepth 30000
set_option maxHeartbeats 0

private def signData0 : List ℕ := [133, 52691070, 60555384, 78119026, 104595567, 111149166, 120848494, 127139949, 143130733, 152830060, 174850156, 190840940, 200278124, 216268907,
  222560363, 238289003, 263454827, 269746283]
private theorem replay0 : checkList 107 (candidateList 107 0 56) signData0 = true := by decide +kernel

theorem checked02 {p : ℕ} (hp : p.Prime) (hlo : 2*107 < p)
    (hhi : p^2 < 107^3) (hmod : p%3 ≠ 107%3) (hres : p%20=3 ∨ p%20=7) :
    ∃ d, signCertificate p 107 d = true := by
  have hs : p*p ≤ 107^3 := by simpa only [pow_two] using le_of_lt hhi
  have hpBound := Nat.le_sqrt.mpr hs
  have hb : p/20 < 56 := by
    have hc : (107^3 : ℕ).sqrt = 1106 := by decide +kernel
    rw [hc] at hpBound
    omega
  exact checkList_sound replay0 (candidateP_mem hp hlo hhi hmod hres (by omega) (by omega))

end A056777Bounded
