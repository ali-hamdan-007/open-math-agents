import Cert01
import Cert02
import Cert05
import Cert07
import Cert08
import Cert11
import Cert13
import Cert14
import Cert19
import Cert20
import Cert22
import Cert23
import Cert29
import Cert32
import Cert35
import Cert40
import Cert41
import Cert43
import Cert44
import Cert46
import Cert47
import Cert49
import Cert50
import Cert56
import Cert58
import Cert61
import Cert67
import Cert76
import Cert79
import Cert82
import Cert83
import Cert86
import Cert88
import Cert97
import Cert98

namespace A056777Bounded

private def validIndices : List ℕ := [1, 2, 5, 7, 8, 11, 13, 14, 19, 20, 22, 23, 29, 32, 35, 40, 41, 43, 44, 46, 47, 49, 50, 56, 58, 61, 67, 76, 79, 82, 83, 86, 88, 97, 98]

private theorem checkedIndices : (List.range 100).all
    (fun i => !possiblePrime (qFromIndex i) || validIndices.contains i) = true := by
  decide +kernel

private theorem index_mem {i : ℕ} (hi : i<100) (hq : (qFromIndex i).Prime) :
    i ∈ validIndices := by
  have h := List.all_eq_true.mp checkedIndices i (List.mem_range.mpr hi)
  have hs := prime_possiblePrime hq
  simpa [hs] using h

private theorem check_for_index {p i : ℕ} (hp : p.Prime) (hi : i<100)
    (hq : (qFromIndex i).Prime) (hlo : 2*qFromIndex i<p)
    (hhi : p^2<(qFromIndex i)^3) (hmod : p%3≠qFromIndex i%3)
    (hres : p%20=3 ∨ p%20=7) :
    ∃ d, signCertificate p (qFromIndex i) d = true := by
  have hvalid := index_mem hi hq
  simp only [validIndices, List.mem_cons, List.not_mem_nil, or_false] at hvalid
  rcases hvalid with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact checked01 hp hlo hhi hmod hres
  · exact checked02 hp hlo hhi hmod hres
  · exact checked05 hp hlo hhi hmod hres
  · exact checked07 hp hlo hhi hmod hres
  · exact checked08 hp hlo hhi hmod hres
  · exact checked11 hp hlo hhi hmod hres
  · exact checked13 hp hlo hhi hmod hres
  · exact checked14 hp hlo hhi hmod hres
  · exact checked19 hp hlo hhi hmod hres
  · exact checked20 hp hlo hhi hmod hres
  · exact checked22 hp hlo hhi hmod hres
  · exact checked23 hp hlo hhi hmod hres
  · exact checked29 hp hlo hhi hmod hres
  · exact checked32 hp hlo hhi hmod hres
  · exact checked35 hp hlo hhi hmod hres
  · exact checked40 hp hlo hhi hmod hres
  · exact checked41 hp hlo hhi hmod hres
  · exact checked43 hp hlo hhi hmod hres
  · exact checked44 hp hlo hhi hmod hres
  · exact checked46 hp hlo hhi hmod hres
  · exact checked47 hp hlo hhi hmod hres
  · exact checked49 hp hlo hhi hmod hres
  · exact checked50 hp hlo hhi hmod hres
  · exact checked56 hp hlo hhi hmod hres
  · exact checked58 hp hlo hhi hmod hres
  · exact checked61 hp hlo hhi hmod hres
  · exact checked67 hp hlo hhi hmod hres
  · exact checked76 hp hlo hhi hmod hres
  · exact checked79 hp hlo hhi hmod hres
  · exact checked82 hp hlo hhi hmod hres
  · exact checked83 hp hlo hhi hmod hres
  · exact checked86 hp hlo hhi hmod hres
  · exact checked88 hp hlo hhi hmod hres
  · exact checked97 hp hlo hhi hmod hres
  · exact checked98 hp hlo hhi hmod hres

theorem bounded : OMA.R_OeisA56777_comesFromPrimeQuadruple_of_a_R2_H2_R1_H2_R1.H1 := by
  apply bounded_of_signCertificates
  intro p q hp hq hqBound hq8 hq5 hp4 hp5 hlo hhi hmod
  have hqValue := q_index_eq hq8 hq5
  have hi : q/40 < 100 := by omega
  have hqPrime : (qFromIndex (q/40)).Prime := by rwa [hqValue]
  have hlo' : 2*qFromIndex (q/40)<p := by rwa [hqValue]
  have hhi' : p^2<(qFromIndex (q/40))^3 := by rwa [hqValue]
  have hmod' : p%3≠qFromIndex (q/40)%3 := by rwa [hqValue]
  have h := check_for_index hp hi hqPrime hlo' hhi' hmod' (p_mod_twenty hp4 hp5)
  rwa [hqValue] at h

#print axioms bounded

end A056777Bounded
