#!/usr/bin/env bash
set -eu
cd "$(dirname "$0")"
for name in Bracket Finite Witness; do
  if [[ ! "$name.olean" -nt "$name.lean" ]]; then
    ./check.sh -j1 -DwarningAsError=true -o "$name.olean" "$name.lean"
  fi
done

REPLAY_JOBS="${REPLAY_JOBS:-2}"
mkdir -p logs
for file in Cert*.lean; do
  stem=$(basename "$file" .lean)
  if [[ ! "$stem.olean" -nt "$file" ]]; then
    printf '%s\n' "$stem"
  fi
done | sort -r | xargs -r -P "$REPLAY_JOBS" -n 1 bash -c '
  stem="$1"
  start=$SECONDS
  echo "Checking $stem"
  if ./check.sh -j1 -DwarningAsError=true -o "$stem.olean" "$stem.lean" >"logs/$stem.log" 2>&1; then
    echo "Passed $stem in $((SECONDS-start))s"
  else
    cat "logs/$stem.log"
    exit 1
  fi
' _
./check.sh -j1 -DwarningAsError=true -o Bounded.olean Bounded.lean
