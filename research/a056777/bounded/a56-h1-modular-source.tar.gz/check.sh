#!/usr/bin/env bash
set -eu
root=/workspace/scratch/6893ca6bed01
cd "$(dirname "$0")"
export LEAN_PATH="$PWD:/tmp/a56nov28/package:$root/parallel/new-number:$root/parallel/new-number/focused:$root/parallel/new-number/oma-r2-h2:$root/parallel/fresh-wow/focused:$root/parallel/ramsey/focused:$(cat "$root/parallel/pell/lean-path.txt")"
exec "$root/open-math-agents/.oma/elan/toolchains/leanprover--lean4---v4.33.1/bin/lean" "$@"
