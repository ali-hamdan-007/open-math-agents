import OMAReductions.R_OeisA56777_comesFromPrimeQuadruple_of_a_R2_H2_R1_H2_R1

/-! A certificate for nonvanishing of the A056777 cubic at every integer in an interval. -/

namespace A056777Bounded

def cubic (L M C x : ℤ) : ℤ := ((2*x-L)*x+M)*x-C

def slope (L M x y : ℤ) : ℤ := 2*(x*x+x*y+y*y)-L*(x+y)+M

theorem cubic_diff (L M C x y : ℤ) :
    cubic L M C y - cubic L M C x = (y-x)*slope L M x y := by
  unfold cubic slope
  ring

theorem slope_antitone {L M P u v u' v' : ℤ}
    (hL : 6*P ≤ L) (hu : u ≤ u') (hv : v ≤ v') (hu' : u' ≤ P) (hv' : v' ≤ P) :
    slope L M u' v' ≤ slope L M u v := by
  have h₁ := mul_nonpos_of_nonneg_of_nonpos (sub_nonneg.mpr hu)
    (show 2*(u'+u+v)-L ≤ 0 by linarith)
  have h₂ := mul_nonpos_of_nonneg_of_nonpos (sub_nonneg.mpr hv)
    (show 2*(u'+v'+v)-L ≤ 0 by linarith)
  unfold slope
  nlinarith only [h₁,h₂]

theorem no_root_between {L M C P a b x : ℤ} (hL : 6*P ≤ L) (hab : a+1 ≤ b)
    (hb : b+1 ≤ P) (hx : x ≤ P)
    (hfa : cubic L M C a < 0) (hfa' : 0 < cubic L M C (a+1))
    (hfb : 0 < cubic L M C b) (hfb' : cubic L M C (b+1) < 0) :
    cubic L M C x ≠ 0 := by
  have ha' : a+1 ≤ P := by omega
  have hbp : b ≤ P := by omega
  have leftSlope : 0 ≤ slope L M a (a+1) := by linarith [cubic_diff L M C a (a+1)]
  have rightSlope : slope L M b (b+1) ≤ 0 := by linarith [cubic_diff L M C b (b+1)]
  by_cases hxa : x ≤ a
  · have h := slope_antitone (M:=M) hL hxa (show a ≤ a+1 by omega) (by omega) ha'
    have hmul := mul_nonneg (show 0 ≤ a-x by omega) (leftSlope.trans h)
    linarith [cubic_diff L M C x a]
  by_cases hxb : b+1 ≤ x
  · have h := slope_antitone (M:=M) hL (show b ≤ b+1 by omega) hxb hb hx
    have hmul := mul_nonpos_of_nonneg_of_nonpos (show 0 ≤ x-(b+1) by omega) (h.trans rightSlope)
    linarith [cubic_diff L M C (b+1) x]
  have hax : a+1 ≤ x := by omega
  have hxb' : x ≤ b := by omega
  by_cases hsign : 0 ≤ slope L M (a+1) x
  · have hmul := mul_nonneg (show 0 ≤ x-(a+1) by omega) hsign
    linarith [cubic_diff L M C (a+1) x]
  · have h := slope_antitone (M:=M) hL hax hxb' hx hbp
    have hmul := mul_nonpos_of_nonneg_of_nonpos (show 0 ≤ b-x by omega)
      (h.trans (le_of_lt (lt_of_not_ge hsign)))
    linarith [cubic_diff L M C x b]

theorem no_root_below_peak {L M C P a x : ℤ} (hL : 6*P ≤ L)
    (ha : a+1 ≤ P) (hx : x ≤ P)
    (hfa : cubic L M C a < 0) (hleft : 0 ≤ slope L M (a-1) a)
    (hright : slope L M a (a+1) ≤ 0) : cubic L M C x ≠ 0 := by
  obtain hxa|rfl|hax := lt_trichotomy x a
  · have h := slope_antitone (M:=M) hL (show x ≤ a-1 by omega) (le_refl a)
        (by omega) (by omega)
    have hmul := mul_nonneg (show 0 ≤ a-x by omega) (hleft.trans h)
    linarith [cubic_diff L M C x a]
  · exact ne_of_lt hfa
  · have h := slope_antitone (M:=M) hL (le_refl a) (show a+1 ≤ x by omega) (by omega) hx
    have hmul := mul_nonpos_of_nonneg_of_nonpos (show 0 ≤ x-a by omega) (h.trans hright)
    linarith [cubic_diff L M C a x]

def boundary (condition : ℕ → Bool) : ℕ → ℕ → ℕ → ℕ
  | 0, low, _ => low
  | fuel+1, low, high =>
    if low < high then
      let middle := (low+high)/2
      if condition middle then boundary condition fuel (middle+1) high
      else boundary condition fuel low middle
    else low

def sumCoeff (p q : ℤ) : ℤ := (p*p+p+1)*(q+1)+2*p^3

def pairCoeff (p q : ℤ) : ℤ := 2*p^3*(p+q-1)+sumCoeff p q-2

def productCoeff (p q : ℤ) : ℤ := 2*(p^4*q+12)

def cubicCheck (p q : ℕ) : Bool :=
  let L := sumCoeff p q
  let M := pairCoeff p q
  let C := productCoeff p q
  let f (x : ℕ) := cubic L M C x
  let peak := boundary (fun i => decide (0 < slope L M i ((i:ℤ)+1))) 19 q (p-1)
  decide (6*(p:ℤ) ≤ L) &&
    if f peak < 0 then
      decide ((peak:ℤ)+1 ≤ p ∧
        0 ≤ slope L M ((peak:ℤ)-1) peak ∧ slope L M peak ((peak:ℤ)+1) ≤ 0)
    else
      let left := boundary (fun i => decide (f i < 0)) 19 q peak
      let right := boundary (fun i => decide (0 < f i)) 19 peak (p-1)
      let a : ℤ := (left:ℤ)-1
      let b : ℤ := (right:ℤ)-1
      decide (a+1 ≤ b ∧ b+1 ≤ p ∧ cubic L M C a < 0 ∧ 0 < cubic L M C (a+1) ∧
        0 < cubic L M C b ∧ cubic L M C (b+1) < 0)

theorem cubicCheck_sound {p q x : ℕ} (hc : cubicCheck p q = true) (hx : x ≤ p) :
    cubic (sumCoeff p q) (pairCoeff p q) (productCoeff p q) x ≠ 0 := by
  unfold cubicCheck at hc
  simp only [Bool.and_eq_true, decide_eq_true_eq] at hc
  obtain ⟨hL,hc⟩ := hc
  have hxp : (x:ℤ) ≤ (p:ℤ) := by exact_mod_cast hx
  split at hc
  next h =>
    simp only [decide_eq_true_eq] at hc
    exact no_root_below_peak hL hc.1 hxp h hc.2.1 hc.2.2
  next _ =>
    simp only [decide_eq_true_eq] at hc
    exact no_root_between hL hc.1 hc.2.1 hxp hc.2.2.1 hc.2.2.2.1 hc.2.2.2.2.1 hc.2.2.2.2.2

end A056777Bounded
