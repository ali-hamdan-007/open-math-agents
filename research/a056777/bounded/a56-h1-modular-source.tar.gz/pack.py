"""Pack each sign bracket into two 12-bit offsets and emit the exact standalone proof."""
from pathlib import Path
from math import isqrt
import re
import sys

from generate import make_certificate, passes_sieve

root = Path(__file__).resolve().parent
step = 256
indices = [i for i in range(100) if passes_sieve(40*i + 27)]

def pack(q, start, size):
    encoded = 0
    count = 0
    for j in range(start, start + size):
        for p in (20*j + 3,20*j + 7):
            if not (2*q < p and p*p < q**3 and p%3 != q%3 and passes_sieve(p)):
                continue
            raw = make_certificate(p,q)
            a,b = raw%262144,raw//262144
            field1 = a-q
            field2 = p-b if b else 0
            assert 0 <= field1 < 4096 and 0 <= field2 < 4096
            encoded |= (field1 + 4096*field2) << (24*count)
            count += 1
    return f"0x{encoded:x}" if encoded else "0"

def transform(i):
    q = 40*i + 27
    path = root / f"Cert{i:02d}.lean"
    text = path.read_text().replace("import Witness","import Packed")
    pattern = (r"private def signData(\d+) : List ℕ := \[.*?\]\n"
               r"private theorem replay\1 : checkList (\d+) \(candidateList \2 (\d+) (\d+)\) "
               r"signData\1 = true := by decide \+kernel")
    def replacement(match):
        index,q_matched,start,size = map(int,match.groups())
        assert q==q_matched
        packed = pack(q,start,size)
        return (
            "set_option maxRecDepth 30000 in\nset_option maxHeartbeats 0 in\n"
            f"private theorem replay{index} : checkPacked {q} "
            f"(candidateList {q} {start} {size})\n  {packed} = true := by decide +kernel")
    text = re.sub(pattern,replacement,text,flags=re.S)
    text = text.replace("checkList_sound replay","checkPacked_sound replay")
    (root / f"PackedCert{i:02d}.lean").write_text(text)
    return text

def body(source):
    start = source.index("namespace A056777Bounded") + len("namespace A056777Bounded")
    end = source.rindex("end A056777Bounded")
    text = source[start:end].strip()
    return "\n".join(
        line for line in text.splitlines()
        if not line.startswith(("#print ", "set_option maxHeartbeats 0\n"))
    ).strip()

def source(name):
    return body((root/name).read_text())

if len(sys.argv)>1:
    transform(int(sys.argv[1]))
    sys.exit()

all_modules = [(i,transform(i)) for i in indices]
bundle = root / "OeisA56777.comesFromPrimeQuadruple_of_a.R2.H2.R1.H2.R1.H1.lean"
pieces = [
"""import OMAReductions.R_OeisA56777_comesFromPrimeQuadruple_of_a_R2_H2_R1_H2_R1

/-! Bounded prime-root divisor case. The stored integer brackets and coverage are
replayed by Lean's kernel. -/

namespace A056777Bounded
""",
source("Bracket.lean").split("def boundary")[0] +
"def sumCoeff" + source("Bracket.lean").split("def sumCoeff",1)[1].split("def cubicCheck")[0],
source("Finite.lean").split("def pCheck")[0] +
"def qFromIndex" + source("Finite.lean").split("def qFromIndex",1)[1].split("def pRows",1)[0] +
"theorem q_index_eq" + source("Finite.lean").split("theorem q_index_eq",1)[1],
re.sub(r"def checkList .*?(?=theorem candidateP_mem)","",source("Witness.lean"),flags=re.S),
source("Packed.lean")
]
for i,text in all_modules:
    compact = re.sub(r'\b(replay)(\d+)\b',rf'\g<1>{i}_\g<2>',body(text))
    compact=compact.replace("set_option maxRecDepth 30000\n", "").replace("set_option maxHeartbeats 0\n", "")
    compact=compact.replace("theorem checked", "set_option maxHeartbeats 0 in\ntheorem checked")
    pieces.append(compact)
pieces += [source("Bounded.lean"),
"""
end A056777Bounded

theorem OMA.solution : OMA.R_OeisA56777_comesFromPrimeQuadruple_of_a_R2_H2_R1_H2_R1.H1 :=
  A056777Bounded.bounded
"""]
bundle.write_text("\n\n".join(pieces))
print(bundle.name, bundle.stat().st_size)
