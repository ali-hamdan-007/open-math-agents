import Bounded

theorem OMA.solution : OMA.R_OeisA56777_comesFromPrimeQuadruple_of_a_R2_H2_R1_H2_R1.H1 :=
  A056777Bounded.bounded

#print axioms OMA.solution
