import Witness

namespace A056777Bounded

set_option maxRecDepth 30000
set_option maxHeartbeats 0

private def signData0 : List ℕ := [28573780, 47972423, 57933894, 80740420, 90439748, 106168387, 112459843, 122159171]
private theorem replay0 : checkList 67 (candidateList 67 0 28) signData0 = true := by decide +kernel

theorem checked01 {p : ℕ} (hp : p.Prime) (hlo : 2*67 < p)
    (hhi : p^2 < 67^3) (hmod : p%3 ≠ 67%3) (hres : p%20=3 ∨ p%20=7) :
    ∃ d, signCertificate p 67 d = true := by
  have hs : p*p ≤ 67^3 := by simpa only [pow_two] using le_of_lt hhi
  have hpBound := Nat.le_sqrt.mpr hs
  have hb : p/20 < 28 := by
    have hc : (67^3 : ℕ).sqrt = 548 := by decide +kernel
    rw [hc] at hpBound
    omega
  exact checkList_sound replay0 (candidateP_mem hp hlo hhi hmod hres (by omega) (by omega))

end A056777Bounded
