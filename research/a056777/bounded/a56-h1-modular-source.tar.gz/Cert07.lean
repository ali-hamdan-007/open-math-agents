import Witness

namespace A056777Bounded

set_option maxRecDepth 30000
set_option maxHeartbeats 0

private def signData0 : List ℕ := [385, 404, 117440932, 156762469, 168558941, 176161113, 194249041, 204734797, 238813510, 255328579, 261882178, 271843649, 288096575, 294650175,
  310903101, 327156028, 343146811, 352846139, 368836922, 375390522, 391381305, 423362872, 432800056, 439091512, 455082295, 480510263, 486801719, 496501047,
  502792503, 534511926, 543949110, 550240566, 591397173, 597950773, 623116597, 654836021, 661127477, 702284085, 718012724, 724304180, 733741364, 749470004,
  765460788, 787480884, 796918068, 828375348, 834666804, 850395444, 866386228, 882114868, 907280692, 945029428, 954466612, 970457396, 986186036, 992477492,
  1008206131, 1039663411, 1080557875, 1128005939, 1143734579, 1150026035, 1159463219, 1175191859, 1190920499, 1212940595, 1253835059, 1260126515, 1269563699, 1291583795]
private theorem replay0 : checkList 307 (candidateList 307 0 256) signData0 = true := by decide +kernel

private def signData1 : List ℕ := [1307312435, 1317011763, 1348469043]
private theorem replay1 : checkList 307 (candidateList 307 256 13) signData1 = true := by decide +kernel

theorem checked07 {p : ℕ} (hp : p.Prime) (hlo : 2*307 < p)
    (hhi : p^2 < 307^3) (hmod : p%3 ≠ 307%3) (hres : p%20=3 ∨ p%20=7) :
    ∃ d, signCertificate p 307 d = true := by
  have hs : p*p ≤ 307^3 := by simpa only [pow_two] using le_of_lt hhi
  have hpBound := Nat.le_sqrt.mpr hs
  have hb : p/20 < 269 := by
    have hc : (307^3 : ℕ).sqrt = 5379 := by decide +kernel
    rw [hc] at hpBound
    omega
  set j := p/20/256 with hj
  have jBound : j < 2 := by omega
  interval_cases j
  · exact checkList_sound replay0 (candidateP_mem hp hlo hhi hmod hres (by omega) (by omega))
  · exact checkList_sound replay1 (candidateP_mem hp hlo hhi hmod hres (by omega) (by omega))

end A056777Bounded
