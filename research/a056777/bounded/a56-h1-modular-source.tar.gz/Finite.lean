import Bracket

/-! The indexing and small-factor sieve for the bounded cubic certificates. -/

namespace A056777Bounded

/-- Filtering multiples of these constants reduces the kernel replay cost.
Soundness only needs every constant to be greater than one. -/
def divisors : List ℕ :=
  [2,3,5,7,11,13,17,19,23,29,31,37,41,43,47,53,59,61]

def possiblePrime (p : ℕ) : Bool :=
  divisors.all fun d => decide (p ≤ d ∨ p % d ≠ 0)

theorem prime_possiblePrime {p : ℕ} (hp : p.Prime) : possiblePrime p = true := by
  apply List.all_eq_true.mpr
  intro d hd
  have h1 : 1 < d := by
    change d ∈ divisors at hd
    unfold divisors at hd
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hd
    omega
  apply decide_eq_true
  by_contra! h
  have hdvd : d ∣ p := Nat.dvd_iff_mod_eq_zero.mpr h.2
  rcases hp.eq_one_or_self_of_dvd d hdvd with hbad|hbad <;> omega

def pCheck (q p : ℕ) : Bool :=
  if 2*q < p ∧ p*p < q^3 ∧ p%3 ≠ q%3 ∧ possiblePrime p = true
  then cubicCheck p q
  else true

def qFromIndex (i : ℕ) : ℕ := 40*i+27

def pRows (q : ℕ) : ℕ := (q^3).sqrt/20+1

def qCheck (i : ℕ) : Bool :=
  let q := qFromIndex i
  if possiblePrime q then
    (List.range (pRows q)).all fun j =>
      pCheck q (20*j+3) && pCheck q (20*j+7)
  else true

theorem extract_cubicCheck {i p : ℕ} (hi : qCheck i = true)
    (hq : (qFromIndex i).Prime) (hp : p.Prime) (hpLo : 2*qFromIndex i < p)
    (hpHi : p^2 < (qFromIndex i)^3) (hmod : p%3 ≠ (qFromIndex i)%3)
    (hp20 : p%20=3 ∨ p%20=7) : cubicCheck p (qFromIndex i) = true := by
  let q := qFromIndex i
  have hpHiSq : p*p < q^3 := by simpa only [pow_two] using hpHi
  have hpRoot : p ≤ (q^3).sqrt := Nat.le_sqrt.mpr (le_of_lt hpHiSq)
  have hpIndex : p/20 ∈ List.range (pRows q) := by
    apply List.mem_range.mpr
    unfold pRows
    omega
  have h := prime_possiblePrime hq
  unfold qCheck at hi
  simp only [h, if_true] at hi
  have hrow := List.all_eq_true.mp hi _ hpIndex
  simp only [Bool.and_eq_true] at hrow
  obtain ⟨hleft,hright⟩ := hrow
  obtain h3|h7 := hp20
  · have he : 20*(p/20)+3=p := by omega
    rw [he] at hleft
    have hconds : 2*q<p ∧ p*p<q^3 ∧ p%3≠q%3 ∧ possiblePrime p = true :=
      ⟨hpLo,hpHiSq,hmod,prime_possiblePrime hp⟩
    simpa [pCheck,hconds,q] using hleft
  · have he : 20*(p/20)+7=p := by omega
    rw [he] at hright
    have hconds : 2*q<p ∧ p*p<q^3 ∧ p%3≠q%3 ∧ possiblePrime p = true :=
      ⟨hpLo,hpHiSq,hmod,prime_possiblePrime hp⟩
    simpa [pCheck,hconds,q] using hright

theorem q_index_eq {q : ℕ} (h8 : q%8=3) (h5 : q%5=2) :
    qFromIndex (q/40)=q := by
  have hmod8 : (q%40)%8=q%8 := Nat.mod_mod_of_dvd q (by decide)
  have hmod5 : (q%40)%5=q%5 := Nat.mod_mod_of_dvd q (by decide)
  unfold qFromIndex
  omega

theorem p_mod_twenty {p : ℕ} (h4 : p%4=3) (h5 : p%5=2 ∨ p%5=3) :
    p%20=3 ∨ p%20=7 := by
  have hmod4 : (p%20)%4=p%4 := Nat.mod_mod_of_dvd p (by decide)
  have hmod5 : (p%20)%5=p%5 := Nat.mod_mod_of_dvd p (by decide)
  omega

end A056777Bounded
