# All adjacent ascending R2-H3 fibers of W(3,13)

The normalized ascending heights $(h,h+1,h,h+1)$ satisfy the R2-H3 sign and normalization tests exactly when $0 ≤ h ≤ 5$. The four ray points, in increasing order, are $13h$, $13h+2$, $13h+14$, and $13h+16$.

Two width-145 windows close the four remaining normalized cases:

| Start in the window | Shifts used on 160 points | Normalized heights | Search nodes | Fragments |
| ---: | --- | --- | ---: | ---: |
| 0 | 0, 13 | 0, 1 | 177,442 | 1,217 |
| 24 | 2, 15 | 2, 3 | 57,035 | 382 |

The earlier width-147 window provides heights 4 and 5. The complete range theorem covers 92 starts of the ascending four-red shape: $[0,15] ∪ [24,39] ∪ [52,65] ∪ [78,91] ∪ [104,119] ∪ [128,143]$. Reflection gives the six raw unnormalized ray fits as well.

The main theorem `OMA.GreenR2Ascending.r2_h3_ascending_heights_complete` rules out every raw height $0 ≤ h ≤ 11$ under the precise R2-H3 ray, no-red-triple, and shorter-step hitting premises. This settles the six normalized members of this family. The other R2-H3 tuples and the full upper bound remain outside the claim.

## Build

Use Lean 4.33.1. Preserve the layout relative to `parallel/ramsey`: `Green160NearWitness.lean`, the four earlier `r2ascending` Lean modules, `r2ascending/window.tail`, and this directory.

```sh
r2ascending/full145/verify_full.sh
```

Set `LEAN_BIN` if the executable is outside `PATH`. The script builds into a temporary directory. Set `JOBS=1` for strictly sequential kernel verification. The default permits two workers. The source DAG uses a single width-145 checker, with each tape module limited to around 52 KiB. All tape fragments use `decide +kernel`. The final theorem audit is in `final-audit.log`.

To regenerate the DAG, use the same local solver with a raised node count cap:

```sh
sed 's/++calls>=100000/++calls>=800000/' search160.cpp > /tmp/w313-ascending.cpp
g++ -std=c++17 -O3 /tmp/w313-ascending.cpp -o /tmp/w313-ascending
python3 r2ascending/full145/generate.py /tmp/w313-ascending
```

The generator splits the checked instruction programs by dependency depth and writes explicit imports for all proof references. The latest relevant R2 reduction is PR [#4300](https://github.com/GuillaumeBAUD-coder/open-math-agents/pull/4300). The newer PRs #5141 and #5179 address R1 central-gap reductions.
