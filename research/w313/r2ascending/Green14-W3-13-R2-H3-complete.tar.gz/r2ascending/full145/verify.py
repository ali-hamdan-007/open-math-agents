"""Build the Lean certificate DAG, with at most two concurrent workers."""
from argparse import ArgumentParser
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait
import json
import os
from pathlib import Path
import subprocess
from time import monotonic

work = Path(__file__).resolve().parent
ramsey = work.parent.parent
parser = ArgumentParser(description=__doc__)
parser.add_argument("--build", type=Path, default=ramsey / "focused")
parser.add_argument("--lean", type=Path, default=ramsey / "lean-focus.sh")
parser.add_argument("--jobs", type=int, choices=(1, 2), default=2)
args = parser.parse_args()
output = args.build.resolve()
output.mkdir(parents=True, exist_ok=True)
lean = args.lean.resolve()
env = dict(os.environ)
env["LEAN_PATH"] = str(output) + (":" + env["LEAN_PATH"] if env.get("LEAN_PATH") else "")

graph = json.loads((work / "dag.json").read_text())
done = set()
todo = set(graph)
active = {}


def compile_module(name):
    start = monotonic()
    result = subprocess.run([str(lean), "-o", str(output / (name + ".olean")), name + ".lean"],
                            cwd=work, env=env, capture_output=True, text=True)
    return name, monotonic() - start, result


with ThreadPoolExecutor(max_workers=args.jobs) as executor:
    while todo or active:
        ready = sorted((node for node in todo if all(dep in done for dep in graph[node])),
                       key=lambda node: (node.startswith("Green145Ascending24"), node))
        for name in ready[:args.jobs - len(active)]:
            todo.remove(name)
            active[executor.submit(compile_module, name)] = name
        if not active:
            raise ValueError(f"Cyclic or incomplete dependencies: {sorted(todo)}")
        completed, _ = wait(active, return_when=FIRST_COMPLETED)
        for f in completed:
            active.pop(f)
            name, elapsed, result = f.result()
            print(f"{name} ({elapsed:.1f}s) exit {result.returncode}", flush=True)
            if result.stdout:
                print(result.stdout.strip(), flush=True)
            if result.stderr:
                print(result.stderr.strip(), flush=True)
            result.check_returncode()
            done.add(name)
