#!/usr/bin/env bash
set -euo pipefail
work=$(cd "$(dirname "$0")" && pwd)
ramsey=$(cd "$work/../.." && pwd)
build=$(mktemp -d)
trap 'rm -rf "$build"' EXIT
export LEAN_PATH="$build${LEAN_PATH:+:$LEAN_PATH}"
lean_bin=$(realpath "$(command -v "${LEAN_BIN:-lean}")")
"$lean_bin" --version
cd "$ramsey"
"$lean_bin" -o "$build/Green160NearWitness.olean" Green160NearWitness.lean
for module in Green147WindowCore Green147Window52 GreenR2Premises GreenR2Ascending; do
    "$lean_bin" -o "$build/$module.olean" "r2ascending/$module.lean"
done
python3 "$work/verify.py" --build "$build" --lean "$lean_bin" --jobs "${JOBS:-2}"
"$lean_bin" -o "$build/GreenR2AscendingFull.olean" r2ascending/full145/GreenR2AscendingFull.lean
