#!/usr/bin/env bash
set -euo pipefail
work=$(cd "$(dirname "$0")" && pwd)
ramsey=$(cd "$work/../.." && pwd)
output=$(realpath -m "${1:-Green14-W3-13-R2-H3-complete.tar.gz}")
cd "$ramsey"
files=(
    Green160NearWitness.lean search160.cpp
    r2ascending/Green147WindowCore.lean r2ascending/Green147Window52.lean
    r2ascending/GreenR2Premises.lean r2ascending/GreenR2Ascending.lean
    r2ascending/{window.tail,README.md,verify.sh,make_window.py,probe.py,probe.log,search.log,lean.log,premises-audit.log,final-audit.log}
    r2ascending/full145/*.lean
    r2ascending/full145/{README.md,dag.json,generate.py,verify.py,verify_full.sh,package.sh}
    r2ascending/full145/{search-0.log,search-24.log,lean.log,final-audit.log}
)
tar --sort=name --mtime=@0 --owner=0 --group=0 --numeric-owner -cf - "${files[@]}" |
    gzip -n > "$output"
printf '%s\n' "$output"
