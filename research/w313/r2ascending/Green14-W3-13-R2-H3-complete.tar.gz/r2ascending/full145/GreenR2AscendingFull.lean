import Green145Ascending0
import Green145Ascending24
import GreenR2Ascending

namespace OMA.GreenR2Ascending

open OMA.Green160NearWitness (Mono)

private theorem use_window (r : Nat → Bool) (a w : Nat)
    (lo : w ≤ a) (hi : a ≤ w+15)
    (window : ∀ s ≤ 15, (∀ x ∈ points w, r (s+x) = false) → Mono r)
    (red : RedShape r a) : Mono r := by
  apply window (a-w) (by omega)
  intro x hx
  have hx' : x = w ∨ x = w+2 ∨ x = w+14 ∨ x = w+16 := by simpa [points] using hx
  rcases hx' with hx' | hx' | hx' | hx' <;> rw [hx']
  · rw [show a-w+w = a by omega]
    exact red _ (by simp [points])
  · rw [show a-w+(w+2) = a+2 by omega]
    exact red _ (by simp [points])
  · rw [show a-w+(w+14) = a+14 by omega]
    exact red _ (by simp [points])
  · rw [show a-w+(w+16) = a+16 by omega]
    exact red _ (by simp [points])

private theorem forward145 (r : Nat → Bool) (a : Nat)
    (h : a ≤ 15 ∨ (24 ≤ a ∧ a ≤ 39)) (red : RedShape r a) : Mono r := by
  rcases h with h | h
  · exact use_window r a 0 (by omega) h
      (OMA.Green145AscendingCore.Seed0.shifted_forces_progression r) red
  · exact use_window r a 24 h.1 h.2
      (OMA.Green145AscendingCore.Seed24.shifted_forces_progression r) red

private theorem reflected_shape (r : Nat → Bool) (a : Nat) (ha : a ≤ 143)
    (red : RedShape r a) : RedShape (fun x => r (159-x)) (143-a) := by
  intro x hx
  have hx' : x = 143-a ∨ x = 143-a+2 ∨ x = 143-a+14 ∨ x = 143-a+16 := by
    simpa [points] using hx
  rcases hx' with rfl | rfl | rfl | rfl <;> dsimp only
  · rw [show 159-(143-a) = a+16 by omega]
    exact red _ (by simp [points])
  · rw [show 159-(143-a+2) = a+14 by omega]
    exact red _ (by simp [points])
  · rw [show 159-(143-a+14) = a+2 by omega]
    exact red _ (by simp [points])
  · rw [show 159-(143-a+16) = a by omega]
    exact red _ (by simp [points])

/-- The checked windows and their reflected copies cover 92 starts of the
ascending four-red shape. -/
theorem forces_of_ascending_start_complete (r : Nat → Bool) (a : Nat)
    (covered : a ≤ 15 ∨ (24 ≤ a ∧ a ≤ 39) ∨ (52 ≤ a ∧ a ≤ 65) ∨
      (78 ≤ a ∧ a ≤ 91) ∨ (104 ≤ a ∧ a ≤ 119) ∨ (128 ≤ a ∧ a ≤ 143))
    (red : RedShape r a) : Mono r := by
  rcases covered with h | h | h | h | h | h
  · exact forward145 r a (Or.inl h) red
  · exact forward145 r a (Or.inr h) red
  · exact forces_of_ascending_start r a (Or.inl h) red
  · exact forces_of_ascending_start r a (Or.inr h) red
  · exact OMA.Green160NearWitness.reflect_progression r
      (forward145 _ (143-a) (Or.inr ⟨by omega, by omega⟩)
        (reflected_shape r a (by omega) red))
  · exact OMA.Green160NearWitness.reflect_progression r
      (forward145 _ (143-a) (Or.inl (by omega))
        (reflected_shape r a (by omega) red))

private theorem covered_at_heights (h : Nat) (hh : h ≤ 11) :
    13*h ≤ 15 ∨ (24 ≤ 13*h ∧ 13*h ≤ 39) ∨ (52 ≤ 13*h ∧ 13*h ≤ 65) ∨
      (78 ≤ 13*h ∧ 13*h ≤ 91) ∨ (104 ≤ 13*h ∧ 13*h ≤ 119) ∨
      (128 ≤ 13*h ∧ 13*h ≤ 143) := by
  by_cases h1 : h ≤ 1
  · exact Or.inl (by omega)
  by_cases h3 : h ≤ 3
  · exact Or.inr (Or.inl ⟨by omega, by omega⟩)
  by_cases h5 : h ≤ 5
  · exact Or.inr (Or.inr (Or.inl ⟨by omega, by omega⟩))
  by_cases h7 : h ≤ 7
  · exact Or.inr (Or.inr (Or.inr (Or.inl ⟨by omega, by omega⟩)))
  by_cases h9 : h ≤ 9
  · exact Or.inr (Or.inr (Or.inr (Or.inr (Or.inl ⟨by omega, by omega⟩))))
  exact Or.inr (Or.inr (Or.inr (Or.inr (Or.inr ⟨by omega, by omega⟩))))

/-- The conclusion of R2-H3 for every raw adjacent ascending tuple
(h,h+1,h,h+1). The normalized members are exactly h = 0 through 5. -/
theorem r2_h3_ascending_heights_complete (R : Nat → Prop) [DecidablePred R] (h : Nat)
    (hhi : h ≤ 11)
    (noTriple : ∀ x y z, R x → R y → R z → x+z = 2*y → x = z)
    (hit : ∀ a d : Nat, 0 < d → d ≤ 12 → a+12*d < 160 →
      ∃ t : Fin 13, R (a+t.val*d))
    (ri : R (13*h)) (rj : R (13*(h+1)+1))
    (rk : R (13*h+2)) (rl : R (13*(h+1)+3)) : False := by
  let u : Fin 13 := ⟨h, by omega⟩
  let v : Fin 13 := ⟨h+1, by omega⟩
  apply OMA.GreenR2Premises.impossible_of_mono R u v u v noTriple hit
  · intro x hx
    have hx' : x = 13*h ∨ x = 13*(h+1)+1 ∨ x = 13*h+2 ∨ x = 13*(h+1)+3 := by
      simpa [OMA.GreenR2Premises.rayPoints, u, v] using hx
    rcases hx' with rfl | rfl | rfl | rfl
    · exact ri
    · exact rj
    · exact rk
    · exact rl
  · apply forces_of_ascending_start_complete _ (13*h) (covered_at_heights h hhi)
    intro x hx
    have hx' : x = 13*h ∨ x = 13*h+2 ∨ x = 13*h+14 ∨ x = 13*h+16 := by
      simpa [points] using hx
    rcases hx' with rfl | rfl | rfl | rfl
    · simpa using ri
    · simpa using rk
    · simpa [Nat.mul_add, Nat.add_assoc] using rj
    · simpa [Nat.mul_add, Nat.add_assoc] using rl

end OMA.GreenR2Ascending

#print axioms OMA.GreenR2Ascending.forces_of_ascending_start_complete
#print axioms OMA.GreenR2Ascending.normalized_ascending_iff
#print axioms OMA.GreenR2Ascending.r2_h3_ascending_heights_complete
