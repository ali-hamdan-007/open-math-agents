# W(3,13) ascending R2, gap-two alternating heights

In the ascending branch of merged PR [#4300](https://github.com/GuillaumeBAUD-coder/open-math-agents/pull/4300), this checkpoint treats ray heights $(h,h+2,h,h+2)$. The four red points, indexed from zero, are $13h + \{0,2,27,29\}$. The local certificates for width 145 start at 0, 26 and 52. Shifts by 0 and 13 cover normalized heights 0 through 5. Reflection in the 160-point interval replaces $h$ by $10-h$, giving the full raw range $0 \le h \le 10$.

| Local start | Search nodes | Lean fragments | DAG layers | DAG modules |
| ---: | ---: | ---: | ---: | ---: |
| 0 | 119,469 | 807 | 13 | 21 |
| 26 | 24,716 | 166 | 10 | 11 |
| 52 | 15,986 | 107 | 8 | 8 |

The final entry is `GapTwoVerified.lean`. Its theorem `OMA.GreenR2GapTwo.gap_two` rules out the shape for the original R2 premises. Its theorem `OMA.GreenR2GapTwo.h3_of_wider_and_nonalternating` reduces the literal ascending H3 statement to the two residual obligations in `RemainderBridge.lean`. There are 4,924 normalized H3 tuples, with six each in the previously checked gap-one family and this gap-two family. The residual counts are 30 wider alternating tuples and 4,882 nonalternating tuples. See `count_cases.py` to reproduce the counts.

## Build and regeneration

Run `./finish.sh` from this bundle on the original workspace. It uses the pinned Lean 4.33.1 and the existing workspace modules in `parallel/ramsey/focused`. Prerequisites are the cached `Green145AscendingCore`, `Green160NearWitness`, `GreenR2Premises` and `GreenR2AscendingFull` and all their imports. Source for the prior adjacent result and the checker is in `parallel/ramsey/r2ascending/full145`. The build compiles the three certificates in the dependency order in `dag.json`, followed by the geometry, exact-statement bridge and final entry. Each generated fragment uses kernel reduction via `decide +kernel`. The final entry prints both theorems' axiom dependencies. The builder can resume from previously checked modules.

The generated sources are included, so reproducing the build does not require the C++ search. To regenerate them, run `g++ -std=c++17 -O3 -o search500 search500.cpp` and `python generate_gap2.py ./search500`. The generator reads the unchanged Lean window proof template at `parallel/ramsey/r2ascending/window.tail`. The search cap is 500,000 nodes per start. The solver logs are measurements of the search that produced the sources.
