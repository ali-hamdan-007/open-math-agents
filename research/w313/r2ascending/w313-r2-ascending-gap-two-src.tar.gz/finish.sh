#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
root=/workspace/scratch/6893ca6bed01
export LEAN_PATH="$PWD:$root/parallel/ramsey/focused:$(cat "$root/parallel/pell/lean-path.txt")"
LEAN="$root/open-math-agents/.oma/elan/toolchains/leanprover--lean4---v4.33.1/bin/lean"
./build.sh
for m in GapTwoGeometry RemainderBridge GapTwoVerified; do
    "$LEAN" -o "$m.olean" "$m.lean" | tee "$m.log"
    test -f "$m.olean"
done
