"""Count normalized tuples of ascending R2.H3 by the remaining proof obligations."""
from collections import Counter
from itertools import product

counts = Counter()
for i, j, k, l in product(range(13), repeat=4):
    if not (i+k < 2*j and 2*k < j+l):
        continue
    if not (i+l < 12 or (i+l == 12 and j+k <= 12)):
        continue
    if i != k or j != l:
        counts['nonalternating'] += 1
    elif j-i == 1:
        counts['gap_one'] += 1
    elif j-i == 2:
        counts['gap_two'] += 1
    else:
        counts['wider'] += 1

for category, count in sorted(counts.items()):
    print(category, count)
print('total', sum(counts.values()))
