import RemainderBridge
import Green145GapTwo0
import Green145GapTwo26
import Green145GapTwo52

namespace OMA.GreenR2GapTwo

private theorem window0 : Window 0 :=
  OMA.Green145AscendingCore.GapTwo0.shifted_forces_progression

private theorem window26 : Window 26 :=
  OMA.Green145AscendingCore.GapTwo26.shifted_forces_progression

private theorem window52 : Window 52 :=
  OMA.Green145AscendingCore.GapTwo52.shifted_forces_progression

/-- Gap-two alternating heights are impossible throughout the 160-point interval. -/
theorem gap_two (R : Nat → Prop) [DecidablePred R] (h : Nat) (hh : h ≤ 10)
    (noTriple : ∀ x y z, R x → R y → R z → x+z=2*y → x=z)
    (hit : ∀ a d : Nat, 0<d → d≤12 → a+12*d<160 → ∃ t : Fin 13, R (a+t.val*d))
    (ri : R (13*h)) (rj : R (13*(h+2)+1))
    (rk : R (13*h+2)) (rl : R (13*(h+2)+3)) : False :=
  impossible window0 window26 window52 R h hh noTriple hit ri rj rk rl

/-- The remaining branches of the exact H3 after excluding gaps one and two. -/
theorem h3_of_wider_and_nonalternating (wide : Wider) (nonAlt : Nonalternating) :
    ExpectedH3 :=
  exact_h3_split window0 window26 window52 wide nonAlt

end OMA.GreenR2GapTwo

#print axioms OMA.GreenR2GapTwo.gap_two
#print axioms OMA.GreenR2GapTwo.h3_of_wider_and_nonalternating
