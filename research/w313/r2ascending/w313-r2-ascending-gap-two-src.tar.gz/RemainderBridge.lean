import Mathlib.Data.Finset.Basic
import GreenR2AscendingFull
import GapTwoGeometry

namespace OMA.GreenR2GapTwo

/-- The exact statement of H3 in the merged R2 reduction (#4300). -/
def ExpectedH3 : Prop :=
  ∀ (R : Finset ℕ) (i j k l : Fin 13),
    (∀ x ∈ R, ∀ y ∈ R, ∀ z ∈ R, x + z = 2*y → x = z) →
    (∀ a d : ℕ, 0 < d → d ≤ 12 → a + 12*d < 160 →
      ∃ t : Fin 13, a + t.val*d ∈ R) →
    13*i.val ∈ R → 13*j.val + 1 ∈ R → 13*k.val + 2 ∈ R → 13*l.val + 3 ∈ R →
    i.val + k.val < 2*j.val → 2*k.val < j.val + l.val →
    (i.val + l.val < 12 ∨ (i.val + l.val = 12 ∧ j.val + k.val ≤ 12)) → False

/-- Wider alternating heights, with gap at least three. -/
def Wider : Prop :=
  ∀ (R : Finset ℕ) (i j : Fin 13),
    (∀ x ∈ R, ∀ y ∈ R, ∀ z ∈ R, x + z = 2*y → x = z) →
    (∀ a d : ℕ, 0 < d → d ≤ 12 → a + 12*d < 160 →
      ∃ t : Fin 13, a + t.val*d ∈ R) →
    13*i.val ∈ R → 13*j.val + 1 ∈ R → 13*i.val + 2 ∈ R → 13*j.val + 3 ∈ R →
    i.val + 2 < j.val → i.val + j.val ≤ 12 → False

/-- All height patterns for which at least one opposing pair differs. -/
def Nonalternating : Prop :=
  ∀ (R : Finset ℕ) (i j k l : Fin 13),
    (∀ x ∈ R, ∀ y ∈ R, ∀ z ∈ R, x + z = 2*y → x = z) →
    (∀ a d : ℕ, 0 < d → d ≤ 12 → a + 12*d < 160 →
      ∃ t : Fin 13, a + t.val*d ∈ R) →
    13*i.val ∈ R → 13*j.val + 1 ∈ R → 13*k.val + 2 ∈ R → 13*l.val + 3 ∈ R →
    i.val + k.val < 2*j.val → 2*k.val < j.val + l.val →
    (i.val + l.val < 12 ∨ (i.val + l.val = 12 ∧ j.val + k.val ≤ 12)) →
    (i ≠ k ∨ j ≠ l) → False

theorem exact_h3_split (w0 : Window 0) (w26 : Window 26) (w52 : Window 52)
    (wide : Wider) (nonAlt : Nonalternating) : ExpectedH3 := by
  intro R i j k l hno hhit hi hj hk hl hsign1 hsign2 hnorm
  by_cases hAlt : i=k ∧ j=l
  · obtain ⟨rfl,rfl⟩ := hAlt
    have hgap : i.val < j.val := by omega
    have hn : i.val+j.val ≤ 12 := by omega
    by_cases hwide : i.val+2 < j.val
    · exact wide R i j hno hhit hi hj hk hl hwide hn
    let S (x : ℕ) : Prop := x ∈ R
    letI : DecidablePred S := fun a => inferInstanceAs (Decidable (a ∈ R))
    have noTriple (x y z : ℕ) (hx : S x) (hy : S y) (hz : S z) (h : x+z=2*y) :
        x=z := hno x hx y hy z hz h
    have hcases : j.val=i.val+1 ∨ j.val=i.val+2 := by omega
    rcases hcases with h|h
    · exact OMA.GreenR2Ascending.r2_h3_ascending_heights_complete S i.val
        (by have := j.isLt; omega) noTriple hhit hi (by rw [h] at hj; exact hj)
        hk (by rw [h] at hl; exact hl)
    · exact impossible w0 w26 w52 S i.val (by have := j.isLt; omega)
        noTriple hhit hi (by rw [h] at hj; exact hj) hk (by rw [h] at hl; exact hl)
  · exact nonAlt R i j k l hno hhit hi hj hk hl hsign1 hsign2 hnorm
      (by tauto)

end OMA.GreenR2GapTwo

#print axioms OMA.GreenR2GapTwo.exact_h3_split
