import GreenR2Premises
import Green160NearWitness

namespace OMA.GreenR2GapTwo
open OMA.Green160NearWitness (Mono)

def points (a : Nat) : List Nat := [a,a+2,a+27,a+29]
def RedShape (r : Nat → Bool) (a : Nat) := ∀ x ∈ points a, r x = false
def Window (w : Nat) : Prop :=
  ∀ (r : Nat → Bool) (s : Nat), s≤15 → (∀ x ∈ points w, r (s+x)=false) → Mono r

private theorem use_window (r : Nat → Bool) (a w : Nat)
    (lo : w ≤ a) (hi : a ≤ w+15) (window : Window w) (red : RedShape r a) : Mono r := by
  apply window r (a-w) (by omega)
  intro x hx
  have e : x = w ∨ x = w+2 ∨ x = w+27 ∨ x = w+29 := by simpa [points] using hx
  rcases e with he | he | he | he <;> rw [he]
  · rw [show a-w+w=a by omega]; exact red _ (by simp [points])
  · rw [show a-w+(w+2)=a+2 by omega]; exact red _ (by simp [points])
  · rw [show a-w+(w+27)=a+27 by omega]; exact red _ (by simp [points])
  · rw [show a-w+(w+29)=a+29 by omega]; exact red _ (by simp [points])

private theorem reflect_shape (r : Nat → Bool) (a : Nat)
    (ha : a≤130) (red : RedShape r a) : RedShape (fun x => r (159-x)) (130-a) := by
  intro x hx
  have e : x = 130-a ∨ x = 130-a+2 ∨ x = 130-a+27 ∨ x = 130-a+29 := by
    simpa [points] using hx
  rcases e with rfl | rfl | rfl | rfl <;> dsimp only
  · rw [show 159-(130-a)=a+29 by omega]; exact red _ (by simp [points])
  · rw [show 159-(130-a+2)=a+27 by omega]; exact red _ (by simp [points])
  · rw [show 159-(130-a+27)=a+2 by omega]; exact red _ (by simp [points])
  · rw [show 159-(130-a+29)=a by omega]; exact red _ (by simp [points])

private theorem forward (w0 : Window 0) (w26 : Window 26) (w52 : Window 52)
    (r : Nat → Bool) (h : Nat) (hh : h≤5) (red : RedShape r (13*h)) : Mono r := by
  by_cases hi : h≤1
  · exact use_window r (13*h) 0 (by omega) (by omega) w0 red
  by_cases hj : h≤3
  · exact use_window r (13*h) 26 (by omega) (by omega) w26 red
  exact use_window r (13*h) 52 (by omega) (by omega) w52 red

theorem forces_of_gap_two_height (w0 : Window 0) (w26 : Window 26) (w52 : Window 52)
    (r : Nat → Bool) (h : Nat) (hh : h≤10) (red : RedShape r (13*h)) : Mono r := by
  by_cases hlo : h≤5
  · exact forward w0 w26 w52 r h hlo red
  apply OMA.Green160NearWitness.reflect_progression r
  apply forward w0 w26 w52 _ (10-h) (by omega)
  rw [show 13*(10-h)=130-13*h by omega]
  exact reflect_shape r (13*h) (by omega) red

/-- R2.H3's ray configuration with heights (h,h+2,h,h+2). -/
theorem impossible (w0 : Window 0) (w26 : Window 26) (w52 : Window 52)
    (R : Nat → Prop) [DecidablePred R] (h : Nat) (hh : h≤10)
    (noTriple : ∀ x y z, R x → R y → R z → x+z=2*y → x=z)
    (hit : ∀ a d : Nat, 0<d → d≤12 → a+12*d<160 → ∃ t : Fin 13, R (a+t.val*d))
    (ri : R (13*h)) (rj : R (13*(h+2)+1))
    (rk : R (13*h+2)) (rl : R (13*(h+2)+3)) : False := by
  let i : Fin 13 := ⟨h,by omega⟩
  let j : Fin 13 := ⟨h+2,by omega⟩
  apply OMA.GreenR2Premises.impossible_of_mono R i j i j noTriple hit
  · intro x hx
    have e : x=13*h ∨ x=13*(h+2)+1 ∨ x=13*h+2 ∨ x=13*(h+2)+3 := by
      simpa [OMA.GreenR2Premises.rayPoints,i,j] using hx
    rcases e with rfl | rfl | rfl | rfl
    · exact ri
    · exact rj
    · exact rk
    · exact rl
  · apply forces_of_gap_two_height w0 w26 w52 _ h hh
    intro x hx
    have e : x=13*h ∨ x=13*h+2 ∨ x=13*h+27 ∨ x=13*h+29 := by
      simpa [points] using hx
    rcases e with rfl | rfl | rfl | rfl
    · simpa using ri
    · simpa using rk
    · simpa [Nat.mul_add,Nat.add_assoc] using rj
    · simpa [Nat.mul_add,Nat.add_assoc] using rl

end OMA.GreenR2GapTwo

#print axioms OMA.GreenR2GapTwo.impossible
