import FullGapFourGeometry
import GapFourGeometry
import Green147GapFour39
import Green147GapFour13
import Green153GapFour0

namespace OMA.GreenR2GapFourEdges

/-- All nine raw heights in the gap-four alternating family. -/
theorem gap_four (R : Nat → Prop) [DecidablePred R]
    (h : Nat) (hh : h ≤ 8)
    (noTriple : ∀ x y z, R x → R y → R z → x+z=2*y → x=z)
    (hit : ∀ a d : Nat, 0<d → d≤12 → a+12*d<160 → ∃ t : Fin 13, R (a+t.val*d))
    (ri : R (13*h)) (rj : R (13*(h+4)+1))
    (rk : R (13*h+2)) (rl : R (13*(h+4)+3)) : False :=
  impossible OMA.Green153GapFourCore.Start0.shifted_forces_progression
    OMA.Green147GapThreeCore.GapFour13.shifted_forces_progression
    (OMA.GreenR2GapFour.forces_of_gap_four_height
      OMA.Green147GapThreeCore.GapFour39.shifted_forces_progression)
    R h hh noTriple hit ri rj rk rl

end OMA.GreenR2GapFourEdges

#print axioms OMA.GreenR2GapFourEdges.gap_four
