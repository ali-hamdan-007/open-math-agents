from concurrent.futures import ThreadPoolExecutor
from itertools import product
import os
import re
import subprocess

pairs = []
for gap in range(5, 13):
    last = (12 - gap) // 2
    for width, offset in ((160, 0), (160, 13*last), (147, 0), (147, 13*max(0,last-1))):
        if offset + 13*gap + 3 < width:
            pair = (gap, width, offset)
            if pair not in pairs:
                pairs.append(pair)

def run(job):
    (gap,width,offset), order = job
    seed = '1?1' + '?'*(13*gap-2) + '1?1'
    done = subprocess.run(['./search-gap4',seed,str(width),str(offset),'emit'],
                          stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,text=True,
                          env=dict(os.environ,W313_ORDER=str(order)))
    result = re.search(r'sat=([01]), calls=(\d+), depth=\d+, lemmas=(\d+)',done.stderr)
    return gap,width,offset,order,*(map(int,result.groups()) if result else (-1,0,0))

with ThreadPoolExecutor(max_workers=2) as pool:
    for outcome in pool.map(run,product(pairs,(0,1,5))):
        print(*outcome,flush=True)
