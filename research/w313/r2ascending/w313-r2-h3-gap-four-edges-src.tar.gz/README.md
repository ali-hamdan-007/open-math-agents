# W(3,13) R2.H3 gap-four edge cases

Run `./finish.sh` to resume the single-worker Lean 4.33.1 replay. The sources use the original pinned workspace at `/workspace/scratch/6893ca6bed01` and the verified gap-two, gap-three and central gap-four build directories at `/tmp/w313nov28`, `/tmp/w313gap3` and `/tmp/w313gap4`. Set `W313_LEAN_ROOT`, `W313_GAP_TWO_DIR`, `W313_GAP_THREE_DIR` and `W313_CENTRAL_FOUR_DIR` to override those paths. Each fragment is checked using `decide +kernel`.

| Width | Local anchor | Normalized heights | Search nodes | Fragments |
| --- | ---: | --- | ---: | ---: |
| 153 | 0 | 0 | 190,906 | 1,275 |
| 147 | 13 | 1 and 2 | 154,117 | 1,035 |
| 147 | 39 | 3 and 4 | 70,917 | 465 |

The central window is imported from the previous checkpoint. Reflection maps $h$ to $8-h$. The final assembly covers $0 \le h \le 8$ and reduces the literal [merged R2.H3](https://github.com/GuillaumeBAUD-coder/open-math-agents/pull/4300) to 20 normalized alternating tuples with gap at least five and 4,882 nonalternating tuples, provided the replay succeeds.

The source is generated with `g++ -std=c++17 -O3 -o search-gap4 search-gap4.cpp`, followed by `(cd endpoint && python ../generate.py ../search-gap4 153 0 9)` and `(cd shared && python ../generate.py ../search-gap4 147 13 11)`. The generated sources are included. To reproduce the smaller memory-oriented partition, run `python repartition.py endpoint shared` after generation. The representative follow-up measurements are in `next_probe.log`.
