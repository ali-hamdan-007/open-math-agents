#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
root="${W313_LEAN_ROOT:-/workspace/scratch/6893ca6bed01}"
gap_two="${W313_GAP_TWO_DIR:-/tmp/w313nov28}"
gap_three="${W313_GAP_THREE_DIR:-/tmp/w313gap3}"
central_four="${W313_CENTRAL_FOUR_DIR:-/tmp/w313gap4}"
for part in endpoint shared; do
  (cd "$part" && python -u ../replay.py)
done
export LEAN_PATH="$PWD:$PWD/endpoint:$PWD/shared:$central_four:$gap_three:$gap_two:$root/parallel/ramsey/focused:$(cat "$root/parallel/pell/lean-path.txt")"
lean="$root/open-math-agents/.oma/elan/toolchains/leanprover--lean4---v4.33.1/bin/lean"
for module in FullGapFourGeometry FullGapFourVerified H3AfterGapFour; do
  "$lean" -j1 -o "$module.olean" "$module.lean" | tee "$module.log"
done
