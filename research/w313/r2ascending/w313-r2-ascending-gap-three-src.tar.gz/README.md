# W(3,13) ascending R2, gap-three alternating heights

The four red points for heights $(h,h+3,h,h+3)$ are $13h + \{0,2,40,42\}$. Reflection in the 160-point interval changes $h$ to $9-h$, so five normalized heights cover the full range 0 through 9. The exact step is `Green14.W_3_13.R2.H3` of [merged PR #4300](https://github.com/GuillaumeBAUD-coder/open-math-agents/pull/4300).

| Width | Local start | Normalized heights | Search nodes | Fragments |
| ---: | ---: | :--- | ---: | ---: |
| 145 | 26 | 2 and 3 | 35,568 | 226 |
| 147 | 52 | 4 | 23,319 | 149 |
| 157 | 12 | 1 | 51,793 | 347 |
| 159 | 0 | 0 | 98,983 | 638 |

`GapThreeGeometry.lean` compiles and audits under standard Lean axioms. Its theorem `OMA.GreenR2GapThree.impossible` reduces the exact gap-three family under the R2 premises to these four local windows. The certificate searches have finished and generated the 61 DAG source chunks. Their full Lean replay was deferred, so `GapThreeVerified.lean` remains an unverified final assembly. The gap-three family is five of the 30 wider alternating tuples left by the verified gap-one and gap-two proofs.

`check_endpoint_window.py` checks an actual width-148 countercoloring with red at 0, 2, 40 and 42, so any narrower local window that starts at the first red point also admits an avoidance coloring. Covering both h=0 and h=1 with the same positively translated window would require width at most 147 and local start 0.

The generated sources require the original pinned Lean 4.33.1 workspace and the cached `Green145AscendingCore`, `Green160NearWitness` and `GreenR2Premises` in `parallel/ramsey/focused`. Run `./finish.sh` to check the chunks and final assembly. It works sequentially in the dependency order recorded in `dag.json`. It can resume an incomplete build. Each generated fragment uses `decide +kernel`.

Regeneration uses `g++ -std=c++17 -O3 -o search-gap3 search-gap3.cpp` and `python generate_gap3.py ./search-gap3`. `probe.py` and `tune.py` document the bounded window and heuristic scans. `probe.py` uses the previous gap-two search executable.
