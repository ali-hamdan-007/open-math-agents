#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
root=/workspace/scratch/6893ca6bed01
export LEAN_PATH="$PWD:$root/parallel/ramsey/focused:$(cat "$root/parallel/pell/lean-path.txt")"
LEAN="$root/open-math-agents/.oma/elan/toolchains/leanprover--lean4---v4.33.1/bin/lean"
python -c 'import json; print(*(k for k in json.load(open("dag.json")) if k!="Green145AscendingCore"),sep="\n")' |
while IFS= read -r m; do
  if [[ ! -f "$m.olean" ]]; then
    "$LEAN" -o "$m.olean" "$m.lean" >"$m.log" 2>&1 || { cat "$m.log"; exit 1; }
    printf 'checked %s\n' "$m"
  fi
done
