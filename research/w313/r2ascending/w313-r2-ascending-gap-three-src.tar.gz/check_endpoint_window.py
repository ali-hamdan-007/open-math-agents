"""Check a countercoloring on the width-148 window for gap three at h=0."""
N = 148
red = {0, 2, 5, 17, 25, 26, 39, 40, 42, 43, 51, 64, 65, 70, 72, 83,
       92, 95, 108, 109, 116, 117, 122, 129, 134, 143}
assert {0, 2, 40, 42} <= red <= set(range(N))
assert all(a + 2 * d not in red for a in red for b in red if (d := b - a) > 0)
assert all(any(a + t * d in red for t in range(13))
           for d in range(1, 13) for a in range(N - 12 * d))
print(f"Width {N} admits a coloring with {len(red)} red points for (0,2,40,42).")
