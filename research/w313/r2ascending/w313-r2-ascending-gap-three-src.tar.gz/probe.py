from pathlib import Path
import subprocess,re
binary=Path("/tmp/w313nov28/search500")
seed='1?1'+'?'*37+'1?1'
best={}
for n in range(135,161):
    lo=max(0, 13-(160-n))
    for x in sorted({0, *(max(0,13*h-s) for h in range(1,6) for s in (0,(160-n)//2,160-n))}):
        if x+42>=n:continue
        covered=tuple(h for h in range(6) if x<=13*h<=x+160-n)
        if not covered:continue
        out=subprocess.run([str(binary),seed,str(n),str(x)],capture_output=True,text=True)
        m=re.search(r'sat=0, calls=(\d+)',out.stderr)
        if not m:continue
        count=int(m[1])
        if covered not in best or count<best[covered][0]:
            best[covered]=count,n,x
            print(covered,best[covered],flush=True)
print('best',best)
