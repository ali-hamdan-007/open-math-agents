import GapThreeGeometry
import Green145GapThree26
import Green147GapThree52
import Green157GapThree12
import Green159GapThree0

namespace OMA.GreenR2GapThree

private theorem window0 : Window 0 1 :=
  OMA.Green159GapThreeCore.Start0.shifted_forces_progression

private theorem window12 : Window 12 3 :=
  OMA.Green157GapThreeCore.Start12.shifted_forces_progression

private theorem window26 : Window 26 15 :=
  OMA.Green145AscendingCore.GapThree26.shifted_forces_progression

private theorem window52 : Window 52 13 :=
  OMA.Green147GapThreeCore.Start52.shifted_forces_progression

/-- Gap-three alternating heights on the four rays of the ascending R2 case. -/
theorem gap_three (R : Nat → Prop) [DecidablePred R] (h : Nat) (hh : h ≤ 9)
    (noTriple : ∀ x y z, R x → R y → R z → x+z=2*y → x=z)
    (hit : ∀ a d : Nat, 0<d → d≤12 → a+12*d<160 → ∃ t : Fin 13, R (a+t.val*d))
    (ri : R (13*h)) (rj : R (13*(h+3)+1))
    (rk : R (13*h+2)) (rl : R (13*(h+3)+3)) : False :=
  impossible window0 window12 window26 window52 R h hh noTriple hit ri rj rk rl

end OMA.GreenR2GapThree

#print axioms OMA.GreenR2GapThree.gap_three
