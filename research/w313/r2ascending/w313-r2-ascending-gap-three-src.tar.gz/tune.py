import re
import subprocess
from os import environ
from pathlib import Path

binary=Path(__file__).with_name("search-gap3")
targets=[(146,0),(147,0),(145,0),(145,13),(146,38),(145,26),
         (147,52),(159,0),(157,12),(159,26),(148,40),
         (146,13),(147,13),(145,39)]
best={}
for order in [None,*range(24)]:
    for width, start in targets:
        env = dict(environ)
        if order is not None:
            env["W313_ORDER"] = str(order)
        line = subprocess.run(
            [binary,"1?1"+"?"*37+"1?1",str(width),str(start),"emit"],
            stdout=subprocess.DEVNULL, stderr=subprocess.PIPE,env=env,text=True).stderr
        m=re.search(r"sat=0, calls=(\d+), depth=\d+, lemmas=(\d+)",line)
        if m is None: continue
        nodes,lemmas=map(int,m.groups())
        cases=tuple(h for h in range(5) if start<=13*h<=start+160-width)
        if not cases: continue
        key=(width,start)
        old=best.get(key, (1<<60,0,0,()))
        row=(lemmas,nodes,order,cases)
        if row[:2] < old[:2]:
            best[key]=row
            print(key,row,flush=True)
print(best)
