import GreenR2Premises
import Green160NearWitness

namespace OMA.GreenR2GapThree
open OMA.Green160NearWitness (Mono)

def points (a : Nat) : List Nat := [a,a+2,a+40,a+42]
def RedShape (r : Nat → Bool) (a : Nat) := ∀ x ∈ points a, r x = false
def Window (w maxShift : Nat) : Prop :=
  ∀ (r : Nat → Bool) (s : Nat), s≤maxShift → (∀ x ∈ points w, r (s+x)=false) → Mono r

private theorem use_window (r : Nat → Bool) (a w maxShift : Nat)
    (lo : w ≤ a) (hi : a ≤ w+maxShift) (window : Window w maxShift) (red : RedShape r a) : Mono r := by
  apply window r (a-w) (by omega)
  intro x hx
  have e : x = w ∨ x = w+2 ∨ x = w+40 ∨ x = w+42 := by simpa [points] using hx
  rcases e with he | he | he | he <;> rw [he]
  · rw [show a-w+w=a by omega]; exact red _ (by simp [points])
  · rw [show a-w+(w+2)=a+2 by omega]; exact red _ (by simp [points])
  · rw [show a-w+(w+40)=a+40 by omega]; exact red _ (by simp [points])
  · rw [show a-w+(w+42)=a+42 by omega]; exact red _ (by simp [points])

private theorem reflect_shape (r : Nat → Bool) (a : Nat)
    (ha : a≤117) (red : RedShape r a) : RedShape (fun x => r (159-x)) (117-a) := by
  intro x hx
  have e : x = 117-a ∨ x = 117-a+2 ∨ x = 117-a+40 ∨ x = 117-a+42 := by
    simpa [points] using hx
  rcases e with rfl | rfl | rfl | rfl <;> dsimp only
  · rw [show 159-(117-a)=a+42 by omega]; exact red _ (by simp [points])
  · rw [show 159-(117-a+2)=a+40 by omega]; exact red _ (by simp [points])
  · rw [show 159-(117-a+40)=a+2 by omega]; exact red _ (by simp [points])
  · rw [show 159-(117-a+42)=a by omega]; exact red _ (by simp [points])

private theorem forward (w0 : Window 0 1) (w12 : Window 12 3)
    (w26 : Window 26 15) (w52 : Window 52 13)
    (r : Nat → Bool) (h : Nat) (hh : h≤4) (red : RedShape r (13*h)) : Mono r := by
  by_cases he : h=0
  · exact use_window r (13*h) 0 1 (by omega) (by omega) w0 red
  by_cases he : h=1
  · exact use_window r (13*h) 12 3 (by omega) (by omega) w12 red
  by_cases he : h≤3
  · exact use_window r (13*h) 26 15 (by omega) (by omega) w26 red
  exact use_window r (13*h) 52 13 (by omega) (by omega) w52 red

theorem forces_of_gap_three_height (w0 : Window 0 1) (w12 : Window 12 3)
    (w26 : Window 26 15) (w52 : Window 52 13)
    (r : Nat → Bool) (h : Nat) (hh : h≤9) (red : RedShape r (13*h)) : Mono r := by
  by_cases hlo : h≤4
  · exact forward w0 w12 w26 w52 r h hlo red
  apply OMA.Green160NearWitness.reflect_progression r
  apply forward w0 w12 w26 w52 _ (9-h) (by omega)
  rw [show 13*(9-h)=117-13*h by omega]
  exact reflect_shape r (13*h) (by omega) red

/-- R2.H3's ray configuration with heights (h,h+3,h,h+3). -/
theorem impossible (w0 : Window 0 1) (w12 : Window 12 3)
    (w26 : Window 26 15) (w52 : Window 52 13)
    (R : Nat → Prop) [DecidablePred R] (h : Nat) (hh : h≤9)
    (noTriple : ∀ x y z, R x → R y → R z → x+z=2*y → x=z)
    (hit : ∀ a d : Nat, 0<d → d≤12 → a+12*d<160 → ∃ t : Fin 13, R (a+t.val*d))
    (ri : R (13*h)) (rj : R (13*(h+3)+1))
    (rk : R (13*h+2)) (rl : R (13*(h+3)+3)) : False := by
  let i : Fin 13 := ⟨h,by omega⟩
  let j : Fin 13 := ⟨h+3,by omega⟩
  apply OMA.GreenR2Premises.impossible_of_mono R i j i j noTriple hit
  · intro x hx
    have e : x=13*h ∨ x=13*(h+3)+1 ∨ x=13*h+2 ∨ x=13*(h+3)+3 := by
      simpa [OMA.GreenR2Premises.rayPoints,i,j] using hx
    rcases e with rfl | rfl | rfl | rfl
    · exact ri
    · exact rj
    · exact rk
    · exact rl
  · apply forces_of_gap_three_height w0 w12 w26 w52 _ h hh
    intro x hx
    have e : x=13*h ∨ x=13*h+2 ∨ x=13*h+40 ∨ x=13*h+42 := by
      simpa [points] using hx
    rcases e with rfl | rfl | rfl | rfl
    · simpa using ri
    · simpa using rk
    · simpa [Nat.mul_add,Nat.add_assoc] using rj
    · simpa [Nat.mul_add,Nat.add_assoc] using rl

end OMA.GreenR2GapThree

#print axioms OMA.GreenR2GapThree.impossible
