"""Generate the four gap-three ascending certificates as bounded Lean DAGs."""
import json
from os import environ
from argparse import ArgumentParser
from collections import defaultdict
from pathlib import Path
import re
import subprocess

work = Path(__file__).resolve().parent
ramsey = Path("/workspace/scratch/6893ca6bed01/parallel/ramsey")
parser = ArgumentParser(description=__doc__)
parser.add_argument("solver", type=Path)
args = parser.parse_args()

build = {}

for width, offset, order in ((145, 26, 4), (147, 52, 20), (157, 12, 2), (159, 0, 5)):
    core = f"Green{width}GapThreeCore"
    stem = f"Green{width}GapThree{offset}"
    ns = f"OMA.{core}.Start{offset}"
    if width == 145:
        core = "Green145AscendingCore"
        ns = f"OMA.{core}.GapThree{offset}"
    else:
        source = (ramsey / "r2ascending/full145/Green145AscendingCore.lean").read_text()
        source = source.replace("Green145AscendingCore", core).replace("< 145", f"< {width}")
        (work / f"{core}.lean").write_text(source)
        build[core] = []
    search = subprocess.run(
        [str(args.solver.resolve()), "1?1" + "?"*37 + "1?1", str(width), str(offset), "emit"],
        capture_output=True, text=True, check=True, env=dict(environ, W313_ORDER=str(order)),
    )
    if not re.search(r"^sat=0, calls=", search.stderr, re.M):
        raise ValueError(search.stderr)
    chunks = re.split(r"(?=^set_option maxRecDepth)", search.stdout, flags=re.M)
    chunks = [block for block in chunks if block]
    levels = {}
    by_level = defaultdict(list)
    dependencies = {}
    for i, block in enumerate(chunks):
        ident = int(re.search(r"^lemma v(\d+) :", block, re.M)[1])
        deps = tuple(int(dep) for dep in re.findall(r"⟨_,v(\d+)⟩", block))
        if ident != i or any(dep >= i for dep in deps):
            raise ValueError("Non-topological dependency")
        levels[i] = 1 + max((levels[dep] for dep in deps), default=0)
        dependencies[i] = deps
        block = block.replace(f"lemma v{i} :", f"theorem v{i} :")
        by_level[levels[i]].append((i, block))

    owners = {}
    count = 0

    def write_block(blocks):
        name = f"{stem}D{len(build):03}"
        modules = sorted({owners[dep] for i, _ in blocks for dep in dependencies[i]})
        if not modules:
            modules = [core]
        imports = "\n".join(f"import {module}" for module in modules)
        text = f"{imports}\n\nnamespace {ns}\n\n"
        for i, block in blocks:
            text += block
            owners[i] = name
        (work / f"{name}.lean").write_text(text + f"\nend {ns}\n")
        build[name] = modules

    for level in sorted(by_level):
        current = []
        size = 0
        for i, block in by_level[level]:
            nbytes = len(block.encode("utf-8"))
            if current and size + nbytes > 52 * 1024:
                write_block(current)
                count += 1
                current = []
                size = 0
            current.append((i, block))
            size += nbytes
        if current:
            write_block(current)
            count += 1

    last = re.search(r"^lemma (v\d+) : Bad \([^\n]*?,(0x[\da-f]+)\)", chunks[-1], re.M)
    points = [offset + p for p in (0, 2, 40, 42)]
    tail = (ramsey / "r2ascending" / "window.tail").read_text()
    for marker, value in {
        "@WIDTH@": str(width), "@SHIFT@": str(160-width), "@LAST@": last[1], "@MASK@": last[2],
        "@ORDERED@": str(points), "@REVERSED@": str(points[::-1]),
        "@CASES@": " ∨ ".join(f"x = {p}" for p in points[::-1]),
        "@POINTS@": "rfl | rfl | rfl | rfl",
    }.items():
        tail = tail.replace(marker, value)
    module = owners[len(chunks) - 1]
    (work / f"{stem}.lean").write_text(
        f"import {module}\nimport Green160NearWitness\n\nnamespace {ns}\n\n"
        + tail + f"\nend {ns}\n\n"
        f"#print axioms {ns}.shifted_forces_progression\n"
        f"#print axioms {ns}.reflected_shifted_forces_progression\n"
    )
    build[stem] = [module]
    message = search.stderr + f"levels={max(levels.values())}, modules={count}\n"
    (work / f"search-{width}-{offset}.log").write_text(message)
    print(message, end="")
(work / "dag.json").write_text(json.dumps(build, indent=2) + "\n")
