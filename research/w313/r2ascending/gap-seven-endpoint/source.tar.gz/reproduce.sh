#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
target=${1:-$(mktemp -d /tmp/w313-gap-seven-regeneration.XXXXXX)}
mkdir -p "$target"
target=$(realpath "$target")
g++ -std=c++17 -O3 -o "$target/search-gap4" search-gap4.cpp
generator=$PWD/generate.py
repartition=$PWD/repartition.py
(cd "$target" && python "$generator" ./search-gap4 159 0 8 && python "$repartition" .)
printf 'Generated sources in %s\n' "$target"
