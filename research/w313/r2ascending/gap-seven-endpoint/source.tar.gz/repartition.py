"""Split unchecked certificate modules without changing their theorem bodies."""
import json
from pathlib import Path
import re
import sys

MAX_BYTES = 24 * 1024
for directory in map(Path, sys.argv[1:]):
    path = directory / "dag.json"
    dag = json.loads(path.read_text())
    repartitioned = {}
    for name, dependencies in dag.items():
        lean = directory / f"{name}.lean"
        if lean.stat().st_size <= MAX_BYTES or (directory / f"{name}.olean").is_file():
            repartitioned[name] = dependencies
            continue
        text = lean.read_text()
        header, start, tail = text.partition("set_option maxRecDepth")
        if not start:
            raise ValueError(f"{name} has no fragments")
        bodies, end, footer = (start + tail).rpartition("\nend ")
        if not end:
            raise ValueError(f"{name} has no namespace footer")
        chunks = re.split(r"(?=^set_option maxRecDepth)", bodies, flags=re.M)
        groups = []
        group = ""
        for chunk in filter(None, chunks):
            if group and len((group + chunk).encode()) > MAX_BYTES:
                groups.append(group)
                group = ""
            group += chunk
        if group:
            groups.append(group)
        if len(groups) < 2:
            raise ValueError(f"{name} has one unsplittable fragment")
        parts = []
        for index, group in enumerate(groups):
            part = f"{name}Part{index}"
            parts.append(part)
            (directory / f"{part}.lean").write_text(header + group + end + footer)
            repartitioned[part] = dependencies
        lean.write_text("".join(f"import {part}\n" for part in parts))
        repartitioned[name] = parts
        print(f"Split {name} into {len(parts)} parts")
    path.write_text(json.dumps(repartitioned, indent=2) + "\n")
