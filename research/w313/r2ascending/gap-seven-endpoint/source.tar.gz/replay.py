"""Run the certificate DAG in dependency order with one pinned Lean worker."""
import json
import os
from pathlib import Path
import subprocess

root = Path(os.environ.get("W313_LEAN_ROOT", "/workspace/scratch/6893ca6bed01"))
lean = root / "open-math-agents/.oma/elan/toolchains/leanprover--lean4---v4.33.1/bin/lean"
os.environ["LEAN_PATH"] = ":".join([
    str(Path.cwd()),
    os.environ.get("W313_GAP_THREE_DIR", "/tmp/w313gap3"),
    str(root / "parallel/ramsey/focused"),
    (root / "parallel/pell/lean-path.txt").read_text().strip(),
])
dag = json.loads(Path("dag.json").read_text())
checked = {"Green147GapThreeCore"}
for module, dependencies in dag.items():
    if not set(dependencies) <= checked:
        raise ValueError(f"{module} precedes one of its dependencies")
    output = Path(f"{module}.olean")
    if not output.is_file():
        with Path(f"{module}.log").open("w") as log:
            subprocess.run([lean, "-j1", "-o", output, f"{module}.lean"],
                           stdout=log, stderr=subprocess.STDOUT, check=True)
        print(f"checked {module}", flush=True)
    checked.add(module)
