import H3AfterGapFiveInterior

namespace OMA.GreenR2GapSevenEndpoint

open OMA.GreenR2GapTwo (Nonalternating)

section
variable (window : ∀ (r : Nat → Bool) (s : Nat), s ≤ 1 →
  (∀ x ∈ [0, 2, 92, 94], r (s + x) = false) → OMA.Green160NearWitness.Mono r)
include window

theorem gap_seven_height_zero (R : Nat → Prop) [DecidablePred R]
    (noTriple : ∀ x y z, R x → R y → R z → x+z=2*y → x=z)
    (hit : ∀ a d : Nat, 0<d → d≤12 → a+12*d<160 → ∃ t : Fin 13, R (a+t.val*d))
    (ri : R 0) (rj : R 92) (rk : R 2) (rl : R 94) : False := by
  apply OMA.GreenR2Premises.impossible_of_mono R 0 7 0 7 noTriple hit
  · intro x hx
    have e : x = 0 ∨ x = 92 ∨ x = 2 ∨ x = 94 := by
      change x ∈ [0, 92, 2, 94] at hx
      simpa using hx
    rcases e with rfl | rfl | rfl | rfl
    · exact ri
    · exact rj
    · exact rk
    · exact rl
  apply window _ 0 (by decide)
  intro x hx
  have e : x = 0 ∨ x = 2 ∨ x = 92 ∨ x = 94 := by simpa using hx
  rcases e with rfl | rfl | rfl | rfl
  · simpa using ri
  · simpa using rk
  · simpa using rj
  · simpa using rl

def RemainingAlternating : Prop :=
  ∀ (R : Finset ℕ) (i j : Fin 13),
    (∀ x ∈ R, ∀ y ∈ R, ∀ z ∈ R, x + z = 2*y → x = z) →
    (∀ a d : ℕ, 0 < d → d ≤ 12 → a + 12*d < 160 →
      ∃ t : Fin 13, a + t.val*d ∈ R) →
    13*i.val ∈ R → 13*j.val + 1 ∈ R → 13*i.val + 2 ∈ R → 13*j.val + 3 ∈ R →
    i.val + 4 < j.val → i.val + j.val ≤ 12 →
    (i.val = 0 ∨ i.val + 5 < j.val) →
    (i.val ≠ 0 ∨ j.val ≠ 7) → False

theorem h3_iff_remaining_alternating_and_nonalternating :
    OMA.R_Green14_W_3_13_R2.H3 ↔ RemainingAlternating ∧ Nonalternating := by
  rw [OMA.GreenR2GapFiveInterior.h3_iff_remaining_alternating_and_nonalternating]
  constructor
  · rintro ⟨wide, nonAlt⟩
    exact ⟨fun R i j hno hhit hi hj hk hl hgap hnorm hcase _ =>
      wide R i j hno hhit hi hj hk hl hgap hnorm hcase, nonAlt⟩
  · rintro ⟨remaining, nonAlt⟩
    refine ⟨?_, nonAlt⟩
    intro R i j hno hhit hi hj hk hl hgap hnorm hcase
    by_cases hnew : i.val ≠ 0 ∨ j.val ≠ 7
    · exact remaining R i j hno hhit hi hj hk hl hgap hnorm hcase hnew
    · have hiZero : i.val = 0 := by omega
      have hjSeven : j.val = 7 := by omega
      let S (x : ℕ) : Prop := x ∈ R
      let : DecidablePred S := fun a => inferInstanceAs (Decidable (a ∈ R))
      have noTriple (x y z : ℕ) (hx : S x) (hy : S y) (hz : S z) (he : x+z=2*y) :
          x = z := hno x hx y hy z hz he
      exact gap_seven_height_zero window S noTriple hhit
        (by simpa [hiZero] using hi) (by simpa [hjSeven] using hj)
        (by simpa [hiZero] using hk) (by simpa [hjSeven] using hl)

end
end OMA.GreenR2GapSevenEndpoint

#print axioms OMA.GreenR2GapSevenEndpoint.gap_seven_height_zero
#print axioms OMA.GreenR2GapSevenEndpoint.h3_iff_remaining_alternating_and_nonalternating
