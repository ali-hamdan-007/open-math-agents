from collections import Counter
from itertools import product
from pathlib import Path
import sys

ramsey = Path('/workspace/scratch/6893ca6bed01/parallel/ramsey')
sys.path[:0] = [str(ramsey / 'window141'), str(ramsey / 'r2geometry')]
from r2_screen import propagate, r2_case
from classify import WINDOWS, embeddings

verified = {pattern for width, seed in WINDOWS for pattern in embeddings(width, seed)}
for start, end in ((0, 15), (24, 39), (52, 65), (78, 91), (104, 119), (128, 143)):
    verified.update((a, a + 2, a + 14, a + 16) for a in range(start, end + 1))

base = tuple(sum(1 << p for p in seed) for seed in sorted(verified))
for width, anchor, gap in ((145,0,2),(145,26,2),(145,52,2),(145,26,3),
                           (147,52,3),(157,12,3),(159,0,3)):
    distance = 13 * gap + 1
    seed = (anchor, anchor + 2, anchor + distance, anchor + distance + 2)
    verified.update(embeddings(width, seed))
clauses = tuple(sum(1 << p for p in seed) for seed in sorted(verified))

counts = Counter()
new = []
for i,j,k,l in product(range(13), repeat=4):
    if r2_case(i,j,k,l) != 'H3':
        continue
    if i==k and j==l and j-i<=3:
        continue
    reds = (13*i, 13*j+1, 13*k+2, 13*l+3)
    if not propagate(reds, clauses):
        new.append(((i,j,k,l), reds))
    else:
        counts['alternating' if i==k and j==l else 'nonalternating'] += 1
print('Certified clauses',len(base),'=>',len(clauses))
print('Survivors',dict(counts))
print('Additional eliminations',len(new),new)
