from concurrent.futures import ThreadPoolExecutor
from itertools import product
import os
import re
import subprocess

binary = "/tmp/w313gap3/search-gap3"
shape = "1?1" + "?" * 50 + "1?1"
windows = ((145, 39), (147, 39), (146, 39), (144, 39), (147, 38), (146, 38))
jobs = product(windows, range(16))

def run(job):
    (width, offset), order = job
    result = subprocess.run([binary, shape, str(width), str(offset), "emit"],
                            stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, text=True,
                            env=dict(os.environ, W313_ORDER=str(order)))
    found = re.search(r"sat=0, calls=(\d+), depth=\d+, lemmas=(\d+)", result.stderr)
    return (width, offset, order, *(map(int, found.groups()) if found else (0, 0)))

with ThreadPoolExecutor(max_workers=4) as pool:
    for result in pool.map(run, jobs):
        print(*result, flush=True)
