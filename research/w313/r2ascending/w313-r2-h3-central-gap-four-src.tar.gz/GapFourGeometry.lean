import GreenR2Premises
import Green160NearWitness

namespace OMA.GreenR2GapFour
open OMA.Green160NearWitness (Mono)

def points (a : Nat) : List Nat := [a,a+2,a+53,a+55]
def RedShape (r : Nat → Bool) (a : Nat) := ∀ x ∈ points a, r x = false
def Window (w maxShift : Nat) : Prop :=
  ∀ (r : Nat → Bool) (s : Nat), s≤maxShift → (∀ x ∈ points w, r (s+x)=false) → Mono r

private theorem use_window (r : Nat → Bool) (a w maxShift : Nat)
    (lo : w ≤ a) (hi : a ≤ w+maxShift) (window : Window w maxShift) (red : RedShape r a) : Mono r := by
  apply window r (a-w) (by omega)
  intro x hx
  have e : x = w ∨ x = w+2 ∨ x = w+53 ∨ x = w+55 := by simpa [points] using hx
  rcases e with he | he | he | he <;> rw [he]
  · rw [show a-w+w=a by omega]; exact red _ (by simp [points])
  · rw [show a-w+(w+2)=a+2 by omega]; exact red _ (by simp [points])
  · rw [show a-w+(w+53)=a+53 by omega]; exact red _ (by simp [points])
  · rw [show a-w+(w+55)=a+55 by omega]; exact red _ (by simp [points])

private theorem reflect_shape (r : Nat → Bool) (a : Nat)
    (ha : a≤104) (red : RedShape r a) : RedShape (fun x => r (159-x)) (104-a) := by
  intro x hx
  have e : x = 104-a ∨ x = 104-a+2 ∨ x = 104-a+53 ∨ x = 104-a+55 := by
    simpa [points] using hx
  rcases e with rfl | rfl | rfl | rfl <;> dsimp only
  · rw [show 159-(104-a)=a+55 by omega]; exact red _ (by simp [points])
  · rw [show 159-(104-a+2)=a+53 by omega]; exact red _ (by simp [points])
  · rw [show 159-(104-a+53)=a+2 by omega]; exact red _ (by simp [points])
  · rw [show 159-(104-a+55)=a by omega]; exact red _ (by simp [points])

theorem forces_of_gap_four_height (window : Window 39 13)
    (r : Nat → Bool) (h : Nat) (hlo : 3 ≤ h) (hhi : h ≤ 5)
    (red : RedShape r (13*h)) : Mono r := by
  by_cases hleft : h ≤ 4
  · exact use_window r (13*h) 39 13 (by omega) (by omega) window red
  apply OMA.Green160NearWitness.reflect_progression r
  apply use_window _ (13 * (8-h)) 39 13 (by omega) (by omega) window
  rw [show 13*(8-h)=104-13*h by omega]
  exact reflect_shape r (13*h) (by omega) red

/-- Gap-four ray configurations in the three central translates. -/
theorem impossible (window : Window 39 13)
    (R : Nat → Prop) [DecidablePred R] (h : Nat) (hlo : 3 ≤ h) (hhi : h ≤ 5)
    (noTriple : ∀ x y z, R x → R y → R z → x+z=2*y → x=z)
    (hit : ∀ a d : Nat, 0<d → d≤12 → a+12*d<160 → ∃ t : Fin 13, R (a+t.val*d))
    (ri : R (13*h)) (rj : R (13*(h+4)+1))
    (rk : R (13*h+2)) (rl : R (13*(h+4)+3)) : False := by
  let i : Fin 13 := ⟨h,by omega⟩
  let j : Fin 13 := ⟨h+4,by omega⟩
  apply OMA.GreenR2Premises.impossible_of_mono R i j i j noTriple hit
  · intro x hx
    have e : x=13*h ∨ x=13*(h+4)+1 ∨ x=13*h+2 ∨ x=13*(h+4)+3 := by
      simpa [OMA.GreenR2Premises.rayPoints,i,j] using hx
    rcases e with rfl | rfl | rfl | rfl
    · exact ri
    · exact rj
    · exact rk
    · exact rl
  · apply forces_of_gap_four_height window _ h hlo hhi
    intro x hx
    have e : x=13*h ∨ x=13*h+2 ∨ x=13*h+53 ∨ x=13*h+55 := by
      simpa [points] using hx
    rcases e with rfl | rfl | rfl | rfl
    · simpa using ri
    · simpa using rk
    · simpa [Nat.mul_add,Nat.add_assoc] using rj
    · simpa [Nat.mul_add,Nat.add_assoc] using rl

end OMA.GreenR2GapFour

#print axioms OMA.GreenR2GapFour.impossible
