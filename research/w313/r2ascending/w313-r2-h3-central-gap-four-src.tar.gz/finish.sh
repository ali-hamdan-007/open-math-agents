#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
root=/workspace/scratch/6893ca6bed01
export LEAN_PATH="$PWD:/tmp/w313gap3:/tmp/w313nov28:$root/parallel/ramsey/focused:$(cat "$root/parallel/pell/lean-path.txt")"
lean="$root/open-math-agents/.oma/elan/toolchains/leanprover--lean4---v4.33.1/bin/lean"
for module in EndpointWindow GapFourGeometry GapFourVerified H3CentralGapFour; do
  "$lean" -j1 -o "$module.olean" "$module.lean" | tee "$module.log"
done
