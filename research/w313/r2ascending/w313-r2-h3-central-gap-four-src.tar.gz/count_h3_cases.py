"""Count the cases remaining after the central gap-four Lean certificate."""
from collections import Counter
from itertools import product

counts = Counter()
for i, j, k, l in product(range(13), repeat=4):
    if not (i + k < 2 * j and 2 * k < j + l):
        continue
    if not (i + l < 12 or (i + l == 12 and j + k <= 12)):
        continue
    if i != k or j != l:
        category = "nonalternating"
    elif j - i <= 3 or (j - i == 4 and i >= 3):
        category = "verified alternating"
    elif j - i == 4:
        category = "remaining gap four"
    else:
        category = "gap at least five"
    counts[category] += 1

for category, count in sorted(counts.items()):
    print(category, count)
print("total", sum(counts.values()))
