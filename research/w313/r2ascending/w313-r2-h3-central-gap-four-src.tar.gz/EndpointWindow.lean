import Mathlib.Data.List.Basic
import GreenR2Premises

namespace OMA.GreenR2GapFour

def endpointReds : List ℕ :=
  [0, 2, 7, 10, 16, 28, 29, 36, 37, 50, 53, 55, 66, 75, 85, 88, 89, 92, 102, 105,
   107, 111, 124, 127, 136]

/-- A red set on 145 sites with the endpoint gap-four seed. -/
theorem endpoint_window_witness :
    (∀ x ∈ [0, 2, 53, 55], x ∈ endpointReds) ∧
    (∀ x ∈ endpointReds, x < 145) ∧
    (∀ x ∈ endpointReds, ∀ y ∈ endpointReds, ∀ z ∈ endpointReds,
      x + z = 2 * y → x = z) ∧
    (∀ a d : ℕ, 0 < d → a + 12 * d < 145 → ∃ t : Fin 13, a + t.val * d ∈ endpointReds) := by
  refine ⟨?_, ?_, ?_, ?_⟩
  · intro x hx
    have : x = 0 ∨ x = 2 ∨ x = 53 ∨ x = 55 := by simpa using hx
    rcases this with rfl | rfl | rfl | rfl <;> decide
  · have check : endpointReds.all (fun x => decide (x < 145)) = true := by decide +kernel
    intro x hx
    exact of_decide_eq_true (List.all_eq_true.mp check x hx)
  · have check : endpointReds.all (fun x => endpointReds.all (fun z =>
      decide (x = z ∨ (x + z) % 2 ≠ 0 ∨ (x + z) / 2 ∉ endpointReds))) = true := by
      decide +kernel
    intro x hx y hy z hz h
    have found := of_decide_eq_true (List.all_eq_true.mp (List.all_eq_true.mp check x hx) z hz)
    rcases found with hEqual | hOdd | hMid
    · exact hEqual
    · omega
    · exact False.elim (hMid (by rw [show (x + z) / 2 = y by omega]; exact hy))
  · have check : (List.range 13).all (fun d =>
      (List.range (145 - 12 * d)).all (fun a =>
        decide (0 < d → ∃ t : Fin 13, a + t.val * d ∈ endpointReds))) = true := by decide +kernel
    intro a d hd hb
    have dIn : d ∈ List.range 13 := List.mem_range.mpr (by omega)
    have aIn : a ∈ List.range (145 - 12 * d) := List.mem_range.mpr (by omega)
    exact of_decide_eq_true (List.all_eq_true.mp (List.all_eq_true.mp check d dIn) a aIn) hd

/-- Every shorter endpoint window that contains the seed inherits the witness. -/
theorem endpoint_prefix_witness (N : ℕ) (hlo : 55 < N) (hhi : N ≤ 145) :
    ∃ R : ℕ → Prop,
      (∀ x ∈ [0, 2, 53, 55], R x) ∧
      (∀ x, R x → x < N) ∧
      (∀ x y z, R x → R y → R z → x + z = 2 * y → x = z) ∧
      (∀ a d : ℕ, 0 < d → a + 12 * d < N → ∃ t : Fin 13, R (a + t.val * d)) := by
  obtain ⟨seed, _, noTriple, hits⟩ := endpoint_window_witness
  refine ⟨fun x => x < N ∧ x ∈ endpointReds, ?_, fun _ hx => hx.1, ?_, ?_⟩
  · intro x hx
    refine ⟨?_, seed x hx⟩
    have : x = 0 ∨ x = 2 ∨ x = 53 ∨ x = 55 := by simpa using hx
    omega
  · intro x y z hx hy hz he
    exact noTriple x hx.2 y hy.2 z hz.2 he
  · intro a d hd hb
    obtain ⟨t, ht⟩ := hits a d hd (by omega)
    have hm : t.val * d ≤ 12 * d := Nat.mul_le_mul_right d (by have := t.isLt; omega)
    exact ⟨t, by omega, ht⟩

end OMA.GreenR2GapFour

#print axioms OMA.GreenR2GapFour.endpoint_window_witness

#print axioms OMA.GreenR2GapFour.endpoint_prefix_witness
