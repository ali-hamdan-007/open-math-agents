import H3LiteralAudit
import GapFourVerified

namespace OMA.GreenR2GapFour

open OMA.GreenR2GapTwo (Nonalternating)

/-- The alternating heights that remain after the central gap-four exclusion. -/
def AlternatingRemainder : Prop :=
  ∀ (R : Finset ℕ) (i j : Fin 13),
    (∀ x ∈ R, ∀ y ∈ R, ∀ z ∈ R, x + z = 2*y → x = z) →
    (∀ a d : ℕ, 0 < d → d ≤ 12 → a + 12*d < 160 →
      ∃ t : Fin 13, a + t.val*d ∈ R) →
    13*i.val ∈ R → 13*j.val + 1 ∈ R → 13*i.val + 2 ∈ R → 13*j.val + 3 ∈ R →
    i.val + 3 < j.val → i.val + j.val ≤ 12 → (i.val ≤ 2 ∨ i.val + 4 < j.val) → False

/-- The literal H3 statement is equivalent to the remaining two families. -/
theorem h3_iff_alternating_remainder_and_nonalternating :
    OMA.R_Green14_W_3_13_R2.H3 ↔ AlternatingRemainder ∧ Nonalternating := by
  rw [show OMA.R_Green14_W_3_13_R2.H3 = OMA.GreenR2GapTwo.ExpectedH3 from rfl,
    OMA.GreenR2GapThree.h3_iff_gap_at_least_four_and_nonalternating]
  constructor
  · rintro ⟨wide, nonAlt⟩
    exact ⟨fun R i j hno hhit hi hj hk hl hgap hnorm _ =>
      wide R i j hno hhit hi hj hk hl hgap hnorm, nonAlt⟩
  · rintro ⟨remaining, nonAlt⟩
    refine ⟨?_, nonAlt⟩
    intro R i j hno hhit hi hj hk hl hgap hnorm
    by_cases hremaining : i.val ≤ 2 ∨ i.val + 4 < j.val
    · exact remaining R i j hno hhit hi hj hk hl hgap hnorm hremaining
    · have hfour : j.val = i.val + 4 := by omega
      let S (x : ℕ) : Prop := x ∈ R
      let : DecidablePred S := fun a => inferInstanceAs (Decidable (a ∈ R))
      have noTriple (x y z : ℕ) (hx : S x) (hy : S y) (hz : S z) (h : x+z=2*y) :
          x = z := hno x hx y hy z hz h
      exact gap_four_central S i.val (by omega) (by omega) noTriple hhit hi
        (by rw [hfour] at hj; exact hj) hk (by rw [hfour] at hl; exact hl)

end OMA.GreenR2GapFour

#print axioms OMA.GreenR2GapFour.h3_iff_alternating_remainder_and_nonalternating
