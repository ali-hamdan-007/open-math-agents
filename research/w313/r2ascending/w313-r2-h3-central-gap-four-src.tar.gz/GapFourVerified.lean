import GapFourGeometry
import Green147GapFour39

namespace OMA.GreenR2GapFour

/-- A single local window excludes the three central gap-four heights. -/
theorem gap_four_central (R : Nat → Prop) [DecidablePred R]
    (h : Nat) (hlo : 3 ≤ h) (hhi : h ≤ 5)
    (noTriple : ∀ x y z, R x → R y → R z → x+z=2*y → x=z)
    (hit : ∀ a d : Nat, 0<d → d≤12 → a+12*d<160 → ∃ t : Fin 13, R (a+t.val*d))
    (ri : R (13*h)) (rj : R (13*(h+4)+1))
    (rk : R (13*h+2)) (rl : R (13*(h+4)+3)) : False :=
  impossible OMA.Green147GapThreeCore.GapFour39.shifted_forces_progression
    R h hlo hhi noTriple hit ri rj rk rl

end OMA.GreenR2GapFour

#print axioms OMA.GreenR2GapFour.gap_four_central
