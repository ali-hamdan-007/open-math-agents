from concurrent.futures import ThreadPoolExecutor
import re
import subprocess

binary = "/tmp/w313gap3/search-gap3"
shape = "1?1" + "?" * 50 + "1?1"
pairs = [(width, offset) for width in (141, 145, 147, 149, 153, 157, 159, 160)
         for offset in sorted({max(0, 13 * h - shift) for h in range(5)
                              for shift in (0, (160-width)//2, 160-width)})]

def run(pair):
    width, offset = pair
    result = subprocess.run([binary, shape, str(width), str(offset)],
                            capture_output=True, text=True)
    cases = tuple(h for h in range(5) if offset <= 13*h <= offset + 160-width)
    found = re.search(r"sat=([01]), calls=(\d+)", result.stderr)
    return (width, offset, cases, found.group(1, 2) if found else result.stderr.strip())

with ThreadPoolExecutor(max_workers=4) as pool:
    for result in pool.map(run, pairs):
        print(result, flush=True)
