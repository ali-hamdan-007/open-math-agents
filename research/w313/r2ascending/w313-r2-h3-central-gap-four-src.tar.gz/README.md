# W(3,13) R2.H3 central gap-four cases

The four red sites for ray heights $(h,h+4,h,h+4)$ are $13h + \{0,2,53,55\}$. One width-147 certificate uses local red sites 39, 41, 92 and 94. Its admissible translations cover $h=3,4$. Reflection takes $h$ to $8-h$ and also covers $h=5$.

The generation run visited 70,917 nodes and produced 465 certificate fragments in 18 DAG modules. Pinned Lean 4.33.1 checked the DAG with `decide +kernel`, the translated and reflected window theorem, the central exclusion, and the exact bridge to the merged R2.H3 declaration in [#4300](https://github.com/GuillaumeBAUD-coder/open-math-agents/pull/4300). The central exclusion and bridge use `propext`, `Classical.choice` and `Quot.sound`.

| Normalized H3 case | Tuples |
| --- | ---: |
| Verified alternating | 19 |
| Remaining gap four, $h=0,1,2$ | 3 |
| Alternating with gap at least five | 20 |
| Nonalternating | 4,882 |
| Total | 4,924 |

`EndpointWindow.lean` independently certifies a 145-site avoiding coloring with 25 red sites containing 0, 2, 53 and 55. It also proves that restricting the coloring to any prefix containing the four red sites preserves avoidance. An anchored endpoint window for $h=0$ therefore needs width at least 146. These witness theorems use only `propext` and `Quot.sound`.

After transferring gap-two and gap-three windows, `propagate.py` checks 451 distinct forbidden four-red patterns, up from 302. Unit propagation with these patterns gives no additional normalized H3 exclusions beyond the cases already certified. Bounded search found a width-147 window at offset 13 for $h=1,2$ and a width-160 endpoint window for $h=0$. Those two searches have no Lean certificates in this checkpoint.

## Reproduce

On the original pinned workspace, build the preceding combined gap-two and gap-three checkpoint in `/tmp/w313nov28` and `/tmp/w313gap3`. Unpack this directory and run `python replay.py`, then `./finish.sh`. Replay uses two concurrent jobs by default. `python count_h3_cases.py` reproduces the table. To regenerate the certificate sources, run `python generate_gap4.py /tmp/w313gap3/search-gap3`. That generator uses the prior width-147 checker and the shared window proof template.
