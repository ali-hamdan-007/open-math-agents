import H3AfterGapFour
import Green147GapFive26

namespace OMA.GreenR2GapFive

open OMA.GreenR2GapTwo (Nonalternating)

theorem gap_five_heights_two_three (R : Nat → Prop) [DecidablePred R]
    (h : Nat) (hlo : 2 ≤ h) (hhi : h ≤ 3)
    (noTriple : ∀ x y z, R x → R y → R z → x+z=2*y → x=z)
    (hit : ∀ a d : Nat, 0<d → d≤12 → a+12*d<160 → ∃ t : Fin 13, R (a+t.val*d))
    (ri : R (13*h)) (rj : R (13*(h+5)+1))
    (rk : R (13*h+2)) (rl : R (13*(h+5)+3)) : False := by
  let i : Fin 13 := ⟨h, by omega⟩
  let j : Fin 13 := ⟨h+5, by omega⟩
  apply OMA.GreenR2Premises.impossible_of_mono R i j i j noTriple hit
  · intro x hx
    have e : x = 13*h ∨ x = 13*(h+5)+1 ∨ x = 13*h+2 ∨ x = 13*(h+5)+3 := by
      simpa [OMA.GreenR2Premises.rayPoints, i, j] using hx
    rcases e with rfl | rfl | rfl | rfl
    · exact ri
    · exact rj
    · exact rk
    · exact rl
  apply OMA.Green147GapThreeCore.GapFive26.shifted_forces_progression _ (13*h-26) (by omega)
  intro x hx
  have e : x = 26 ∨ x = 28 ∨ x = 92 ∨ x = 94 := by simpa using hx
  rcases e with rfl | rfl | rfl | rfl
  · rw [show 13*h-26+26 = 13*h by omega]
    simpa using ri
  · rw [show 13*h-26+28 = 13*h+2 by omega]
    simpa using rk
  · rw [show 13*h-26+92 = 13*(h+5)+1 by omega]
    simpa using rj
  · rw [show 13*h-26+94 = 13*(h+5)+3 by omega]
    simpa using rl

def RemainingAlternating : Prop :=
  ∀ (R : Finset ℕ) (i j : Fin 13),
    (∀ x ∈ R, ∀ y ∈ R, ∀ z ∈ R, x + z = 2*y → x = z) →
    (∀ a d : ℕ, 0 < d → d ≤ 12 → a + 12*d < 160 →
      ∃ t : Fin 13, a + t.val*d ∈ R) →
    13*i.val ∈ R → 13*j.val + 1 ∈ R → 13*i.val + 2 ∈ R → 13*j.val + 3 ∈ R →
    i.val + 4 < j.val → i.val + j.val ≤ 12 →
    (i.val ≤ 1 ∨ i.val + 5 < j.val) → False

theorem h3_iff_remaining_alternating_and_nonalternating :
    OMA.R_Green14_W_3_13_R2.H3 ↔ RemainingAlternating ∧ Nonalternating := by
  rw [OMA.GreenR2GapFourEdges.h3_iff_gap_at_least_five_and_nonalternating]
  constructor
  · rintro ⟨wide, nonAlt⟩
    exact ⟨fun R i j hno hhit hi hj hk hl hgap hnorm _ =>
      wide R i j hno hhit hi hj hk hl hgap hnorm, nonAlt⟩
  · rintro ⟨remaining, nonAlt⟩
    refine ⟨?_, nonAlt⟩
    intro R i j hno hhit hi hj hk hl hgap hnorm
    by_cases hcase : i.val ≤ 1 ∨ i.val + 5 < j.val
    · exact remaining R i j hno hhit hi hj hk hl hgap hnorm hcase
    · have hfive : j.val = i.val + 5 := by omega
      let S (x : ℕ) : Prop := x ∈ R
      let : DecidablePred S := fun a => inferInstanceAs (Decidable (a ∈ R))
      have noTriple (x y z : ℕ) (hx : S x) (hy : S y) (hz : S z) (he : x+z=2*y) :
          x = z := hno x hx y hy z hz he
      exact gap_five_heights_two_three S i.val (by omega) (by omega) noTriple hhit hi
        (by rw [hfive] at hj; exact hj) hk (by rw [hfive] at hl; exact hl)

end OMA.GreenR2GapFive

#print axioms OMA.GreenR2GapFive.gap_five_heights_two_three
#print axioms OMA.GreenR2GapFive.h3_iff_remaining_alternating_and_nonalternating
