"""Check axiom outputs and replay files for the new window and literal H3 bridge."""
from pathlib import Path
import json
import re

dag = json.loads(Path('dag.json').read_text())
for module in [*dag, 'H3AfterCentralGapFive']:
    source = Path(f'{module}.lean')
    output = Path(f'{module}.olean')
    assert output.is_file() and output.stat().st_mtime_ns >= source.stat().st_mtime_ns, module
print(f'Checked {len(dag)} current DAG outputs and the H3 bridge')

names = {
    'Green147GapFive26.log': {
        'OMA.Green147GapThreeCore.GapFive26.shifted_forces_progression',
        'OMA.Green147GapThreeCore.GapFive26.reflected_shifted_forces_progression',
    },
    'H3AfterCentralGapFive.log': {
        'OMA.GreenR2GapFive.gap_five_heights_two_three',
        'OMA.GreenR2GapFive.h3_iff_remaining_alternating_and_nonalternating',
    },
}
allowed = {'propext', 'Classical.choice', 'Quot.sound'}
for logfile, expected in names.items():
    audits = re.findall(r"'([^']+)' depends on axioms: \[([^\]]*)\]", Path(logfile).read_text())
    assert {name for name, _ in audits} == expected, logfile
    for name, axioms in audits:
        assert set(map(str.strip, axioms.split(','))) <= allowed, (name, axioms)
print('Axiom audit passed')
