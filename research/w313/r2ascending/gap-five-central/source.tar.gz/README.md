# W(3,13) R2.H3 gap-five window

The seed `[26, 28, 92, 94]` in a 147-point window excludes the normalized alternating tuples `(2,7,2,7)` and `(3,8,3,8)`. Offsets 0 and 13 place the seed at those heights in the 160-point board. The final bridge imports the checked gap-four reduction and states the exact literal H3 equivalence with these two tuples removed.

Run `./finish.sh` with the pinned Lean 4.33.1 workspace and the prior gap-two, gap-three, gap-four, and edge replay outputs at the paths set in the script. The replay checks one certificate shard at a time and resumes from existing outputs.

To regenerate in an empty directory, copy `generate.py`, `repartition.py`, and `search-gap4.cpp` there and run the following.

```sh
g++ -std=c++17 -O3 -o search-gap4 search-gap4.cpp
python generate.py ./search-gap4 147 26 5
python repartition.py .
```

The generator emits 576 certificate fragments from 88,767 search nodes. The resulting DAG has 41 modules. The checked theorem establishes the window result using the emitted fragments and kernel evaluation.
