#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
root=/workspace/scratch/6893ca6bed01
lean="$root/open-math-agents/.oma/elan/toolchains/leanprover--lean4---v4.33.1/bin/lean"
"$lean" --version
python -u replay.py
export LEAN_PATH="$PWD:/tmp/w313-endpoint-bridge:/tmp/w313gap4edge/endpoint:/tmp/w313-2118.NrZlu6:/tmp/w313gap4:/tmp/w313gap3:/tmp/w313nov28:$root/parallel/ramsey/focused:$(cat "$root/parallel/pell/lean-path.txt")"
"$lean" -j1 -o H3AfterCentralGapFive.olean H3AfterCentralGapFive.lean 2>&1 | tee H3AfterCentralGapFive.log
python audit-axioms.py
