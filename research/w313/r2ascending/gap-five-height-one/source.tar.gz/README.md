# W(3,13) R2.H3 gap-five height one

The seed `[13, 15, 79, 81]` in a 147-point window excludes the normalized alternating tuple `(1,6,1,6)`. The final bridge imports the checked gap-five reduction for heights two and three and states the literal H3 equivalence with height one removed as well.

Run `./finish.sh` with the pinned Lean 4.33.1 workspace and prior certificate builds at the paths set in the script. The replay resumes from existing outputs and checks one certificate shard at a time.

To regenerate in an empty directory, copy `generate.py`, `repartition.py`, and `search-gap4.cpp` there and run the following.

```sh
g++ -std=c++17 -O3 -o search-gap4 search-gap4.cpp
python generate.py ./search-gap4 147 13 8
python repartition.py .
```

The generator emits 693 certificate fragments from 105,389 search nodes. The resulting DAG has 51 modules. The Lean window theorem assembles the fragments using kernel evaluation.
