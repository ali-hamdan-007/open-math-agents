import H3AfterCentralGapFive
import Green147GapFive13

namespace OMA.GreenR2GapFiveInterior

open OMA.GreenR2GapTwo (Nonalternating)

theorem gap_five_height_one (R : Nat → Prop) [DecidablePred R]
    (noTriple : ∀ x y z, R x → R y → R z → x+z=2*y → x=z)
    (hit : ∀ a d : Nat, 0<d → d≤12 → a+12*d<160 → ∃ t : Fin 13, R (a+t.val*d))
    (ri : R 13) (rj : R 79) (rk : R 15) (rl : R 81) : False := by
  apply OMA.GreenR2Premises.impossible_of_mono R 1 6 1 6 noTriple hit
  · intro x hx
    have e : x = 13 ∨ x = 79 ∨ x = 15 ∨ x = 81 := by
      change x ∈ [13, 79, 15, 81] at hx
      simpa using hx
    rcases e with rfl | rfl | rfl | rfl
    · exact ri
    · exact rj
    · exact rk
    · exact rl
  apply OMA.Green147GapThreeCore.GapFive13.shifted_forces_progression _ 0 (by decide)
  intro x hx
  have e : x = 13 ∨ x = 15 ∨ x = 79 ∨ x = 81 := by simpa using hx
  rcases e with rfl | rfl | rfl | rfl
  · simpa using ri
  · simpa using rk
  · simpa using rj
  · simpa using rl

def RemainingAlternating : Prop :=
  ∀ (R : Finset ℕ) (i j : Fin 13),
    (∀ x ∈ R, ∀ y ∈ R, ∀ z ∈ R, x + z = 2*y → x = z) →
    (∀ a d : ℕ, 0 < d → d ≤ 12 → a + 12*d < 160 →
      ∃ t : Fin 13, a + t.val*d ∈ R) →
    13*i.val ∈ R → 13*j.val + 1 ∈ R → 13*i.val + 2 ∈ R → 13*j.val + 3 ∈ R →
    i.val + 4 < j.val → i.val + j.val ≤ 12 →
    (i.val = 0 ∨ i.val + 5 < j.val) → False

theorem h3_iff_remaining_alternating_and_nonalternating :
    OMA.R_Green14_W_3_13_R2.H3 ↔ RemainingAlternating ∧ Nonalternating := by
  rw [OMA.GreenR2GapFive.h3_iff_remaining_alternating_and_nonalternating]
  constructor
  · rintro ⟨wide, nonAlt⟩
    refine ⟨?_, nonAlt⟩
    intro R i j hno hhit hi hj hk hl hgap hnorm hcase
    exact wide R i j hno hhit hi hj hk hl hgap hnorm (by omega)
  · rintro ⟨remaining, nonAlt⟩
    refine ⟨?_, nonAlt⟩
    intro R i j hno hhit hi hj hk hl hgap hnorm hcase
    by_cases hnew : i.val = 0 ∨ i.val + 5 < j.val
    · exact remaining R i j hno hhit hi hj hk hl hgap hnorm hnew
    · have hiOne : i.val = 1 := by omega
      have hjSix : j.val = 6 := by omega
      let S (x : ℕ) : Prop := x ∈ R
      let : DecidablePred S := fun a => inferInstanceAs (Decidable (a ∈ R))
      have noTriple (x y z : ℕ) (hx : S x) (hy : S y) (hz : S z) (he : x+z=2*y) :
          x = z := hno x hx y hy z hz he
      exact gap_five_height_one S noTriple hhit
        (by simpa [hiOne] using hi) (by simpa [hjSix] using hj)
        (by simpa [hiOne] using hk) (by simpa [hjSix] using hl)

end OMA.GreenR2GapFiveInterior

#print axioms OMA.GreenR2GapFiveInterior.gap_five_height_one
#print axioms OMA.GreenR2GapFiveInterior.h3_iff_remaining_alternating_and_nonalternating
