"""Build only missing pinned project and Mathlib geometry dependencies."""
from pathlib import Path
import os
import re
import subprocess

here = Path(__file__).resolve().parent
repo = Path(os.environ.get("OMA_REPO", here.parent.parent))
if not (repo / ".oma/formal-conjectures").exists():
    repo /= "open-math-agents"
fc = (repo / ".oma/formal-conjectures").resolve()
mathlib = fc / ".lake/packages/mathlib"
mathcache = mathlib / ".lake/build/lib/lean"

def build(module: Path):
    if module.parts[0] == "Mathlib":
        root = mathlib
        cache = mathcache
    elif module.parts[0] == "FormalConjecturesForMathlib":
        root = fc
        cache = here
    else:
        raise ValueError(module)

    target = cache / module.with_suffix(".olean")
    if target.exists():
        return
    target.parent.mkdir(parents=True, exist_ok=True)
    current = set()
    while True:
        result = subprocess.run([str(here / "check.sh"), f"--root={root}", "-o",
                                 str(target), str(root / module.with_suffix(".lean"))],
                                text=True, capture_output=True)
        if result.returncode == 0:
            print(f"Built {module}", flush=True)
            return
        missing = re.search(r"object file '([^']+\.olean)'", result.stdout + result.stderr)
        if not missing:
            raise RuntimeError(result.stdout + result.stderr)
        path = Path(missing[1])
        source = None
        for prefix in (mathcache, here):
            if path.is_relative_to(prefix):
                source = path.relative_to(prefix).with_suffix("")
                break
        if source is None or source in current:
            raise RuntimeError(result.stdout + result.stderr)
        current.add(source)
        build(source)

for name in ("Data/Sym/Sym2", "Geometry/Metric", "Logic/Equiv/Fin/Rotate", "Data/Set/Triplewise", "Geometry/2d"):
    build(Path("FormalConjecturesForMathlib") / name)
