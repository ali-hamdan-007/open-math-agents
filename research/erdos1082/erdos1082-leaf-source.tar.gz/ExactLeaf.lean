import Assembly123
import ExactLeafGeometry

namespace Erdos1082

/-- The two five-point base codes allowed by H2 of reduction #5040
cannot occur in a ten-point four-distance set. -/
theorem actualLeaf : ExpectedH2 :=
  exactGeomLeaf verified123

end Erdos1082

#print axioms Erdos1082.actualLeaf
