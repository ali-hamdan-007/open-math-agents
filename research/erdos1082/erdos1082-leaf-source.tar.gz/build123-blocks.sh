#!/usr/bin/env bash
set -eu
cd "$(dirname "$0")"
for ((i = 0; i < 32; i++)); do
  printf -v name 'Check123Block%02d' "$i"
  cat >"$name.lean" <<LEAN
import Cover123
namespace Erdos1082
set_option maxRecDepth 100000
set_option maxHeartbeats 0
theorem checked123_$i : checkBlock123 true $((32*i)) 32 = true := by
  decide +kernel
end Erdos1082
LEAN
  if [[ ! -f "$name.olean" ]]; then
    ./check.sh -o "$name.olean" "$name.lean"
    printf 'Checked %s\n' "$name"
  fi
done
