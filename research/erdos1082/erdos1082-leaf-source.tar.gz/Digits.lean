import Bounds

namespace Erdos1082

def baseCode (c : Fin 10 → Fin 3) : ℕ :=
  (c 0).val*19683 + (c 1).val*6561 + (c 2).val*2187 + (c 3).val*729 +
  (c 4).val*243 + (c 5).val*81 + (c 6).val*27 + (c 7).val*9 +
  (c 8).val*3 + (c 9).val

theorem digits (c : Fin 10 → Fin 3) (h : baseCode c = 123 ∨ baseCode c = 157) :
    c 0 = 0 ∧ c 1 = 0 ∧ c 2 = 0 ∧ c 3 = 0 ∧ c 4 = 0 ∧ c 5 = 1 ∧
      ((baseCode c = 123 ∧ c 6 = 1 ∧ c 7 = 1 ∧ c 8 = 2 ∧ c 9 = 0) ∨
       (baseCode c = 157 ∧ c 6 = 2 ∧ c 7 = 2 ∧ c 8 = 1 ∧ c 9 = 1)) := by
  have h0 := (c 0).isLt
  have h1 := (c 1).isLt
  have h2 := (c 2).isLt
  have h3 := (c 3).isLt
  have h4 := (c 4).isLt
  have h5 := (c 5).isLt
  have h6 := (c 6).isLt
  have h7 := (c 7).isLt
  have h8 := (c 8).isLt
  have h9 := (c 9).isLt
  have hc := h
  unfold baseCode at h
  have leCode : baseCode c < 162 := by unfold baseCode; omega
  have e0 : (c 0).val = 0 := by omega
  have e1 : (c 1).val = 0 := by omega
  have e2 : (c 2).val = 0 := by omega
  have e3 : (c 3).val = 0 := by omega
  have e4 : (c 4).val = 0 := by omega
  have e5 : (c 5).val = 1 := by omega
  refine ⟨Fin.ext e0, Fin.ext e1, Fin.ext e2, Fin.ext e3, Fin.ext e4, Fin.ext e5, ?_⟩
  rcases hc with hp | hp
  · left
    have hf := hp
    unfold baseCode at hf
    refine ⟨hp, Fin.ext ?_, Fin.ext ?_, Fin.ext ?_, Fin.ext ?_⟩ <;> omega
  · right
    have hf := hp
    unfold baseCode at hf
    refine ⟨hp, Fin.ext ?_, Fin.ext ?_, Fin.ext ?_, Fin.ext ?_⟩ <;> omega

end Erdos1082
