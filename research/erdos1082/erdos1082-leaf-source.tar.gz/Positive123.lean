import Transport123

namespace Erdos1082

def mirror (p : ℝ × ℝ) : ℝ × ℝ := (-p.1,p.2)

theorem mirror_dist (p q : ℝ × ℝ) : distanceSq (mirror p) (mirror q) = distanceSq p q := by
  simp only [distanceSq, mirror]
  ring

theorem mirror_injective : Function.Injective mirror := by
  intro p q h
  exact Prod.ext (neg_inj.mp (congrArg Prod.fst h)) (show (mirror p).2 = (mirror q).2 from congrArg Prod.snd h)

theorem transportPositive123 (p₀ p₁ p₂ p₃ p₄ : ℝ × ℝ) (r : ℝ) (hr : r ≠ 0)
    (h1 : distanceSq p₁ p₀ = r^2) (h2 : distanceSq p₂ p₀ = r^2)
    (h3 : distanceSq p₃ p₀ = r^2) (h4 : distanceSq p₄ p₀ = r^2)
    (h12 : distanceSq p₁ p₂ = r^2)
    (ha : distanceSq p₃ p₁ = distanceSq p₃ p₂)
    (hb : distanceSq p₃ p₁ = distanceSq p₄ p₁)
    (hc : distanceSq p₃ p₄ = r^2) :
    ∃ (f : (ℝ × ℝ) → ℝ × ℝ) (s z : ℝ), Function.Injective f ∧
      (∀ p q, distanceSq (f p) (f q) = distanceSq p q / r^2) ∧
      s^2 = 3 ∧ z^3 = 3*z+1 ∧
      f p₀ = (0,0) ∧ f p₁ = (s/2,-1/2) ∧ f p₂ = (s/2,1/2) ∧
      f p₃ = Point.eval (form123 true).1 s z ∧ f p₄ = Point.eval (form123 true).2 s z := by
  obtain ⟨f,s,z,positive,hfi,hfd,hs,hz,hf0,hf1,hf2,hf3,hf4⟩ :=
    transport123 p₀ p₁ p₂ p₃ p₄ r hr h1 h2 h3 h4 h12 ha hb hc
  cases positive
  · have hs' : (-s)^2 = 3 := by simpa using hs
    have hS (a : ℝ) : sqrtThree.eval a z = a := by simp [sqrtThree, Radical.eval]
    refine ⟨mirror ∘ f, -s, z, mirror_injective.comp hfi, ?_, hs', hz, ?_, ?_, ?_, ?_, ?_⟩
    · intro p q
      exact (mirror_dist _ _).trans (hfd p q)
    · simp [hf0, mirror]
    · simp [hf1, mirror, neg_div]
    · simp [hf2, mirror, neg_div]
    · simp [hf3, mirror, Point.eval, form123, rc]
    · simp [hf4, mirror, Point.eval, form123, Radical.eval_mul, hs, hs', hz, hS, rc]
  · exact ⟨f,s,z,hfi,hfd,hs,hz,hf0,hf1,hf2,hf3,hf4⟩

end Erdos1082

#print axioms Erdos1082.transportPositive123
