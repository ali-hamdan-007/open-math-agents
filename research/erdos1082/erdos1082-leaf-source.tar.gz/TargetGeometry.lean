import ExtensionBound123
import Code157
import Digits
import FormalConjecturesForMathlib.Geometry.Metric
import Mathlib.Analysis.InnerProductSpace.PiL2
import Mathlib.Tactic.FinCases

namespace Erdos1082
open Finset

abbrev Plane := EuclideanSpace ℝ (Fin 2)

def coords (p : Plane) : ℝ × ℝ := (p 0,p 1)

theorem coords_inj : Function.Injective coords := by
  intro p q h
  apply PiLp.ext
  intro i
  fin_cases i
  · exact congrArg Prod.fst h
  · exact congrArg Prod.snd h

theorem coords_dist (p q : Plane) : distanceSq (coords p) (coords q) = dist p q ^ 2 := by
  rw [EuclideanSpace.dist_sq_eq, Fin.sum_univ_two]
  simp [distanceSq, coords, Real.dist_eq, sq_abs]

theorem distance_mem {A : Finset Plane} {p q : Plane} (hp : p ∈ A) (hq : q ∈ A)
    (hne : p ≠ q) : dist p q ∈ distanceSet A := by
  classical
  exact mem_image.mpr ⟨(p,q), mem_offDiag.mpr ⟨hp,hq,hne⟩, rfl⟩

theorem distance_subset {A B : Finset Plane} (hBA : B ⊆ A) : distanceSet B ⊆ distanceSet A := by
  classical
  intro d hd
  obtain ⟨⟨p,q⟩,hp,rfl⟩ := mem_image.mp hd
  obtain ⟨hp,hq,hne⟩ := mem_offDiag.mp hp
  exact distance_mem (hBA hp) (hBA hq) hne

theorem distance_elim {A : Finset Plane} {d : ℝ} (hd : d ∈ distanceSet A) :
    ∃ p ∈ A, ∃ q ∈ A, p ≠ q ∧ d = dist p q := by
  classical
  obtain ⟨⟨p,q⟩, hp, rfl⟩ := mem_image.mp hd
  obtain ⟨hp,hq,hne⟩ := mem_offDiag.mp hp
  exact ⟨p,hp,q,hq,hne,rfl⟩

theorem twoCases
    (verified : ∀ n < 1024, check (form123 true) (small123 true) n = some (expected123 true n))
    (A : Finset Plane) (hA : A.card = 10) (hd : distinctDistances A = 4)
    (M : ℝ) (hM : M ∈ distanceSet A) (B : Finset Plane) (hBA : B ⊆ A)
    (hB : B.card = 5) (hf : ∀ a ∈ B, ∀ b ∈ B, dist a b < M)
    (p : Fin 5 ≃ B) (r : Fin 3 ≃ distanceSet B) (c : Fin 10 → Fin 3)
    (hc : let e : Fin 10 → Fin 5 × Fin 5 :=
      ![(0,1),(0,2),(0,3),(0,4),(1,2),(1,3),(1,4),(2,3),(2,4),(3,4)];
      ∀ k, dist (p (e k).1).1 (p (e k).2).1 = (r (c k)).1)
    (hcode : baseCode c ∈ ([157,123] : List ℕ)) : False := by
  classical
  let P (i : Fin 5) := (p i).1
  let R (i : Fin 3) := (r i).1
  let X := (A \ B).image coords
  have hX : X.card = 5 := by
    dsimp [X]
    rw [card_image_of_injective _ coords_inj, card_sdiff_of_subset hBA, hA,hB]
  have hBrange : distanceSet B = {R 0,R 1,R 2} := by
    ext d
    constructor
    · intro h
      obtain ⟨k,hk⟩ := r.surjective ⟨d,h⟩
      have he : R k = d := congrArg Subtype.val hk
      rw [← he]
      fin_cases k <;> simp
    · simp only [mem_insert, mem_singleton]
      rintro (rfl | rfl | rfl) <;> exact (r _).2
  have hMB : M ∉ distanceSet B := by
    intro he
    obtain ⟨a,ha,b,hb,_,hab⟩ := distance_elim he
    exact (not_lt_of_ge hab.le) (hf a ha b hb)
  have hArange : distanceSet A = insert M (distanceSet B) := by
    symm
    apply eq_of_subset_of_card_le
    · exact insert_subset hM (distance_subset hBA)
    · rw [card_insert_of_notMem hMB]
      change distinctDistances A ≤ distinctDistances B + 1
      have hcard := Fintype.card_congr r
      simp only [Fintype.card_fin, Fintype.card_coe] at hcard
      exact hd.trans_le (by change 4 ≤ (distanceSet B).card + 1; omega)
  have hR0 : R 0 ≠ 0 := by
    obtain ⟨a,_,b,_,hne,he⟩ := distance_elim (r 0).2
    change (r 0).1 ≠ 0
    rw [he]
    exact dist_ne_zero.mpr hne
  have hRM (i : Fin 3) : R i < M := by
    obtain ⟨a,ha,b,hb,_,he⟩ := distance_elim (r i).2
    change (r i).1 < M
    rw [he]
    exact hf a ha b hb
  have hSqM : M^2 ∉ ([R 0 ^ 2, R 1 ^ 2, R 2 ^ 2] : List ℝ) := by
    have hnon (i : Fin 3) : 0 ≤ R i := by
      obtain ⟨a,_,b,_,_,he⟩ := distance_elim (r i).2
      change 0 ≤ (r i).1
      rw [he]; positivity
    simp only [List.mem_cons, List.not_mem_nil, or_false, not_or]
    refine ⟨?_, ?_, ?_⟩ <;>
      intro he <;>
      nlinarith [hRM 0,hRM 1,hRM 2,hnon 0,hnon 1,hnon 2]
  have hdistX : ∀ x ∈ X, ∀ y ∈ [(coords (P 0)),coords (P 1),coords (P 2),coords (P 3),coords (P 4)],
      x ≠ y ∧ distanceSq x y ∈ [R 0^2,R 1^2,R 2^2,M^2] := by
    intro x hx y hy
    obtain ⟨a,ha,rfl⟩ := mem_image.mp hx
    have hyl : y ∈ ([P 0,P 1,P 2,P 3,P 4] : List Plane).map coords := by simpa using hy
    obtain ⟨b,hb,rfl⟩ := List.mem_map.mp hyl
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hb
    have hb' : b ∈ B := by rcases hb with rfl|rfl|rfl|rfl|rfl <;> exact (p _).2
    obtain ⟨haA,haB⟩ := mem_sdiff.mp ha
    have hab : a ≠ b := fun h => haB (h ▸ hb')
    refine ⟨coords_inj.ne hab, ?_⟩
    have he := distance_mem haA (hBA hb') hab
    rw [hArange,hBrange] at he
    simp only [mem_insert,mem_singleton] at he
    rw [coords_dist]
    rcases he with he|he|he|he <;> simp [he]
  have hcode' : baseCode c = 123 ∨ baseCode c = 157 := by simpa [or_comm] using hcode
  obtain ⟨e0,e1,e2,e3,e4,e5,branch⟩ := digits c hcode'
  have d01 : distanceSq (coords (P 1)) (coords (P 0)) = R 0^2 := by
    rw [coords_dist,dist_comm]; simpa [P,R,e0] using congrArg (·^2) (hc 0)
  have d02 : distanceSq (coords (P 2)) (coords (P 0)) = R 0^2 := by
    rw [coords_dist,dist_comm]; simpa [P,R,e1] using congrArg (·^2) (hc 1)
  have d03 : distanceSq (coords (P 3)) (coords (P 0)) = R 0^2 := by
    rw [coords_dist,dist_comm]; simpa [P,R,e2] using congrArg (·^2) (hc 2)
  have d04 : distanceSq (coords (P 4)) (coords (P 0)) = R 0^2 := by
    rw [coords_dist,dist_comm]; simpa [P,R,e3] using congrArg (·^2) (hc 3)
  have d12 : distanceSq (coords (P 1)) (coords (P 2)) = R 0^2 := by
    rw [coords_dist]; simpa [P,R,e4] using congrArg (·^2) (hc 4)
  have d13 : distanceSq (coords (P 3)) (coords (P 1)) = R 1^2 := by
    rw [coords_dist,dist_comm]; simpa [P,R,e5] using congrArg (·^2) (hc 5)
  rcases branch with ⟨_,e6,e7,e8,e9⟩ | ⟨_,e6,e7,e8,e9⟩
  · have d14 : distanceSq (coords (P 4)) (coords (P 1)) = R 1^2 := by
      rw [coords_dist,dist_comm]; simpa [P,R,e6] using congrArg (·^2) (hc 6)
    have d23 : distanceSq (coords (P 3)) (coords (P 2)) = R 1^2 := by
      rw [coords_dist,dist_comm]; simpa [P,R,e7] using congrArg (·^2) (hc 7)
    have d24 : distanceSq (coords (P 4)) (coords (P 2)) = R 2^2 := by
      rw [coords_dist,dist_comm]; simpa [P,R,e8] using congrArg (·^2) (hc 8)
    have d34 : distanceSq (coords (P 3)) (coords (P 4)) = R 0^2 := by
      rw [coords_dist]; simpa [P,R,e9] using congrArg (·^2) (hc 9)
    have hh := excludeExtensions123 verified (coords (P 0)) (coords (P 1)) (coords (P 2))
      (coords (P 3)) (coords (P 4)) (R 0) (M^2) hR0 d01 d02 d03 d04 d12
      (d13.trans d23.symm) (d13.trans d14.symm) d34
      (by rw [d13,d24]; exact hSqM) X (by rw [d13,d24]; exact hdistX)
    omega
  · have d14 : distanceSq (coords (P 4)) (coords (P 1)) = R 2^2 := by
      rw [coords_dist,dist_comm]; simpa [P,R,e6] using congrArg (·^2) (hc 6)
    have d23 : distanceSq (coords (P 3)) (coords (P 2)) = R 2^2 := by
      rw [coords_dist,dist_comm]; simpa [P,R,e7] using congrArg (·^2) (hc 7)
    have d24 : distanceSq (coords (P 4)) (coords (P 2)) = R 1^2 := by
      rw [coords_dist,dist_comm]; simpa [P,R,e8] using congrArg (·^2) (hc 8)
    have d34 : distanceSq (coords (P 3)) (coords (P 4)) = R 1^2 := by
      rw [coords_dist]; simpa [P,R,e9] using congrArg (·^2) (hc 9)
    have hne : coords (P 3) ≠ coords (P 2) := by
      intro he
      have hEq : p 3 = p 2 := Subtype.ext (coords_inj he)
      exact (by decide : (3 : Fin 5) ≠ 2) (p.injective hEq)
    have hh := code157_bound (coords (P 0)) (coords (P 1)) (coords (P 2))
      (coords (P 3)) (coords (P 4)) (R 0) (M^2) hR0 d01 d02 d03 d04 d12
      (d13.trans d24.symm) (d23.trans d14.symm) (d13.trans d34.symm) hne
      (by rw [d13,d14]; exact hSqM) X (by rw [d13,d14]; exact hdistX)
    omega

end Erdos1082

#print axioms Erdos1082.twoCases
