import Check123Block00
import Check123Block01
import Check123Block02
import Check123Block03
import Check123Block04
import Check123Block05
import Check123Block06
import Check123Block07
import Check123Block08
import Check123Block09
import Check123Block10
import Check123Block11
import Check123Block12
import Check123Block13
import Check123Block14
import Check123Block15
import Check123Block16
import Check123Block17
import Check123Block18
import Check123Block19
import Check123Block20
import Check123Block21
import Check123Block22
import Check123Block23
import Check123Block24
import Check123Block25
import Check123Block26
import Check123Block27
import Check123Block28
import Check123Block29
import Check123Block30
import Check123Block31
import Mathlib.Tactic.IntervalCases
namespace Erdos1082

theorem verified123 (n : ℕ) (hn : n < 1024) :
    check (form123 true) (small123 true) n = some (expected123 true n) := by
  let b := n / 32
  have hb : b < 32 := by dsimp [b]; omega
  have table (j : ℕ) (hj : j < 32) : checkBlock123 true (32*j) 32 = true := by
    interval_cases j
    · exact checked123_0
    · exact checked123_1
    · exact checked123_2
    · exact checked123_3
    · exact checked123_4
    · exact checked123_5
    · exact checked123_6
    · exact checked123_7
    · exact checked123_8
    · exact checked123_9
    · exact checked123_10
    · exact checked123_11
    · exact checked123_12
    · exact checked123_13
    · exact checked123_14
    · exact checked123_15
    · exact checked123_16
    · exact checked123_17
    · exact checked123_18
    · exact checked123_19
    · exact checked123_20
    · exact checked123_21
    · exact checked123_22
    · exact checked123_23
    · exact checked123_24
    · exact checked123_25
    · exact checked123_26
    · exact checked123_27
    · exact checked123_28
    · exact checked123_29
    · exact checked123_30
    · exact checked123_31
  have hh : checkBlock123 true (32*b) 32 = true := table b hb
  have he : 32*b + n%32 = n := by dsimp [b]; omega
  simpa only [he] using checkedBlock123 hh (show n%32 < 32 by omega)

end Erdos1082

#print axioms Erdos1082.verified123
