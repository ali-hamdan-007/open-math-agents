#!/usr/bin/env bash
set -eu
cd "$(dirname "$0")"
./build157.sh --resume
python build_geometry_dependencies.py
for name in Normalize123 Transport123 Positive123 CandidateCount Rows123 Cover123 ExtensionBound123 Digits TargetGeometry ExactLeafGeometry; do
  if [[ ! -f "$name.olean" ]]; then
    ./check.sh -o "$name.olean" "$name.lean"
  fi
done
./build123-blocks.sh
./check.sh -o Assembly123.olean Assembly123.lean
./check.sh -o ExactLeaf.olean ExactLeaf.lean
