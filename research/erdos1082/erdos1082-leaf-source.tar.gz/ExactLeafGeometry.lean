import TargetGeometry
import FormalConjecturesForMathlib.Geometry.«2d»

namespace Erdos1082
open EuclideanGeometry

/-- The statement of H2 in the merged reduction #5040. -/
def ExpectedH2 : Prop := ∀ A : Finset ℝ², NonTrilinear (A:Set ℝ²) → A.card=10 → distinctDistances A=4 →
    ∀ M∈distanceSet A, ∀ B⊆A, B.card=5 → (∀ a∈B, ∀ b∈B, dist a b<M) → distinctDistances B=3 → ∀ (p : Fin 5≃B) (r : Fin 3≃(distanceSet B)) (c : Fin 10→Fin 3),
    (let e : Fin 10→Fin 5×Fin 5 := ![(0,1),(0,2),(0,3),(0,4),(1,2),(1,3),(1,4),(2,3),(2,4),(3,4)]; ∀ k, dist (p (e k).1).1 (p (e k).2).1=(r (c k)).1) →
    ((c 0).val*19683 + (c 1).val*6561 + (c 2).val*2187 + (c 3).val*729 + (c 4).val*243 + (c 5).val*81 + (c 6).val*27 + (c 7).val*9 + (c 8).val*3 + (c 9).val*1)∈([157,123]:List ℕ) → False

theorem exactGeomLeaf
    (verified : ∀ n < 1024, check (form123 true) (small123 true) n = some (expected123 true n)) :
    ExpectedH2 := by
  intro A _ hA hd M hM B hBA hB hf _ p r c hc hcode
  exact twoCases verified A hA hd M hM B hBA hB hf p r c hc (by simpa [baseCode] using hcode)

end Erdos1082

#print axioms Erdos1082.exactGeomLeaf
