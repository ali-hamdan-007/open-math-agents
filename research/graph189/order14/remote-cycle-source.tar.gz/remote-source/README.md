# Six vertices with four high-degree vertices

Every six-vertex simple graph of minimum degree at least two with at least four vertices of degree at least four has a Hamiltonian cycle. Removing an edge incident to a designated vertex gives a Hamiltonian path with that endpoint. The designated four-vertex version and the relabeling version appear in RemoteHamiltonian.lean and Relabeled.lean.

Use the project's Lean 4.33.1 and pinned Mathlib environment. With lean on PATH and the Mathlib build in LEAN_PATH, run ./rebuild.sh. The 36 generated blocks are included so that reproducing the proof does not require Python. The CycleTable witness list is checked in Lean's kernel. The assembly and graph interpretation were checked with only propext, Classical.choice and Quot.sound.
