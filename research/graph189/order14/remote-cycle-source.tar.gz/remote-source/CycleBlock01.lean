import CycleCheck
namespace Ali189.RemoteCycle
set_option maxRecDepth 10000 in
set_option maxHeartbeats 0 in
theorem checked1 : block 1 = true := by decide +kernel
end Ali189.RemoteCycle
