import CycleCheck
namespace Ali189.RemoteCycle
set_option maxRecDepth 10000 in
set_option maxHeartbeats 0 in
theorem checked30 : block 30 = true := by decide +kernel
end Ali189.RemoteCycle
