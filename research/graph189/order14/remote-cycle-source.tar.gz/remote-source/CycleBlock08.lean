import CycleCheck
namespace Ali189.RemoteCycle
set_option maxRecDepth 10000 in
set_option maxHeartbeats 0 in
theorem checked8 : block 8 = true := by decide +kernel
end Ali189.RemoteCycle
