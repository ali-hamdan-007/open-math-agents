#!/usr/bin/env bash
set -eu
cd "$(dirname "$0")"
export LEAN_PATH="$PWD:${LEAN_PATH:-}"
for module in CycleTable CycleCheck CycleSound WalkConversions CycleBlock{00..35} RemoteCycle RemoteHamiltonian Relabeled; do
  lean -DwarningAsError=true -o "$module.olean" "$module.lean"
done
