import CycleSound
import CycleBlock00
import CycleBlock01
import CycleBlock02
import CycleBlock03
import CycleBlock04
import CycleBlock05
import CycleBlock06
import CycleBlock07
import CycleBlock08
import CycleBlock09
import CycleBlock10
import CycleBlock11
import CycleBlock12
import CycleBlock13
import CycleBlock14
import CycleBlock15
import CycleBlock16
import CycleBlock17
import CycleBlock18
import CycleBlock19
import CycleBlock20
import CycleBlock21
import CycleBlock22
import CycleBlock23
import CycleBlock24
import CycleBlock25
import CycleBlock26
import CycleBlock27
import CycleBlock28
import CycleBlock29
import CycleBlock30
import CycleBlock31
import CycleBlock32
import CycleBlock33
import CycleBlock34
import CycleBlock35
import Mathlib.Tactic.IntervalCases

namespace Ali189.RemoteCycle

theorem verified (k : Nat) (hk : k < 2592) : check k = true := by
  let b := k / 72
  have hb : b < 36 := by dsimp [b]; omega
  have table (i : Nat) (hi : i < 36) : block i = true := by
    interval_cases i
    · exact checked0
    · exact checked1
    · exact checked2
    · exact checked3
    · exact checked4
    · exact checked5
    · exact checked6
    · exact checked7
    · exact checked8
    · exact checked9
    · exact checked10
    · exact checked11
    · exact checked12
    · exact checked13
    · exact checked14
    · exact checked15
    · exact checked16
    · exact checked17
    · exact checked18
    · exact checked19
    · exact checked20
    · exact checked21
    · exact checked22
    · exact checked23
    · exact checked24
    · exact checked25
    · exact checked26
    · exact checked27
    · exact checked28
    · exact checked29
    · exact checked30
    · exact checked31
    · exact checked32
    · exact checked33
    · exact checked34
    · exact checked35
  have hb' := table b hb
  have hm : k % 72 < 72 := by omega
  have hcheck := List.all_eq_true.mp hb' (k%72) (List.mem_range.mpr hm)
  have heq : 72*b+k%72 = k := by dsimp [b]; omega
  simpa only [heq] using hcheck

/-- A six-vertex graph of minimum degree two with four designated vertices
of degree at least four has a cyclic Hamiltonian ordering. -/
theorem six_vertex_cycle (G : SimpleGraph V) [DecidableRel G.Adj]
    (minDeg : ∀ u, 2 ≤ G.degree u) (high : ∀ u : V, u.val < 4 → 4 ≤ G.degree u) :
    ∃ p : V ≃ V, ∀ u, G.Adj (p u) (p (u+1)) :=
  cycle_from_checks verified G minDeg high

end Ali189.RemoteCycle

#print axioms Ali189.RemoteCycle.six_vertex_cycle
