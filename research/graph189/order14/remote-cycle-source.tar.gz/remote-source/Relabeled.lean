import RemoteHamiltonian

namespace Ali189.RemoteCycle
open Finset

theorem relabeled_cycle {U : Type*} [Fintype U] [DecidableEq U] (G : SimpleGraph U)
    [DecidableRel G.Adj] (labels : V ≃ U)
    (minDeg : ∀ u, 2 ≤ G.degree u)
    (high : ∀ u : V, u.val < 4 → 4 ≤ G.degree (labels u)) :
    ∃ p : V ≃ U, ∀ u, G.Adj (p u) (p (u+1)) := by
  classical
  let H := G.comap labels
  have hdeg (u : V) : H.degree u = G.degree (labels u) := by
    have hmap : (H.neighborFinset u).map labels.toEmbedding = G.neighborFinset (labels u) := by
      ext v
      constructor
      · intro hv
        obtain ⟨w,hw,rfl⟩ := mem_map.mp hv
        exact (G.mem_neighborFinset _ _).mpr ((H.mem_neighborFinset _ _).mp hw)
      · intro hv
        refine mem_map.mpr ⟨labels.symm v, (H.mem_neighborFinset _ _).mpr ?_, labels.apply_symm_apply v⟩
        change G.Adj (labels u) (labels (labels.symm v))
        rw [labels.apply_symm_apply]
        exact (G.mem_neighborFinset _ _).mp hv
    simp only [SimpleGraph.degree]
    rw [← hmap, Finset.card_map]
  obtain ⟨p,hp⟩ := six_vertex_cycle H (fun u => hdeg u ▸ minDeg (labels u))
    (fun u hu => hdeg u ▸ high u hu)
  exact ⟨p.trans labels, hp⟩

end Ali189.RemoteCycle

#print axioms Ali189.RemoteCycle.relabeled_cycle

namespace Ali189.RemoteCycle

theorem relabeled_hamiltonian {U : Type*} [Fintype U] [DecidableEq U] (G : SimpleGraph U)
    [DecidableRel G.Adj] (labels : V ≃ U)
    (minDeg : ∀ u, 2 ≤ G.degree u)
    (high : ∀ u : V, u.val < 4 → 4 ≤ G.degree (labels u)) :
    G.IsHamiltonian := by
  obtain ⟨p,hp⟩ := relabeled_cycle G labels minDeg high
  exact cycle_order_to_hamiltonian G p hp

end Ali189.RemoteCycle

#print axioms Ali189.RemoteCycle.relabeled_hamiltonian
