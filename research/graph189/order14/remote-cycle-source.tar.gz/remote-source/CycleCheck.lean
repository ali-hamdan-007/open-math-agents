import CycleTable
import Mathlib.Data.Fintype.Basic
import Mathlib.Tactic.IntervalCases

namespace Ali189.RemoteCycle

abbrev V := Fin 6

def digit (n i : Nat) : V := ⟨n / 6^i % 6, Nat.mod_lt _ (by decide)⟩

def adjacency (k : Nat) (u v : V) : Bool :=
  if u = v then false
  else let a := min u.val v.val
       let b := max u.val v.val
       if a < 4 then (digit k a).val != b else decide (1296 ≤ k)

def count (k : Nat) (u : V) : Nat :=
  ((List.ofFn fun v : V => adjacency k u v).filter id).length

def degreeTests (k : Nat) : Bool :=
  (List.ofFn (fun u : V => decide ((if u.val < 4 then 4 else 2) ≤ count k u))).all id

def order (k : Nat) (u : V) : V := digit witnesses[k]! u.val

def cycleTests (k : Nat) : Bool :=
  (List.ofFn (fun u : V => (List.ofFn (fun v : V =>
    decide (order k u = order k v → u = v))).all id)).all id &&
  (List.ofFn (fun u : V => adjacency k (order k u) (order k (u+1)))).all id

def check (k : Nat) : Bool := !degreeTests k || cycleTests k

def block (b : Nat) : Bool := (List.range 72).all fun j => check (72*b+j)

end Ali189.RemoteCycle
