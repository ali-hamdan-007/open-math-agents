import CycleSound
import Mathlib.Combinatorics.SimpleGraph.Hamiltonian
import Mathlib.Tactic.FinCases

namespace Ali189.RemoteCycle

theorem cycle_order_to_hamiltonian {U : Type*} [Fintype U] [DecidableEq U]
    (G : SimpleGraph U) (p : V ≃ U)
    (h : ∀ i, G.Adj (p i) (p (i+1))) : G.IsHamiltonian := by
  intro _
  have e0 : G.Adj (p 0) (p 1) := h 0
  have e1 : G.Adj (p 1) (p 2) := h 1
  have e2 : G.Adj (p 2) (p 3) := h 2
  have e3 : G.Adj (p 3) (p 4) := h 3
  have e4 : G.Adj (p 4) (p 5) := h 4
  have e5 : G.Adj (p 5) (p 0) := h 5
  let w : G.Walk (p 0) (p 0) :=
    .cons e0 (.cons e1 (.cons e2 (.cons e3 (.cons e4 (.cons e5 .nil)))))
  have ht : w.tail.IsHamiltonian := by
    intro v
    obtain ⟨i,rfl⟩ := p.surjective v
    fin_cases i <;>
      simp [w, SimpleGraph.Walk.tail_cons, p.injective.eq_iff]
  refine ⟨p 0,w, ?_⟩
  apply SimpleGraph.Walk.isHamiltonianCycle_isCycle_and_isHamiltonian_tail.mpr
  exact ⟨SimpleGraph.Walk.isCycle_iff_isPath_tail_and_le_length.mpr
    ⟨ht.isPath, by change 3 ≤ 6; decide⟩, ht⟩

end Ali189.RemoteCycle

#print axioms Ali189.RemoteCycle.cycle_order_to_hamiltonian
