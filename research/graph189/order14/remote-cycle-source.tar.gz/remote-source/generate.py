from itertools import permutations
from pathlib import Path
cycles=[(0,*p) for p in permutations(range(1,6))]
data=[]
for k in range(2592):
    misses=[k//(6**i)%6 for i in range(4)]
    low=k//1296==1
    def adj(i,j):
        if i==j:return False
        a,b=sorted((i,j))
        return b!=misses[a] if a<4 else low
    deg=[sum(adj(i,j) for j in range(6)) for i in range(6)]
    if min(deg)<2 or min(deg[:4])<4:
        data.append(0)
    else:
        p=next(p for p in cycles if all(adj(p[i],p[(i+1)%6]) for i in range(6)))
        data.append(sum(x*6**i for i,x in enumerate(p)))
p=Path(__file__).with_name('CycleTable.lean')
with p.open('w') as f:
    f.write('namespace Ali189.RemoteCycle\n\ndef witnesses : Array Nat := #[\n')
    for i in range(0,len(data),24): f.write('  '+','.join(map(str,data[i:i+24]))+',\n')
    f.write(']\nend Ali189.RemoteCycle\n')
print(len(data), sum(x>0 for x in data))
