import CycleCheck
import Mathlib.Combinatorics.SimpleGraph.Finite
import Mathlib.Data.List.FinRange
import Mathlib.Data.Finset.Card

namespace Ali189.RemoteCycle
open Finset

theorem ofFn_all {n : Nat} {p : Fin n → Bool} (h : (List.ofFn p).all id) (u : Fin n) :
    p u = true :=
  List.all_eq_true.mp h (p u) (List.mem_ofFn.mpr ⟨u,rfl⟩)

theorem one_miss (G : SimpleGraph V) [DecidableRel G.Adj] (u : V)
    (h : 4 ≤ G.degree u) :
    ∃ m : V, ∀ v, u ≠ v → (G.Adj u v ↔ v ≠ m) := by
  by_cases hm : ∃ v, u ≠ v ∧ ¬G.Adj u v
  · obtain ⟨m,hum,hm⟩ := hm
    refine ⟨m, fun v huv => ⟨fun hv he => hm (he ▸ hv),?_⟩⟩
    intro hvm
    by_contra hv
    let bad : Finset V := {u,m,v}
    have hb : bad.card = 3 := by
      have hn1 : u ∉ ({m,v} : Finset V) := by simp [hum, huv]
      have hn2 : m ∉ ({v} : Finset V) := by simpa using Ne.symm hvm
      rw [show bad = insert u (insert m {v}) from rfl, card_insert_of_notMem hn1,
        card_insert_of_notMem hn2, card_singleton]
    have hin : G.neighborFinset u ⊆ univ \ bad := by
      intro w hw
      have hadj := (G.mem_neighborFinset _ _).mp hw
      refine mem_sdiff.mpr ⟨mem_univ _,?_⟩
      simp only [bad, mem_insert, mem_singleton]
      rintro (rfl|rfl|rfl)
      · exact G.loopless.irrefl _ hadj
      · exact hm hadj
      · exact hv hadj
    have hh := card_le_card hin
    rw [card_sdiff_of_subset (subset_univ _), card_univ, Fintype.card_fin, hb] at hh
    change 4 ≤ (G.neighborFinset u).card at h
    omega
  · refine ⟨u, fun v huv => ⟨fun _ => Ne.symm huv, fun _ => ?_⟩⟩
    by_contra he
    exact hm ⟨v,huv,he⟩

theorem code_exists (G : SimpleGraph V) [DecidableRel G.Adj]
    (high : ∀ u : V, u.val < 4 → 4 ≤ G.degree u) :
    ∃ k < 2592, ∀ u v, adjacency k u v = true ↔ G.Adj u v := by
  have hm (u : V) : ∃ m : V, u.val < 4 → ∀ v, u ≠ v → (G.Adj u v ↔ v ≠ m) := by
    by_cases hu : u.val < 4
    · obtain ⟨m,hm⟩ := one_miss G u (high u hu)
      exact ⟨m,fun _ => hm⟩
    · exact ⟨u,fun h => (hu h).elim⟩
  choose m hmiss using hm
  let last : Nat := if G.Adj 4 5 then 1 else 0
  have hlast : last ≤ 1 := by dsimp [last]; split <;> omega
  have h0 := (m 0).isLt
  have h1 := (m 1).isLt
  have h2 := (m 2).isLt
  have h3 := (m 3).isLt
  let k := (m 0).val + 6*(m 1).val + 36*(m 2).val + 216*(m 3).val + 1296*last
  have hk : k < 2592 := by dsimp [k]; omega
  have hD (i : V) (hi : i.val < 4) : digit k i.val = m i := by
    apply Fin.ext
    have he : i = 0 ∨ i = 1 ∨ i = 2 ∨ i = 3 := by
      have h : i.val = 0 ∨ i.val = 1 ∨ i.val = 2 ∨ i.val = 3 := by omega
      rcases h with h|h|h|h <;> first
        | exact Or.inl (Fin.ext h)
        | exact Or.inr (Or.inl (Fin.ext h))
        | exact Or.inr (Or.inr (Or.inl (Fin.ext h)))
        | exact Or.inr (Or.inr (Or.inr (Fin.ext h)))
    rcases he with rfl|rfl|rfl|rfl <;> dsimp [digit,k] <;> omega
  have hL : 1296 ≤ k ↔ G.Adj 4 5 := by
    by_cases h : G.Adj 4 5
    · have he : last = 1 := by simp [last,h]
      simp only [h, iff_true]
      dsimp [k]; omega
    · have he : last = 0 := by simp [last,h]
      simp only [h, iff_false]
      dsimp [k]; omega
  have direct (u v : V) (huv : u.val < v.val) :
      adjacency k u v = true ↔ G.Adj u v := by
    have hn : u ≠ v := fun he => lt_irrefl _ (he ▸ huv)
    unfold adjacency
    simp only [if_neg hn, Nat.min_eq_left huv.le, Nat.max_eq_right huv.le]
    by_cases hu : u.val < 4
    · rw [if_pos hu, hD u hu, (hmiss u hu v hn)]
      simp [ne_comm, Fin.ext_iff]
    · have hx : u = 4 := Fin.ext (by have := v.isLt; omega)
      have hy : v = 5 := Fin.ext (by have := v.isLt; omega)
      rw [if_neg hu, decide_eq_true_eq, hL, hx, hy]
  refine ⟨k,hk,fun u v => ?_⟩
  rcases lt_trichotomy u.val v.val with hl|he|hr
  · exact direct u v hl
  · have hv : u = v := Fin.ext he
    subst v
    simp [adjacency]
  · have hs : adjacency k u v = adjacency k v u := by
      simp only [adjacency, eq_comm (a := u), Nat.min_comm u.val, Nat.max_comm u.val]
    rw [hs, direct v u hr, G.adj_comm]

theorem count_eq (G : SimpleGraph V) [DecidableRel G.Adj] (k : Nat)
    (hadj : ∀ u v, adjacency k u v = true ↔ G.Adj u v) (u : V) :
    count k u = G.degree u := by
  let vv := List.ofFn (id : V → V)
  have hnd : vv.Nodup := List.nodup_ofFn.mpr (fun _ _ he => he)
  have huniv : vv.toFinset = univ := by
    ext v
    simp only [mem_univ, iff_true, List.mem_toFinset, vv, List.mem_ofFn]
    exact ⟨v,rfl⟩
  have hcount : count k u = (vv.filter (adjacency k u)).length := by
    unfold count
    rw [show (List.ofFn fun v : V => adjacency k u v) = vv.map (adjacency k u) by
      simp [vv]]
    simp only [← List.countP_eq_length_filter, List.countP_map, Function.comp_def, id_eq]
  rw [hcount, ← List.toFinset_card_of_nodup (hnd.filter _), List.toFinset_filter, huniv,
    SimpleGraph.degree, SimpleGraph.neighborFinset_eq_filter]
  congr 1
  ext v
  simp [hadj]

theorem cycle_from_checks (verified : ∀ k < 2592, check k = true)
    (G : SimpleGraph V) [DecidableRel G.Adj]
    (minDeg : ∀ u, 2 ≤ G.degree u) (high : ∀ u : V, u.val < 4 → 4 ≤ G.degree u) :
    ∃ p : V ≃ V, ∀ u, G.Adj (p u) (p (u+1)) := by
  obtain ⟨k,hk,hadj⟩ := code_exists G high
  have deg : degreeTests k = true := by
    unfold degreeTests
    apply List.all_eq_true.mpr
    intro q hq
    obtain ⟨u,rfl⟩ := List.mem_ofFn.mp hq
    apply decide_eq_true
    rw [count_eq G k hadj]
    split
    · exact high u (by assumption)
    · exact minDeg u
  have hcycle : cycleTests k = true := by simpa [check,deg] using verified k hk
  obtain ⟨inj,cycle⟩ := Bool.and_eq_true_iff.mp hcycle
  have hi : Function.Injective (order k) := fun u v he =>
    of_decide_eq_true (ofFn_all (ofFn_all inj u) v) he
  let p := Equiv.ofBijective (order k) (Finite.injective_iff_bijective.mp hi)
  exact ⟨p, fun u => (hadj _ _).mp (ofFn_all cycle u)⟩

end Ali189.RemoteCycle

#print axioms Ali189.RemoteCycle.cycle_from_checks
