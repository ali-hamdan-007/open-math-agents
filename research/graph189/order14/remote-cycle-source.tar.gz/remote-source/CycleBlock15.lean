import CycleCheck
namespace Ali189.RemoteCycle
set_option maxRecDepth 10000 in
set_option maxHeartbeats 0 in
theorem checked15 : block 15 = true := by decide +kernel
end Ali189.RemoteCycle
