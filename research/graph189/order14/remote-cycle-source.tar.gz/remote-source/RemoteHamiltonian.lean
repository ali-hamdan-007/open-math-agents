import RemoteCycle
import WalkConversions

namespace Ali189.RemoteCycle

theorem six_vertex_hamiltonian (G : SimpleGraph V) [DecidableRel G.Adj]
    (minDeg : ∀ u, 2 ≤ G.degree u) (high : ∀ u : V, u.val < 4 → 4 ≤ G.degree u) :
    G.IsHamiltonian := by
  obtain ⟨p,hp⟩ := six_vertex_cycle G minDeg high
  exact cycle_order_to_hamiltonian G p hp

theorem six_vertex_hamiltonianPath_end (G : SimpleGraph V) [DecidableRel G.Adj]
    (minDeg : ∀ u, 2 ≤ G.degree u) (high : ∀ u : V, u.val < 4 → 4 ≤ G.degree u) (t : V) :
    ∃ s, ∃ p : G.Walk s t, p.IsHamiltonian := by
  obtain ⟨p,hp⟩ := (six_vertex_hamiltonian G minDeg high).exists_isHamiltonianCycle t
  exact ⟨_,p.tail,hp.isHamiltonian_tail⟩

end Ali189.RemoteCycle

#print axioms Ali189.RemoteCycle.six_vertex_hamiltonian
#print axioms Ali189.RemoteCycle.six_vertex_hamiltonianPath_end
