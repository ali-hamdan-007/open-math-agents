import Graph189ExceptionalNeighbors
import Graph189OneExceptionalPair
import Graph189ExteriorMatching

open SimpleGraph Finset Graph189TerminalLeafClosure
namespace Graph189ExteriorGap
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj] {x y : V}

/-- A degree-two exceptional vertex and an actual ordered contact matching
force the matched exterior order estimate with a loss of at most one vertex. -/
theorem degree_two_port_order (p : G.Walk x y) (hp : p.IsPath)
    (longest : ∀ {a b}, ∀ r : G.Walk a b, r.IsPath → r.length≤p.length)
    (K : Finset V) (outside : ∀ w∈K, w∉p.support)
    (z : K) (two : (G.induce (K : Set V)).degree z=2)
    (high : ∀ a : K, a≠z → K.card+1≤2*(G.induce (K : Set V)).degree a)
    {j : ℕ} (mark : Fin (j+1) ↪o Fin p.support.length) (port : Fin (j+1) ↪ K)
    (contacts : ∀ i, G.Adj p.support[(mark i).val] (port i).val) :
    (j+3)*K.card+(j+1)≤Fintype.card V+1 := by
  classical
  let H := G.induce (K : Set V)
  have deg : (H.neighborFinset z).card=2 := two
  obtain ⟨u,v,uv,pair⟩ := Finset.card_eq_two.mp deg
  have members (a : K) : H.Adj z a ↔ a=u ∨ a=v := by
    rw [← H.mem_neighborFinset z a,pair]
    simp
  have h (a : K) (az : a≠z) : Fintype.card K+1≤2*H.degree a := by simpa [H] using high a az
  have regular (a b : K) (ab : a≠b) (avoids : ¬(H.Adj z a ∧ H.Adj z b)) :
      ExteriorRoute p a.val b.val K.card := by
    obtain ⟨q,hq⟩ := prescribed_avoiding_low_neighbors (G:=H) z a b ab (show H.degree z=2 from two).ge h avoids
    exact route_of_induced_hamilton p K outside hq
  have fallback (a b : K) (ab : a≠b) : ExteriorRoute p a.val b.val (K.card-1) := by
    by_cases both : H.Adj z a ∧ H.Adj z b
    · obtain ⟨q,qpath,len,_⟩ := prescribed_between_low_neighbors (G:=H) z a b ab two h both.1 both.2
      let e := SimpleGraph.Embedding.induce (G:=G) (K : Set V)
      refine ⟨q.map e.toHom,qpath.map e.injective,?_,?_⟩
      · rw [List.disjoint_left]
        intro t ht
        change t∈(q.map e.toHom).support at ht
        rw [Walk.support_map] at ht
        obtain ⟨c,_,rfl⟩ := List.mem_map.mp ht
        exact outside c.val c.property
      · change K.card-1≤(q.map e.toHom).support.length
        rw [Walk.support_map,List.length_map]
        have exactLen : q.support.length+1=K.card := len.trans (Fintype.card_coe K)
        omega
    · obtain ⟨q,hq,dis,len⟩ := regular a b ab both
      exact ⟨q,hq,dis,by omega⟩
  let P : Fin (j+1) ↪ V := port.trans ⟨Subtype.val,Subtype.val_injective⟩
  have pair_avoid (a b : K) (ab : a≠b)
      (avoids : ¬(a.val=u.val ∧ b.val=v.val ∨ a.val=v.val ∧ b.val=u.val)) :
      ¬(H.Adj z a ∧ H.Adj z b) := by
    rintro ⟨ha,hb⟩
    rcases (members a).mp ha with au | av <;> rcases (members b).mp hb with bu | bv
    · exact ab (au.trans bu.symm)
    · exact avoids (Or.inl ⟨congrArg Subtype.val au,congrArg Subtype.val bv⟩)
    · exact avoids (Or.inr ⟨congrArg Subtype.val av,congrArg Subtype.val bu⟩)
    · exact ab (av.trans bv.symm)
  have another (a : K) : ∃ b : K, b≠a ∧ ¬(H.Adj z a ∧ H.Adj z b) := by
    by_cases az : a=z
    · subst a
      exact ⟨u,((members u).mpr (Or.inl rfl)).ne.symm,fun hadj => hadj.1.ne rfl⟩
    · exact ⟨z,Ne.symm az,fun hadj => hadj.2.ne rfl⟩
  obtain ⟨a,na,ra⟩ := another (port 0)
  obtain ⟨b,nb,rb⟩ := another (port (Fin.last j))
  have result := exterior_order_one_exceptional_pair p hp longest K outside mark P contacts u.val v.val
    (fun i => fallback _ _ (port.injective.ne (ne_of_lt i.castSucc_lt_succ)))
    (fun i no => regular _ _ (port.injective.ne (ne_of_lt i.castSucc_lt_succ))
      (pair_avoid _ _ (port.injective.ne (ne_of_lt i.castSucc_lt_succ)) no))
    ⟨a.val,regular _ _ na (fun hadj => ra hadj.symm)⟩ ⟨b.val,regular _ _ nb.symm rb⟩
  simp only [Nat.add_mul] at result ⊢
  omega

#print axioms degree_two_port_order
end Graph189ExteriorGap
