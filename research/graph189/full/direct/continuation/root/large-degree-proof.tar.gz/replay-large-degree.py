"""Build the finite graph proof in topological order with the project-pinned Lean."""
import argparse
import hashlib
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--project", type=Path, required=True, help="built pinned formal-conjectures checkout")
parser.add_argument("--bondy", type=Path, required=True, help="accepted PR 7971 proof, Git blob 1094243524b455ea5dace0862e4c6ec05a7ed312")
parser.add_argument("--check-sources", action="store_true", help="validate and generate the inputs without elaborating")
args = parser.parse_args()
base = Path(__file__).resolve().parent
project = args.project.resolve()
with tempfile.TemporaryDirectory(prefix="graph189-degree-") as work:
    out = Path(work)
    for p in (base / "sources").glob("*.lean"):
        shutil.copyfile(p, out / p.name)
    subprocess.run([sys.executable, str(base / "extract_bondy_core.py"), str(args.bondy.resolve()),
                    str(project), str(out / "Graph189BondyCore.lean")], check=True)
    order = []
    for line in (base / "manifest.tsv").read_text().splitlines():
        digest, name = line.split("\t")
        if hashlib.sha256((out / name).read_bytes()).hexdigest() != digest:
            raise SystemExit(f"Unexpected source bytes for {name}")
        order.append(name)
    print(f"Verified {len(order)} source files", flush=True)
    if args.check_sources:
        sys.exit(0)
    lp = subprocess.check_output(["lake", "env", "printenv", "LEAN_PATH"], cwd=project, text=True)
    lean = subprocess.check_output(["lake", "env", "which", "lean"], cwd=project, text=True).strip()
    paths = [out, *((project / item).resolve() for item in lp.strip().split(os.pathsep) if item)]
    env = dict(os.environ, LEAN_PATH=os.pathsep.join(map(str, paths)))
    for name in order:
        mod = Path(name).stem
        subprocess.run([lean, "-j1", "-o", mod + ".olean", name], cwd=out, env=env, check=True)
    audit = out / "Audit.lean"
    audit.write_text("import Graph189LargeDegreeTrace\n#print axioms Graph189LargeDegree.traceable\n"
                     "#print axioms Graph189ThirdConnectivity.traceable\n")
    log = subprocess.check_output([lean, "-j1", "-DwarningAsError=true", audit.name],
                                  cwd=out, env=env, text=True)
    print(log, end="")
    import re
    results = re.findall(r"depends on axioms:\s*\[([^\]]+)\]", log)
    if len(results) != 2 or any(set(map(str.strip, group.split(","))) !=
                                {"propext", "Classical.choice", "Quot.sound"} for group in results):
        raise SystemExit("Final axiom audit differs from the recorded two theorems.")
