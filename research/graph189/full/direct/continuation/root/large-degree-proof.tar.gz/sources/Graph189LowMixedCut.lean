import Graph189MixedDebit
import Graph189MaximumDegree
import Graph189NineCutDebit

namespace Graph189CutSides.CutSides
open Finset SimpleGraph
open OMA.R_WrittenOnTheWallII_GraphConjecture189_conjecture189_R1

variable {V : Type*} [Fintype V] [DecidableEq V] [Nontrivial V] {G : SimpleGraph V}
variable [DecidableRel G.Adj] {A B S : Finset V} (sides : Graph189CutSides.CutSides G A B S)
include sides

/-- All three finite deficit constraints use the very same pair of actual
opposite-side neighbors and the actual common neighborhood of that pair. -/
theorem low_cut_three_bounds (hc : G.Connected)
    (smaller : ∀ T : Finset V, T.card < S.card → (G.induce {u : V | u ∉ T}).Connected)
    (cap : ∀ v, G.distEven v ≤ 1+G.secondSmallestDegree) {z : V} (hz : z ∈ S)
    (low : G.degree z < G.secondSmallestDegree) :
    ∃ a ∈ A, ∃ b ∈ B, G.Adj a z ∧ G.Adj b z ∧ ∃ r : ℕ,
      r = (G.neighborFinset a ∩ G.neighborFinset b).card ∧
      1 ≤ r ∧ r ≤ S.card ∧ G.secondSmallestDegree-G.degree z+1 ≤ r ∧
      Fintype.card V+G.secondSmallestDegree*(G.secondSmallestDegree-G.degree z) ≤
        2*G.secondSmallestDegree+(G.secondSmallestDegree+1)*r ∧
      Fintype.card V+(r-1)*(G.secondSmallestDegree+1-S.card) ≤
        (S.card+1)*G.secondSmallestDegree+A.card+S.card+
        r*(G.maxDegree-G.secondSmallestDegree+S.card-1) := by
  obtain ⟨a,ha,b,hb,az,bz,r,eq,rmin,rmax,dmin,debit⟩ := sides.low_cut_deficit hc smaller cap hz low
  have ah := (degree_pair (G := G) a z az.ne).resolve_right (not_le.mpr low)
  have hh (y : V) (hy : y ∈ B) : G.secondSmallestDegree ≤ G.degree y := by
    have ne : y ≠ z := fun e => Finset.disjoint_left.mp sides.right_cut (e ▸ hy) hz
    exact (degree_pair (G := G) y z ne).resolve_right (not_le.mpr low)
  have mixed := Graph189MixedDebit.mixed_cut_pair sides hc smaller cap ha hb az bz ah hh
  rw [← eq] at mixed
  have total := (sides.low_cut_product hc smaller cap hz low).1
  exact ⟨a,ha,b,hb,az,bz,r,eq,rmin,rmax,dmin,debit,by omega⟩

/-- The connectivity-nine obstruction from the actual low cut. The remaining
hypotheses are exactly the global order and maximum-root width estimates. -/
theorem no_low_at_nine_of_width (hc : G.Connected)
    (smaller : ∀ T : Finset V, T.card < S.card → (G.induce {u : V | u ∉ T}).Connected)
    (cap : ∀ v, G.distEven v ≤ 1+G.secondSmallestDegree)
    (nine : S.card = 9) (hk : 163 ≤ G.secondSmallestDegree)
    (base : 10*G.secondSmallestDegree ≤ Fintype.card V+71) (w : ℚ)
    (width : 2*((Fintype.card V : ℚ)-2*G.secondSmallestDegree)+
        (G.secondSmallestDegree : ℚ)*(G.maxDegree-G.secondSmallestDegree : ℕ) ≤
      (G.secondSmallestDegree+1 : ℚ)*w)
    (budget : w*((Fintype.card V : ℚ)-2*G.secondSmallestDegree-
        (G.maxDegree-G.secondSmallestDegree : ℕ)-2) ≤
      (G.secondSmallestDegree : ℚ)*(G.secondSmallestDegree+(G.maxDegree-G.secondSmallestDegree : ℕ))) :
    ∀ z ∈ S, G.secondSmallestDegree ≤ G.degree z := by
  classical
  intro z hz
  by_contra! low
  let k := G.secondSmallestDegree
  let n := Fintype.card V
  let e := G.maxDegree-k
  let d := k-G.degree z
  have contradiction_of_le {A' B' : Finset V} (ss : Graph189CutSides.CutSides G A' B' S)
      (small : A'.card ≤ B'.card) : False := by
    obtain ⟨_,_,_,_,_,_,r,_,rmin,rmax,_,debit,mixed⟩ := ss.low_cut_three_bounds hc smaller cap hz low
    rw [nine] at rmax mixed
    have cross := (ss.low_cut_product hc smaller cap hz low).2
    rw [nine] at cross
    change A'.card*B'.card ≤ A'.card*k+9*(k*k) at cross
    change n+k*d ≤ 2*k+(k+1)*r at debit
    change n+(r-1)*(k+1-9) ≤ 10*k+A'.card+9+r*(e+9-1) at mixed
    have maxd := Graph189DegreeCeiling.maxDegree_le_three_mul_secondSmallestDegree hc cap
    change G.maxDegree ≤ 3*k at maxd
    have ep : e ≤ 2*k := by dsimp [e]; omega
    have dp : 1 ≤ d := by dsimp [d,k]; omega
    have hr : (r : ℚ) = 9 ∨ (r : ℚ) ≤ 8 := by
      rcases (show r=9 ∨ r≤8 by omega) with h | h
      · left; exact_mod_cast h
      · right; exact_mod_cast h
    have hbase : 10*(k : ℚ) ≤ (n : ℚ)+71 := by exact_mod_cast base
    have hd : (n : ℚ)+(k : ℚ)*(d : ℚ) ≤ 2*(k : ℚ)+(k+1 : ℚ)*r := by exact_mod_cast debit
    have hcross : (A'.card : ℚ)*B'.card ≤ (A'.card : ℚ)*k+9*((k : ℚ)*k) := by exact_mod_cast cross
    have hmix : (n : ℚ)+((r-1 : ℕ) : ℚ)*((k+1-9 : ℕ) : ℚ) ≤
        10*(k : ℚ)+A'.card+9+(r : ℚ)*((e+9-1 : ℕ) : ℚ) := by exact_mod_cast mixed
    have kl : 9 ≤ k+1 := by dsimp [k]; omega
    have el : e+9-1 = e+8 := by omega
    rw [Nat.cast_sub rmin,Nat.cast_sub kl,el] at hmix
    push_cast at hmix
    exact Graph189NineCutDebit.no_low_at_nine (k := (k:ℚ)) (n := (n:ℚ)) (w := w)
      (e := (e:ℚ)) (d := (d:ℚ)) (r := (r:ℚ)) (x := (A'.card:ℚ)) (y := (B'.card:ℚ))
      (by exact_mod_cast hk) (by linarith only [hbase]) (by positivity) (by exact_mod_cast ep)
      width budget (by positivity) (by exact_mod_cast small) (by nlinarith only [hcross])
      (by exact_mod_cast dp) hr (by linarith only [hd]) (by linarith only [hmix])
  rcases le_total A.card B.card with h | h
  · exact contradiction_of_le sides h
  · exact contradiction_of_le sides.swap h

end Graph189CutSides.CutSides
#print axioms Graph189CutSides.CutSides.low_cut_three_bounds
#print axioms Graph189CutSides.CutSides.no_low_at_nine_of_width
