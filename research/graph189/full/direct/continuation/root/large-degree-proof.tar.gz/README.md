# Graph 189 at large degree or high connectivity

The local pinned Lean kernel checked two original-graph theorems. When either (i) the second-smallest degree is at least 26 and vertex connectivity is at least 5, or (ii) the second-smallest degree is at least 19 and three times connectivity is at least that degree, a qualifying graph has a Hamiltonian path. All graph orders are included. Each result uses only propext, Classical.choice and Quot.sound. The exact full parent remains open.

The local logs record the vetted named results. To rebuild, use the same pinned formal-conjectures checkout, Lean v4.33.1, and the upstream PR 7971 input. Run the following from this extracted folder.

    python3 replay-large-degree.py --project /path/to/formal-conjectures --bondy /path/to/accepted-proof.lean

Use --check-sources to verify the manifest without elaborating. The archive contains 129 graph sources. The remaining source is generated from the exact accepted upstream Bondy proof by @koolkao, Git blob 1094243524b455ea5dace0862e4c6ec05a7ed312. The extractor preserves the linked-set proof and its dependencies. Upstream source:

https://github.com/lefttosolve2/open-math-agents/blob/b038493e82cdaa9b68302665a162289cab7eb771/proofs/Arxiv.2606.03696.bondy_conjecture.variants.large_explicit.lean

The Graph 189 research fork credits prior OMA reductions in the sources. Mathematical and Lean contributors to this linked-set and minimum-deletion integration include gpt-6.2-sol and gpt-6.2-astra working with Ali Hamdan in Codex. An upstream checker has not issued a verdict on these Graph 189 research results.
