import Graph189ThreePrivateBlocks

open Finset SimpleGraph Graph189PositiveEvenCut
namespace Graph189ThreePrivateDensity

private theorem row_count {q far near n e x t miss a u k : ℕ}
    (opposite : q+far≤e) (splitN : far+near=n)
    (own : miss+e≤k) (splitX : miss+t=x)
    (firsts : t≤a+u) (second : u+near≤k) : q+n+x≤2*k+a := by omega

variable {V : Type*} [Fintype V] [DecidableEq V]
variable {G : SimpleGraph V} [DecidableRel G.Adj] {A B S X Y N : Finset V}

/-- Charge the nonneighbors of the representative within its own side
and target nonports across the separator in a single row. -/
theorem representative_row (hc : G.Connected) (cut : Graph189CutSides.CutSides G A B S)
    (xs : X⊆A) (ys : Y⊆B) (ns : N⊆Y) {k : ℕ} (cap : ∀ v,G.distEven v≤k+1)
    {a i : V} (aa : a∈A) (hi : i∈S) (ai : G.Adj a i)
    (unique : ∀ j∈S,G.Adj a j → j=i) (near : ∀ b∈N,G.dist a b≤4)
    (nonport : ∀ b∈N,∀ j∈S,¬G.Adj j b)
    (depth : ∀ u∈X,a≠u → ¬G.Adj a u → G.dist a u=2) :
    (Y.filter (G.Adj i)).card+N.card+X.card≤2*k+(X.filter (G.Adj i)).card := by
  classical
  let E := Y.filter (fun b => Even (G.dist a b))
  let T := X.filter (fun u => u=a ∨ G.Adj a u)
  let Z := N.filter (fun b => G.dist i b=2)
  let U := X.filter (fun u => G.dist i u=2)
  let Q := Y.filter (G.Adj i)
  let C := X.filter (G.Adj i)
  obtain ⟨port,far⟩ := cross_blocks (N:=N) hc cut aa ys ns ai unique near nonport
  have d : Disjoint Q (N \ Z) := by
    refine Finset.disjoint_left.mpr fun b hq hn => ?_
    exact nonport b (mem_sdiff.mp hn).1 i hi (mem_filter.mp hq).2
  have count := card_le_card (union_subset port far)
  change (Q∪(N \ Z)).card≤E.card at count
  rw [card_union_of_disjoint d] at count
  have splitN : (N \ Z).card+Z.card=N.card := card_sdiff_add_card_eq_card (filter_subset _ _)
  obtain ⟨own,close⟩ := source_blocks hc cut xs hi ai depth
  have cross : E⊆evenOthers G a := by
    intro b hb
    obtain ⟨bt,even⟩ := mem_filter.mp hb
    exact mem_even_others (fun eq => Finset.disjoint_left.mp cut.apart aa (eq ▸ ys bt)) even
  have apart : Disjoint (X \ T) E :=
    cut.apart.mono (sdiff_subset.trans xs) ((filter_subset _ _).trans ys)
  have both := (card_le_card (union_subset own cross)).trans (even_others_card (cap a))
  change ((X \ T)∪E).card≤k at both
  rw [card_union_of_disjoint apart] at both
  have splitX : (X \ T).card+T.card=X.card := card_sdiff_add_card_eq_card (filter_subset _ _)
  have firsts := (card_le_card close).trans (card_union_le _ _)
  change T.card≤C.card+U.card at firsts
  have second : U.card+Z.card≤k := Graph189PrivateQuota.two_layer_budget G (cap i) U Z
    (cut.apart.mono ((filter_subset _ _).trans xs) ((filter_subset _ _).trans (ns.trans ys)))
    (fun _ h => (mem_filter.mp h).2) (fun _ h => (mem_filter.mp h).2)
  exact row_count count splitN both splitX firsts second

#print axioms representative_row
end Graph189ThreePrivateDensity
