import Graph189ResidualWindows

open Finset
namespace Graph189ThreePrivateDensity

private theorem total {x y n p qa qb k : ℕ}
    (sumA : qa≤x) (ports : p≤qb) (portCap : qb+6≤3*k)
    (rows : qb+3*(n+x)≤6*k+qa) (part : n+p=y) :
    2*x+3*y+12≤12*k := by omega

/-- Sum the three row budgets. The six missing-label debits are separate
from the three within-side row budgets. -/
theorem tally {I : Type*} [DecidableEq I] (S : Finset I) (three : S.card=3)
    {x y n p k : ℕ} (qa qb : I→ℕ) (sumA : (∑ i∈S,qa i)≤x)
    (portCount : p≤∑ i∈S,qb i)
    (portRow : ∀ i∈S,qb i+2≤k)
    (row : ∀ i∈S,qb i+n+x≤2*k+qa i) (part : n+p=y) :
    2*x+3*y+12≤12*k := by
  have ports := Finset.sum_le_sum portRow
  simp only [Finset.sum_add_distrib,sum_const,Nat.nsmul_eq_mul,three] at ports
  have line (i : I) (hi : i∈S) : qb i+(n+x)≤2*k+qa i := by
    simpa only [Nat.add_assoc] using row i hi
  have all := Finset.sum_le_sum line
  simp only [sum_add_distrib,sum_const,Nat.nsmul_eq_mul,three] at all
  exact total sumA portCount (by omega) (by omega) part

#print axioms tally
end Graph189ThreePrivateDensity
