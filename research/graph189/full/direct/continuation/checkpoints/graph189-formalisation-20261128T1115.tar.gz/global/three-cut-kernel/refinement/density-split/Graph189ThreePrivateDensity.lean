import Graph189BoundaryDebit
import Graph189ThreeDenseDepth
import Graph189ThreePrivateRow
import Graph189ThreePrivateTally

open Finset SimpleGraph Graph189PositiveEvenCut
namespace Graph189ThreePrivateDensity

variable {V : Type*} [Fintype V] [DecidableEq V] [Nontrivial V]
variable {G : SimpleGraph V} [DecidableRel G.Adj] {A B S : Finset V}

/-- For a small high side with only private separator contacts, the minimum
three-cut charges six missing labels and controls its internal nonneighbors. -/
theorem dense_private_quota (hc : G.Connected) (cut : Graph189CutSides.CutSides G A B S)
    (smaller : ∀ T : Finset V, T.card<S.card → (G.induce {v : V | v∉T}).Connected)
    (three : S.card=3) (small : A.card<2*G.secondSmallestDegree)
    (cap : ∀ v,G.distEven v≤G.secondSmallestDegree+1)
    (contacts : ∀ i∈S,∃ a∈A,G.secondSmallestDegree≤G.degree a ∧ G.Adj a i)
    (privatePorts : ∀ a∈A,G.secondSmallestDegree≤G.degree a →
      (Graph189PortLabels.support G S a).card≤1) :
    2*(A.filter (fun v => G.secondSmallestDegree≤G.degree v)).card+
      3*(B.filter (fun v => G.secondSmallestDegree≤G.degree v)).card+12≤12*G.secondSmallestDegree := by
  classical
  let k := G.secondSmallestDegree
  let X := A.filter (fun a => k≤G.degree a)
  let Y := B.filter (fun b => k≤G.degree b)
  let P := Y.filter (fun b => ∃ i∈S,G.Adj i b)
  let N := Y \ P
  let QA (i : V) := X.filter (G.Adj i)
  let QB (i : V) := Y.filter (G.Adj i)
  have xs : X⊆A := filter_subset _ _
  have ys : Y⊆B := filter_subset _ _
  have ps : P⊆Y := filter_subset _ _
  have ns : N⊆Y := sdiff_subset
  have nonport (b : V) (hb : b∈N) (i : V) (hi : i∈S) (edge : G.Adj i b) : False :=
    (mem_sdiff.mp hb).2 (mem_filter.mpr ⟨ns hb,i,hi,edge⟩)
  have unique {a : V} (ha : a∈A) (high : k≤G.degree a) {i j : V}
      (hi : i∈S) (hj : j∈S) (ai : G.Adj a i) (aj : G.Adj a j) : i=j :=
    card_le_one_iff.mp (privatePorts a ha high)
      (mem_filter.mpr ⟨hi,ai⟩) (mem_filter.mpr ⟨hj,aj⟩)
  have cp (v : V) : G.distEven v≤1+k := by simpa only [k,Nat.add_comm 1] using cap v
  have rows (i : V) (hi : i∈S) : (QB i).card+2≤k ∧
      (QB i).card+N.card+X.card≤2*k+(QA i).card := by
    obtain ⟨a,aa,high,ai⟩ := contacts i hi
    have one (j : V) (hj : j∈S) (aj : G.Adj a j) := unique aa high hj hi aj ai
    have near (b : V) (hb : b∈N) : G.dist a b≤4 :=
      high_distance_four hc cp high (mem_filter.mp (ns hb)).2
    have port := (cross_blocks (N:=N) hc cut aa ys ns ai one near nonport).1
    have oneLayer := card_le_card port
    have debit := Graph189BoundaryDebit.even_quota hc cut smaller cap ys aa
    have sz := privatePorts a aa high
    rw [three] at debit
    change (QB i).card≤_ at oneLayer
    refine ⟨by omega,representative_row hc cut xs ys ns cap aa hi ai one near nonport ?_⟩
    exact fun u hu => dense_depth hc cut small privatePorts aa high (xs hu) (mem_filter.mp hu).2
  have sourceSum : (∑ i∈S,(QA i).card)≤X.card := by
    have pair : (S : Set V).PairwiseDisjoint QA := by
      intro i hi j hj ne
      apply Finset.disjoint_left.mpr
      intro a ha hd
      obtain ⟨ax,ia⟩ := mem_filter.mp ha
      exact ne (unique (xs ax) (mem_filter.mp ax).2 hi hj ia.symm (mem_filter.mp hd).2.symm)
    have sub : S.biUnion QA⊆X := by
      intro a ha
      obtain ⟨_,_,member⟩ := mem_biUnion.mp ha
      exact (mem_filter.mp member).1
    rw [←card_biUnion pair]
    exact card_le_card sub
  have ports : P.card≤∑ i∈S,(QB i).card := by
    have sub : P⊆S.biUnion QB := by
      intro b pb
      obtain ⟨bt,i,hi,edge⟩ := mem_filter.mp pb
      exact mem_biUnion.mpr ⟨i,hi,mem_filter.mpr ⟨bt,edge⟩⟩
    exact (card_le_card sub).trans card_biUnion_le
  exact tally S three (fun i => (QA i).card) (fun i => (QB i).card) sourceSum ports
    (fun i hi => (rows i hi).1) (fun i hi => (rows i hi).2) (card_sdiff_add_card_eq_card ps)

#print axioms dense_private_quota
end Graph189ThreePrivateDensity
