# Focused private-density certificate

This directory replaces the 275-line monolithic elaboration in its parent.
That run was killed with exit 137 before it printed a Lean diagnostic or
wrote an olean. These are uncompiled sources. They keep the same public
`Graph189ThreePrivateDensity.dense_private_quota` graph theorem.

The next individual compile is `Graph189ThreeDenseDepth.lean`. It has a
single 48-line proof and imports only the existing `Graph189ResidualWindows`.
Once that is checked, the independent tally and blocks can each be compiled
one at a time, then the representative row, then the graph adapter.

| File | Mathematical interface | Local prerequisites |
|---|---|---|
| Graph189ThreeDenseDepth.lean | Two high nonadjacent vertices on the small side lie at distance two | none |
| Graph189ThreePrivateTally.lean | Three row budgets and six missing labels imply the total population inequality | none |
| Graph189ThreePrivateBlocks.lean | The source nonneighbors and target nonports consume their indicated even slots | none |
| Graph189ThreePrivateRow.lean | One private representative yields q + N + X ≤ 2k + a | Graph189ThreePrivateBlocks |
| Graph189ThreePrivateDensity.lean | Exact graph statement 2x + 3y + 12 ≤ 12k | All preceding files |

The blocks now call the existing checked `Graph189CoSingleton.odd_to_nonport`.
The final adapter calls the existing `Graph189PositiveEvenCut.high_distance_four`.
A closed numerical lemma with six hypotheses discharges the representative
row; the final three-row arithmetic has five hypotheses. The long old
representative context is no longer handed to a general arithmetic tactic.
Each file prints the axioms of its public statements. The coordinator
controls the compiler lock and exact-parent lease.
