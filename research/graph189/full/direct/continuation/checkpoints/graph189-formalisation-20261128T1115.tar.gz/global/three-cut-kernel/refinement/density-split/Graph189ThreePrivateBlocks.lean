import Graph189CoSingleton
import Graph189PositiveEvenCut
import Graph189ResidualWindows

open Finset SimpleGraph Graph189PositiveEvenCut
namespace Graph189ThreePrivateDensity

variable {V : Type*} [Fintype V] [DecidableEq V]
variable {G : SimpleGraph V} [DecidableRel G.Adj] {A B S X Y N : Finset V}

/-- The far nonports and immediate opposite contacts are positive even
vertices for a representative with only one separator contact. -/
theorem cross_blocks (hc : G.Connected) (cut : Graph189CutSides.CutSides G A B S)
    {a i : V} (aa : a∈A) (ys : Y⊆B) (ns : N⊆Y) (ai : G.Adj a i)
    (unique : ∀ j∈S,G.Adj a j → j=i) (near : ∀ b∈N,G.dist a b≤4)
    (nonport : ∀ b∈N,∀ j∈S,¬G.Adj j b) :
    Y.filter (G.Adj i)⊆Y.filter (fun b => Even (G.dist a b)) ∧
    N \ N.filter (fun b => G.dist i b=2)⊆Y.filter (fun b => Even (G.dist a b)) := by
  classical
  constructor
  · intro b hb
    obtain ⟨bt,edge⟩ := mem_filter.mp hb
    have ne : a≠b := fun h => Finset.disjoint_left.mp cut.apart aa (h ▸ ys bt)
    have d := Graph189PrivateQuota.exact_two hc ai edge ne (cut.no_cross a aa b (ys bt))
    exact mem_filter.mpr ⟨bt,by simp [d]⟩
  · intro b hb
    obtain ⟨bn,notSecond⟩ := mem_sdiff.mp hb
    refine mem_filter.mpr ⟨ns bn,?_⟩
    by_contra odd
    obtain ⟨j,hj,aj,dist⟩ := Graph189CoSingleton.odd_to_nonport hc cut aa (ys (ns bn))
      (nonport b bn) (near b bn) odd
    exact notSecond (mem_filter.mpr ⟨bn,unique j hj aj ▸ dist⟩)

/-- A representative's missed source vertices consume positive even
slots; its own closed neighborhood is covered by the first two layers of i. -/
theorem source_blocks (hc : G.Connected) (cut : Graph189CutSides.CutSides G A B S)
    (xs : X⊆A) {a i : V} (hi : i∈S) (ai : G.Adj a i)
    (depth : ∀ u∈X,a≠u → ¬G.Adj a u → G.dist a u=2) :
    let T := X.filter (fun u => u=a ∨ G.Adj a u)
    X \ T ⊆ evenOthers G a ∧
      T⊆(X.filter (G.Adj i))∪(X.filter (fun u => G.dist i u=2)) := by
  classical
  constructor
  · intro u hu
    obtain ⟨ux,absent⟩ := mem_sdiff.mp hu
    have outside : ¬(u=a ∨ G.Adj a u) := fun h => absent (mem_filter.mpr ⟨ux,h⟩)
    have ne : u≠a := fun h => outside (Or.inl h)
    have d := depth u ux ne.symm (fun au => outside (Or.inr au))
    exact mem_even_others ne (by simp [d])
  · intro u hu
    obtain ⟨ux,close⟩ := mem_filter.mp hu
    by_cases edge : G.Adj i u
    · exact mem_union_left _ (mem_filter.mpr ⟨ux,edge⟩)
    rcases close with eq|au
    · subst u
      exact (edge ai.symm).elim
    have ne : i≠u := fun eq => Finset.disjoint_left.mp cut.left_cut (xs ux) (eq ▸ hi)
    exact mem_union_right _ (mem_filter.mpr ⟨ux,Graph189PrivateQuota.exact_two hc ai.symm au ne edge⟩)

#print axioms cross_blocks
#print axioms source_blocks
end Graph189ThreePrivateDensity
