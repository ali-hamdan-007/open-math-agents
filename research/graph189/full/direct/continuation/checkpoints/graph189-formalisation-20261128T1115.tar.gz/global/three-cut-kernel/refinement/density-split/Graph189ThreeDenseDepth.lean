import Graph189ResidualWindows

open Finset SimpleGraph
namespace Graph189ThreePrivateDensity
variable {V : Type*} [Fintype V] [DecidableEq V]
variable {G : SimpleGraph V} [DecidableRel G.Adj] {A B S : Finset V}

theorem dense_depth (hc : G.Connected) (cut : Graph189CutSides.CutSides G A B S)
    (small : A.card<2*G.secondSmallestDegree)
    (privatePorts : ∀ a∈A, G.secondSmallestDegree≤G.degree a →
      (Graph189PortLabels.support G S a).card≤1) {a v : V}
    (aa : a∈A) (ah : G.secondSmallestDegree≤G.degree a)
    (va : v∈A) (vh : G.secondSmallestDegree≤G.degree v)
    (ne : a≠v) (no : ¬G.Adj a v) : G.dist a v=2 := by
  classical
  let U (w : V) := A ∩ G.neighborFinset w
  have internal (w : V) (m : w∈A) (h : G.secondSmallestDegree≤G.degree w) :
      G.secondSmallestDegree≤(U w).card+1 := by
    have sub : G.neighborFinset w⊆U w ∪ Graph189PortLabels.support G S w := by
      intro u hu
      have wu := (G.mem_neighborFinset w u).mp hu
      rcases cut.cover u with ua | ub | us
      · exact mem_union_left _ (mem_inter.mpr ⟨ua,hu⟩)
      · exact (cut.no_cross w m u ub wu).elim
      · exact mem_union_right _ (mem_filter.mpr ⟨us,wu⟩)
    have size := (card_le_card sub).trans (card_union_le _ _)
    rw [G.card_neighborFinset_eq_degree] at size
    have labels := privatePorts w m h
    omega
  have manyA := internal a aa ah
  have manyV := internal v va vh
  by_cases overlap : (U a ∩ U v).Nonempty
  · obtain ⟨w,hw⟩ := overlap
    exact Graph189PrivateQuota.exact_two hc
      ((G.mem_neighborFinset a w).mp (mem_inter.mp (mem_inter.mp hw).1).2)
      ((G.mem_neighborFinset v w).mp (mem_inter.mp (mem_inter.mp hw).2).2).symm ne no
  have both : Disjoint (U a) (U v) :=
    Finset.disjoint_left.mpr fun _ ha hv => overlap ⟨_,mem_inter.mpr ⟨ha,hv⟩⟩
  have card := card_union_of_disjoint both
  have av : a∉U a ∪ U v := by
    intro ha
    rcases mem_union.mp ha with ha | ha
    · exact G.loopless.irrefl a ((G.mem_neighborFinset a a).mp (mem_inter.mp ha).2)
    · exact no ((G.mem_neighborFinset v a).mp (mem_inter.mp ha).2).symm
  have vv : v∉U a ∪ U v := by
    intro hv
    rcases mem_union.mp hv with hv | hv
    · exact no ((G.mem_neighborFinset a v).mp (mem_inter.mp hv).2)
    · exact G.loopless.irrefl v ((G.mem_neighborFinset v v).mp (mem_inter.mp hv).2)
  have incl : insert a (insert v (U a∪U v))⊆A :=
    insert_subset aa (insert_subset va (union_subset inter_subset_left inter_subset_left))
  have count := card_le_card incl
  rw [card_insert_of_notMem (fun h => (mem_insert.mp h).elim ne av),card_insert_of_notMem vv,card] at count
  omega

#print axioms dense_depth
end Graph189ThreePrivateDensity
