# Four-cut degrees 15 through 18

The same separator calculation reduces these four degrees to finite profiles. This note records the order and range changes. The finite arithmetic alone is not a result for these degrees.

## Uniform lower order

Assume the original condition and connectivity four, and suppose the graph is nontraceable. Let $z$ be a minimum-degree vertex. If deleting $z$ gives a Hamiltonian path, the checked Graph189RootedSplice.order_of_hamiltonian_deletion_up_to_succ_degree at parameter five gives
$$n\ge(5+1)(k-5+2)-1=6k-19.$$
Indeed the minimum degree is at least four by connectivity. This use of the near-deletion lemma only needs $k\ge5$ and does not use the separate degree-19 theorem that derives a contradiction for every such deletion.

If deleting $z$ is nontraceable, the completion at $z$ has minimum degree at least $k$ and connectivity at least four. The checked parameter-four linked exterior gives $n\ge5k-11$. This lower bound also holds in the near-deletion branch by $6k-19\ge5k-11$. Thus the low-cut lemma from four-cut-low-degree-vertex.md shows that every minimum cut has only high anchors.

In the nontraceable-deletion branch, if $z$ is the unique low vertex, its completion raises connectivity to five since no minimum four-cut contains it, while still having minimum degree at least $k$. The checked parameter-five version of the minimum-deletion linked exterior gives $n\ge6k-19$. If all vertices are high, minimum degree equals $k$ and the critical-connectivity theorem produces a completion with connectivity five. The checked parameter-five linked exterior at that vertex gives the same bound. The numerical hypotheses for these two parameter-five linked theorems hold already at $k=15$: $3\cdot5\le k+2$, $2\cdot5+2\le k$, and in the critical case $k+6\le2k$, with the completed minimum degree at least $k$. Thus all nontraceable graphs in these degrees satisfy $n\ge6k-19$.

## Order upper bound and unchanged graph filters

Both sides of any minimum cut have high vertices, by the singleton layer bound $5k-7<6k-19$. Thus their high populations are at least $k-4$, and the general nearest-label lemma applies. At $n\ge5k+11$ take $h=5k+6$ and cap $k+7$ in Graph189FiniteDomain.population_bound. The endpoint products condition holds since $(k+8)(3k-2)>4k^2$ and $(3k-2)(4k-2)>4k^2$ at every $15\le k\le18$. Hence $x\le k+7$ and $y\ge4k-1$. The private inequality is strict, since $4(4k-11+x)+x\le21k-9<20k+24\le4(x+y)$. At $y>4k$ apply the original recut. At $y=4k-1,4k$ the strict classification forces two common labels, but $x>k$. Thus $n\le5k+10$.

In both order ranges, for $y=4k-1$ with a low-only small-side label $i$, we need connectivity of the high small-side subgraph in the first-step proof. Here $x\le k+7$: in the large-order range this was just proved, and below that range it follows from $n\le5k+10$, $y=4k-1$, and the unique low small-side vertex. Every high small-side vertex misses $i$ and has at most three anchor neighbors, so the high small-side induced graph has minimum degree at least $k-4$. If disconnected, its order would be at least $2(k-3)>k+7$. The rest of the low-only proof from degrees 19 and 20 applies. If $x=k-4$ then all high small-side vertices are full by degree, excluding the low-only branch. If $x=k-3$, a suitable private recut or the one-label incidence contradiction applies. If $x\ge k-2$, use the direct contradiction from degree 21. In particular the uniform two-common conclusion never needs a high contact at $i$ in the exceptional branch.

The stricter support-difference and co-singleton bounds, and the one-common slack proof from degrees 21 and 22, apply unchanged: the inputs are $x+y\ge6k-24$, $y\ge4k-1$, $n>4k+3$, and $2k+23>3k$. The same direct or private-recut arguments from degrees 19 through 23 cover each near-equality value $x\ge k-4$. For $y>4k$, the final existing private recut applies once the finite rows are eliminated. Its reorientation only requires $n\ge4k+5$, which follows from $n\ge6k-19$.

The arithmetic filter runs from $6k-19$ through $5k+10$. Exclude rows with $x<k-4$ by the actual degree bound. It leaves the following rows and distinct pairs. All use the weak edge-order option.

| Degree | Rows | Pairs | Profiles |
|---|---:|---:|---:|
| 15 | 389 | 206 | 1030 |
| 16 | 369 | 197 | 985 |
| 17 | 347 | 187 | 935 |
| 18 | 315 | 172 | 860 |

## Degree 18 replay outcome

The degree-18 run covers all 860 profile keys from the 315 order rows and 172 distinct pairs. The ordinary model gives 852 UNSAT. Its eight SAT keys are retained in the raw log. The stronger model with port-degree constraints excludes five keys. Two more keys give UNSAT for both terminal obstructions, and hence supply two common high labels and a sufficient private recut. The last key is $(x,y)=(14,70)$ with zero saturated small-side labels. The standalone smallest-population paper lemma forces either an immediate even-quota contradiction or a sufficient recut. The exact key-coverage check matched the combined outcomes to every generated pair and every allowed saturation profile. The separate positive controls give SAT for both encodings.

The combined proof gives an independently audited paper and exact-computation route at degree 18. It supplements the existing connectivity-four work as a replay and formalization aid.
