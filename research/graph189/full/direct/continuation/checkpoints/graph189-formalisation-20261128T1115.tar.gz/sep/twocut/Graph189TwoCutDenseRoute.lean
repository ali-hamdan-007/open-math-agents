import Graph189RootedTrace
import Graph189ExteriorPopulation

open Finset SimpleGraph
namespace Graph189TwoCutDenseRoute

variable {V : Type*} [Fintype V] [DecidableEq V]
variable {G : SimpleGraph V} [DecidableRel G.Adj]

/-- The checked rooted local Ore theorem supplies a spanning route when
every pair away from the prescribed start has degree sum at least the order. -/
theorem of_pair_sum (connected : G.Connected) (z : V)
    (degree : ∀ u v : V, u≠z → v≠z → Fintype.card V≤G.degree u+G.degree v) :
    ∃ v, ∃ p : G.Walk z v, p.IsHamiltonian := by
  apply Graph189RootedTrace.rooted_local_ore connected z
  intro u w v uz vz _ _ _
  exact (card_le_univ _).trans (degree u v uz vz)

/-- The Dirac degree threshold gives a spanning path from any prescribed
vertex, using the verified local Ore route. -/
theorem of_half_floor (z : V) (d : ℕ) (room : Fintype.card V≤2*d)
    (minimum : ∀ x, d≤G.degree x) :
    ∃ v, ∃ p : G.Walk z v, p.IsHamiltonian := by
  classical
  have connected : G.Connected := by
    refine ⟨?_,⟨z⟩⟩
    intro x y
    by_contra far
    let N (u : V) := insert u (G.neighborFinset u)
    have reach (u v : V) (hv : v∈N u) : G.Reachable u v := by
      rcases mem_insert.mp hv with rfl|adj
      · exact Reachable.rfl
      · exact ((G.mem_neighborFinset _ _).mp adj).reachable
    have apart : Disjoint (N x) (N y) := by
      apply Finset.disjoint_left.mpr
      intro v xv yv
      exact far ((reach x v xv).trans (reach y v yv).symm)
    have count := card_le_univ (N x ∪ N y)
    rw [card_union_of_disjoint apart] at count
    have size (u : V) : (N u).card=G.degree u+1 := by
      rw [show N u=insert u (G.neighborFinset u) by rfl,
        card_insert_of_notMem (by simp),G.card_neighborFinset_eq_degree]
    rw [size,size] at count
    have dx := minimum x
    have dy := minimum y
    omega
  apply of_pair_sum connected z
  intro u v _ _
  have du := minimum u
  have dv := minimum v
  omega


/-- A single exceptional vertex can be omitted from the dense route.
If it is the prescribed start, prepend it to a route from a surviving neighbor. -/
theorem omit_one (connected : G.Connected) (root : V) (d : ℕ)
    (two : 2≤Fintype.card V) (bad : Finset V) (few : bad.card≤1)
    (size : Fintype.card V+bad.card≤2*d) (minimum : ∀ x∉bad, d≤G.degree x) :
    ∃ y, ∃ P : G.Walk root y, P.IsPath ∧ Fintype.card V≤P.support.length+bad.card := by
  classical
  by_cases empty : bad=∅
  · have floor (x : V) : d≤G.degree x := minimum x (by simp [empty])
    obtain ⟨y,P,hP⟩ := of_half_floor root d (by omega) floor
    exact ⟨y,P,hP.isPath,by rw [hP.length_support]; omega⟩
  have one : bad.card=1 := by
    have pos := card_pos.mpr (Finset.nonempty_iff_ne_empty.mpr empty)
    omega
  obtain ⟨z,hz⟩ := card_eq_one.mp one
  let S : Set V := {v : V | v≠z}
  let H := G.induce S
  let f := (Embedding.induce (G:=G) S).toHom
  have floor (x : S) : d-1≤H.degree x := by
    have m := minimum x.val (by simpa [hz] using x.property)
    have gone := Graph189ExteriorDegreeCycle.degree_le_deletion_add_one (G:=G) z x
    change G.degree x.val≤H.degree x+1 at gone
    omega
  have cardS : Fintype.card S=Fintype.card V-1 := by
    let e : S ≃ (univ.erase z : Finset V) :=
      Equiv.subtypeEquivRight (fun x => by simp [S])
    rw [Fintype.card_congr e,Fintype.card_coe,card_erase_of_mem (mem_univ _),card_univ]
  have small : Fintype.card S≤2*(d-1) := by omega
  have from_high (x : S) : ∃ y, ∃ P : G.Walk x.val y, P.IsPath ∧
      z∉P.support ∧ P.support.length=Fintype.card S := by
    obtain ⟨y,Q,hQ⟩ := of_half_floor (G:=H) x (d-1) small floor
    let P := Q.map f
    refine ⟨y.val,P,hQ.isPath.map Subtype.val_injective,?_,?_⟩
    · intro hit
      rw [show P.support=Q.support.map f from Walk.support_map _ _] at hit
      obtain ⟨w,_,eq⟩ := List.mem_map.mp hit
      exact w.property eq
    · change (Q.map f).support.length=Fintype.card S
      rw [Walk.support_map,List.length_map,hQ.length_support]
  by_cases eq : root=z
  · subst root
    letI : Nontrivial V := Fintype.one_lt_card_iff_nontrivial.mp (by omega)
    obtain ⟨a,za⟩ := connected.preconnected.exists_adj_of_nontrivial z
    obtain ⟨b,P,hP,fresh,len⟩ := from_high ⟨a,za.ne.symm⟩
    refine ⟨b,.cons za P,hP.cons fresh,?_⟩
    simp only [Walk.support_cons,List.length_cons]
    omega
  · obtain ⟨b,P,hP,_,len⟩ := from_high ⟨root,eq⟩
    exact ⟨b,P,hP,by omega⟩

end Graph189TwoCutDenseRoute
#print axioms Graph189TwoCutDenseRoute.of_pair_sum
#print axioms Graph189TwoCutDenseRoute.of_half_floor
#print axioms Graph189TwoCutDenseRoute.omit_one
