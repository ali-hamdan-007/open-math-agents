import Graph189RootedAfterLeaf
import Graph189TwoCutSideDegree

open Finset SimpleGraph Graph189CutSides
open OMA.R_WrittenOnTheWallII_GraphConjecture189_conjecture189_R1
namespace Graph189TwoCutCommonFreeRoute

variable {V : Type*} [Fintype V] [DecidableEq V] [Nontrivial V]
variable {G : SimpleGraph V} [DecidableRel G.Adj]
variable {A B : Finset V} {p q : V}

/-- The true forbidden initial vertices on a common-free side, including any
low contact. The original graph is used to determine every vertex degree. -/
def forbidden (B : Finset V) (p q : V) : Finset V :=
  B.filter (fun z => (¬G.Adj z p ∧ ¬G.Adj z q) ∨ G.degree z<G.secondSmallestDegree)

/-- The ordinary separator-side route, with one or two possible anchor edges.
A single low internal leaf is handled by deletion. -/
theorem route_of_anchor_bound (sides : CutSides G A B {p,q})
    (connected : (G.induce (B : Set V)).Connected)
    (k5 : 5≤G.secondSmallestDegree) (minimum : 3≤G.minDegree)
    (j : ℕ) (flag : j≤1)
    (anchorBound : ∀ x∈B, (({p,q}:Finset V).filter (G.Adj x)).card≤j+1)
    (few : (forbidden (G:=G) B p q).card≤G.secondSmallestDegree) :
    ∃ a b : (B : Set V), (G.Adj a.val p ∨ G.Adj a.val q) ∧
      G.secondSmallestDegree≤G.degree a.val ∧
      ∃ P : (G.induce (B : Set V)).Walk a b, P.IsPath ∧
        min (B.card-j) (2*G.secondSmallestDegree-1-2*j)≤P.support.length := by
  classical
  let k := G.secondSmallestDegree
  let H := G.induce (B : Set V)
  let Low (z : (B : Set V)) := G.degree z.val<k
  let NoPort (z : (B : Set V)) := ¬G.Adj z.val p ∧ ¬G.Adj z.val q
  let T : Finset (B : Set V) := univ.filter (fun z => NoPort z ∨ Low z)
  let M : Finset (B : Set V) := univ.filter Low
  have exc : M⊆T := fun z hz => mem_filter.mpr ⟨mem_univ _, Or.inr (mem_filter.mp hz).2⟩
  have small : M.card≤1 := by
    apply card_le_one.mpr
    intro x hx y hy
    by_contra ne
    have diff : x.val≠y.val := fun eq => ne (Subtype.ext eq)
    obtain dx|dy := degree_pair (G:=G) x.val y.val diff
    · exact (not_lt_of_ge dx) (mem_filter.mp hx).2
    · exact (not_lt_of_ge dy) (mem_filter.mp hy).2
  let f : (B : Set V) ↪ V := ⟨Subtype.val,Subtype.val_injective⟩
  have mapped : T.map f=forbidden (G:=G) B p q := by
    ext v
    constructor
    · intro hv
      obtain ⟨x,hx,rfl⟩ := mem_map.mp hv
      exact mem_filter.mpr ⟨x.property,(mem_filter.mp hx).2⟩
    · intro hv
      obtain ⟨vb,cond⟩ := mem_filter.mp hv
      exact mem_map.mpr ⟨⟨v,vb⟩,mem_filter.mpr ⟨mem_univ _,cond⟩,rfl⟩
  have tSize : T.card≤k := by rw [←card_map f,mapped]; exact few
  let D (z : (B : Set V)) := ({p,q}:Finset V).filter (G.Adj z.val)
  have extSmall (z : (B : Set V)) : (D z).card≤j+1 := anchorBound z.val z.property
  have loss (z : (B : Set V)) : G.degree z.val≤H.degree z+(D z).card :=
    Graph189TwoCutSideDegree.loss sides z
  have high (z : (B : Set V)) (hz : z∉M) : k≤G.degree z.val := by
    by_contra h
    exact hz (mem_filter.mpr ⟨mem_univ _,lt_of_not_ge h⟩)
  have ordinary (z : (B : Set V)) (zt : z∈T) (zm : z∉M) : k≤H.degree z := by
    have no : NoPort z := (mem_filter.mp zt).2.resolve_right
      (fun h => zm (mem_filter.mpr ⟨mem_univ _,h⟩))
    have dne : D z=∅ := by
      apply eq_empty_iff_forall_notMem.mpr
      intro x hx
      rcases (show x=p ∨ x=q by simpa using (mem_filter.mp hx).1) with rfl|rfl
      · exact no.1 (mem_filter.mp hx).2
      · exact no.2 (mem_filter.mp hx).2
    have dz := high z zm
    have h := loss z
    rw [dne,card_empty,add_zero] at h
    omega
  let d := k-(j+1)
  have floor (z : (B : Set V)) (zm : z∉M) : d≤H.degree z := by
    have h := high z zm
    have h' := loss z
    have h'' := extSmall z
    dsimp [d]
    omega
  have minInside (z : (B : Set V)) : 1≤H.degree z := by
    have h := minimum.trans (G.minDegree_le_degree z.val)
    have h' := loss z
    have h'' := extSmall z
    omega
  have routed : ∃ a b : (B : Set V), a∉T ∧ ∃ P : H.Walk a b, P.IsPath ∧
      min (Fintype.card (B : Set V)-j) (2*d+1)≤P.support.length := by
    by_cases noLeaf : ∀ v∈M, 2≤H.degree v
    · obtain ⟨z,hz⟩ := sides.right_nonempty
      obtain ⟨a,b,no,_,P,hP,len⟩ := Graph189RootedLongPath.route_of_degree
        connected.preconnected ⟨z,hz⟩ T M exc small
        (fun v ht hm => tSize.trans (ordinary v ht hm)) noLeaf d (by dsimp [d]; omega) floor
      exact ⟨a,b,no,P,hP,(min_le_min (Nat.sub_le _ _) le_rfl).trans len⟩
    push Not at noLeaf
    obtain ⟨leaf,lM,nd⟩ := noLeaf
    have one : H.degree leaf=1 := by have := minInside leaf; omega
    have j1 : j=1 := by
      have h := minimum.trans (G.minDegree_le_degree leaf.val)
      have h' := loss leaf
      have h'' := extSmall leaf
      omega
    let Bad := T.erase leaf
    have badSize : Bad.card+1≤k := (card_erase_add_one (exc lM)).trans_le tSize
    have notLow (v : (B : Set V)) (ne : v≠leaf) : v∉M :=
      fun h => ne (card_le_one.mp small v h leaf lM)
    have ord (v : (B : Set V)) (vBad : v∈Bad) (ne : v≠leaf) : k≤H.degree v :=
      ordinary v (mem_erase.mp vBad).2 (notLow v ne)
    obtain ⟨a,b,no,ne,P,hP,len⟩ := Graph189RootedAfterLeaf.route connected leaf one
      Bad k d (by dsimp [d]; omega) badSize ord (fun v hv => floor v (notLow v hv))
    have away : a∉T := fun h => no (mem_erase.mpr ⟨ne,h⟩)
    exact ⟨a,b,away,P,hP,by simpa only [j1] using len⟩
  obtain ⟨a,b,outsideT,P,hP,len⟩ := routed
  have aport : G.Adj a.val p ∨ G.Adj a.val q := by
    by_contra! no
    exact outsideT (mem_filter.mpr ⟨mem_univ _,Or.inl no⟩)
  refine ⟨a,b,aport,high a (fun h => outsideT (exc h)),P,hP,?_⟩
  rw [Fintype.card_coe] at len
  have eq : 2*d+1=2*k-1-2*j := by dsimp [d]; omega
  simpa only [eq] using len

/-- A common-free side loses at most one anchor edge at each vertex. -/
theorem route (sides : CutSides G A B {p,q})
    (connected : (G.induce (B : Set V)).Connected)
    (k5 : 5≤G.secondSmallestDegree) (minimum : 3≤G.minDegree)
    (free : ∀ x∈B, G.Adj x p → ¬G.Adj x q)
    (few : (forbidden (G:=G) B p q).card≤G.secondSmallestDegree) :
    ∃ a b : (B : Set V), (G.Adj a.val p ∨ G.Adj a.val q) ∧
      G.secondSmallestDegree≤G.degree a.val ∧
      ∃ P : (G.induce (B : Set V)).Walk a b, P.IsPath ∧
        min B.card (2*G.secondSmallestDegree-1)≤P.support.length := by
  have atMostOne (z : V) (zb : z∈B) : (({p,q}:Finset V).filter (G.Adj z)).card≤0+1 :=
    Graph189TwoCutSideDegree.one_anchor free z zb
  simpa using route_of_anchor_bound sides connected k5 minimum 0 (by omega) atMostOne few

/-- With common contacts the two lost anchor edges cost two path vertices.
The optional internal low leaf costs up to one vertex when the side is short. -/
theorem route_any (sides : CutSides G A B {p,q})
    (connected : (G.induce (B : Set V)).Connected)
    (k5 : 5≤G.secondSmallestDegree) (minimum : 3≤G.minDegree)
    (few : (forbidden (G:=G) B p q).card≤G.secondSmallestDegree) :
    ∃ a b : (B : Set V), (G.Adj a.val p ∨ G.Adj a.val q) ∧
      G.secondSmallestDegree≤G.degree a.val ∧
      ∃ P : (G.induce (B : Set V)).Walk a b, P.IsPath ∧
        min (B.card-1) (2*G.secondSmallestDegree-1-2)≤P.support.length := by
  have atMostTwo (z : V) (_ : z∈B) : (({p,q}:Finset V).filter (G.Adj z)).card≤1+1 := by
    have total := card_insert_le p ({q}:Finset V)
    have bound := (card_le_card (filter_subset (G.Adj z) ({p,q}:Finset V))).trans total
    simpa using bound
  simpa using route_of_anchor_bound sides connected k5 minimum 1 (by omega) atMostTwo few

end Graph189TwoCutCommonFreeRoute
#print axioms Graph189TwoCutCommonFreeRoute.route_of_anchor_bound
#print axioms Graph189TwoCutCommonFreeRoute.route
#print axioms Graph189TwoCutCommonFreeRoute.route_any
