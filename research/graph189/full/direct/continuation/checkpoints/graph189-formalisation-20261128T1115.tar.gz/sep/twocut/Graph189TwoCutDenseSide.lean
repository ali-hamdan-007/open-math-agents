import Graph189TwoCutDenseRoute
import Graph189TwoCutSideDegree

open Finset SimpleGraph Graph189CutSides
open OMA.R_WrittenOnTheWallII_GraphConjecture189_conjecture189_R1
namespace Graph189TwoCutDenseSide

variable {V : Type*} [Fintype V] [DecidableEq V] [Nontrivial V]
variable {G : SimpleGraph V} [DecidableRel G.Adj]
variable {A B : Finset V} {p q : V}

/-- On a small common-free side, a route from a prescribed contact loses
at most one vertex, and no vertex when the side contains no low vertex. -/
theorem route (sides : CutSides G A B {p,q})
    (connected : (G.induce (B : Set V)).Connected) (two : 2≤B.card)
    (free : ∀ z∈B, G.Adj z p → ¬G.Adj z q)
    (few : (B.filter (fun z => G.degree z<G.secondSmallestDegree)).card≤1)
    (size : B.card+(B.filter (fun z => G.degree z<G.secondSmallestDegree)).card
      ≤2*G.secondSmallestDegree-2)
    (a : (B : Set V)) :
    ∃ b, ∃ P : (G.induce (B : Set V)).Walk a b, P.IsPath ∧
      B.card≤P.support.length+(B.filter (fun z => G.degree z<G.secondSmallestDegree)).card := by
  classical
  let k := G.secondSmallestDegree
  let H := G.induce (B : Set V)
  let Bad : Finset (B : Set V) := univ.filter (fun v => G.degree v.val<k)
  let f : (B : Set V) ↪ V := ⟨Subtype.val,Subtype.val_injective⟩
  have map : Bad.map f=B.filter (fun z => G.degree z<k) := by
    ext v
    constructor
    · intro hv
      obtain ⟨x,hx,rfl⟩ := mem_map.mp hv
      exact mem_filter.mpr ⟨x.property,(mem_filter.mp hx).2⟩
    · intro hv
      obtain ⟨vb,cond⟩ := mem_filter.mp hv
      exact mem_map.mpr ⟨⟨v,vb⟩,mem_filter.mpr ⟨mem_univ _,cond⟩,rfl⟩
  have eq : Bad.card=(B.filter (fun z => G.degree z<k)).card := by
    rw [←map,card_map]
  have minDegree (v : (B : Set V)) (hv : v∉Bad) : k-1≤H.degree v := by
    have high : k≤G.degree v.val := by
      by_contra! low
      exact hv (mem_filter.mpr ⟨mem_univ _,low⟩)
    have decline := Graph189TwoCutSideDegree.loss sides v
    have counts := Graph189TwoCutSideDegree.one_anchor free v.val v.property
    change G.degree v.val≤H.degree v+(({p,q}:Finset V).filter (G.Adj v.val)).card at decline
    omega
  have cardB : Fintype.card (B : Set V)=B.card := Fintype.card_coe _
  have bound : Fintype.card (B : Set V)+Bad.card≤2*(k-1) := by
    rw [cardB,eq]
    have eq' : 2*(k-1)=2*k-2 := by omega
    rwa [eq']
  obtain ⟨b,P,path,len⟩ := Graph189TwoCutDenseRoute.omit_one connected a (k-1)
    (by rwa [cardB]) Bad (by rwa [eq]) bound minDegree
  exact ⟨b,P,path,by simpa only [cardB,eq] using len⟩

end Graph189TwoCutDenseSide
#print axioms Graph189TwoCutDenseSide.route
