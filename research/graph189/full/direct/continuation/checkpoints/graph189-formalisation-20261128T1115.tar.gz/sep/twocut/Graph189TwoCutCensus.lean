import Graph189TwoAnchorSeparation
import Graph189TwoCutCensusJoint

namespace Graph189TwoCutCensus
open Finset SimpleGraph Graph189PositiveEvenCut
open OMA.R_WrittenOnTheWallII_GraphConjecture189_conjecture189_R1
variable {V : Type*} [Fintype V] [DecidableEq V]
variable {G : SimpleGraph V} [DecidableRel G.Adj]
variable {A B : Finset V} {p q : V}

/-- A private contact near the opposite anchor charges its own opposite
ports at distance two and the nonports nearest the other anchor at four. -/
theorem private_row (hc : G.Connected) (sides : Graph189CutSides.CutSides G A B {p,q})
    {e : V} (ea : e∈A) (ep : G.Adj e p) (eq : G.dist e q=2)
    (R : Finset V) (rB : R⊆B)
    (near : ∀ y∈R, 3≤G.dist p y ∧ G.dist q y=2)
    {k : ℕ} (cap : G.distEven e≤k+1) :
    (B.filter (G.Adj p)).card+R.card+1≤k := by
  classical
  let P := B.filter (G.Adj p)
  have pP : P⊆evenOthers G e := by
    intro y hy
    obtain ⟨yb,py⟩ := mem_filter.mp hy
    have xy : e≠y := fun h => disjoint_left.mp sides.apart (h ▸ ea) yb
    have l := (hc e y).one_lt_dist_of_ne_of_not_adj xy (sides.no_cross e ea y yb)
    have h := G.dist_le (Walk.cons ep (.cons py .nil))
    change G.dist e y≤2 at h
    exact mem_even_others xy.symm (by rw [show G.dist e y=2 by omega]; exact ⟨1,rfl⟩)
  have pR : R⊆evenOthers G e := by
    intro y yr
    have xy : e≠y := fun h => disjoint_left.mp sides.apart (h ▸ ea) (rB yr)
    obtain ⟨pd,qd⟩ := near y yr
    obtain ⟨i,hi,split⟩ := separator_distance hc sides ea (rB yr)
    have tr := hc.dist_triangle (u:=e) (v:=q) (w:=y)
    rw [eq,qd] at tr
    have lower : 4≤G.dist e y := by
      rcases (show i=p ∨ i=q by simpa using hi) with rfl|rfl
      · have h := dist_eq_one_iff_adj.mpr ep
        omega
      · omega
    exact mem_even_others xy.symm (by rw [show G.dist e y=4 by omega]; exact ⟨2,rfl⟩)
  have notQ : q∉B := fun qb => disjoint_left.mp sides.right_cut qb (by simp)
  have eQ : q∈evenOthers G e :=
    mem_even_others (by intro h; rw [h,dist_self] at eq; omega) (by rw [eq]; exact ⟨1,rfl⟩)
  have sub : insert q (P∪R)⊆evenOthers G e := by
    intro v h
    rcases mem_insert.mp h with rfl|h
    · exact eQ
    exact (mem_union.mp h).elim pP pR
  have apart : Disjoint P R := by
    apply Finset.disjoint_left.mpr
    intro v vp vr
    have h := dist_eq_one_iff_adj.mpr (mem_filter.mp vp).2
    have d := (near v vr).1
    omega
  have out : q∉P∪R := fun h =>
    notQ ((mem_union.mp h).elim (fun hp => (mem_filter.mp hp).1) rB)
  have count := (card_le_card sub).trans (even_others_card cap)
  rw [card_insert_of_notMem out,card_union_of_disjoint apart] at count
  exact count

/-- The two sides' second layers are disjoint and an even anchor-to-anchor
distance takes a further place. -/
theorem anchor_row (sides : Graph189CutSides.CutSides G A B {p,q})
    (diff : p≠q) (R : Finset V) (rB : R⊆B)
    (rTwo : ∀ x∈R, G.dist p x=2) {k : ℕ} (cap : G.distEven p≤k+1) :
    (A.filter (fun x => G.dist p x=2)).card+R.card+
      (if G.dist p q=2 then 1 else 0)≤k := by
  classical
  let P := A.filter (fun x => G.dist p x=2)
  have ps : p∈({p,q}:Finset V) := by simp
  have qs : q∈({p,q}:Finset V) := by simp
  have apart : Disjoint P R := sides.apart.mono (filter_subset _ _) rB
  have pR : P∪R⊆evenOthers G p := by
    intro x hx
    have h : G.dist p x=2 := (mem_union.mp hx).elim (fun hp => (mem_filter.mp hp).2) (rTwo x)
    exact mem_even_others (by rintro rfl; simp at h) (by rw [h]; exact ⟨1,rfl⟩)
  by_cases pq : G.dist p q=2
  · have next : insert q (P∪R)⊆evenOthers G p := by
      intro x hx
      rcases mem_insert.mp hx with rfl|hr
      · exact mem_even_others diff.symm (by rw [pq]; exact ⟨1,rfl⟩)
      · exact pR hr
    have out : q∉P∪R := by
      intro h
      rcases mem_union.mp h with pa|rr
      · exact disjoint_left.mp sides.left_cut (mem_filter.mp pa).1 qs
      · exact disjoint_left.mp sides.right_cut (rB rr) qs
    have count := (card_le_card next).trans (even_others_card cap)
    rw [card_insert_of_notMem out,card_union_of_disjoint apart] at count
    simpa only [if_pos pq] using count
  · have count := (card_le_card pR).trans (even_others_card cap)
    rw [card_union_of_disjoint apart] at count
    simpa only [if_neg pq,Nat.add_zero] using count

noncomputable def singlyNear (B : Finset V) (p q : V) : Finset V :=
  B.filter (fun w => G.dist p w=2 ∧ 3≤G.dist q w)

noncomputable def twiceNear (B : Finset V) (p q : V) : Finset V :=
  B.filter (fun w => G.dist p w=2 ∧ G.dist q w=2)

/-- The two private representatives supply the sharpened opposite-side
census. The ignored set L can be taken to be just the possible low vertex. -/
theorem private_census (hc : G.Connected) (sides : Graph189CutSides.CutSides G A B {p,q})
    {e f : V} (ea : e∈A) (fa : f∈A)
    (ep : G.Adj e p) (eq : G.dist e q=2) (fq : G.Adj f q) (fp : G.dist f p=2)
    {k : ℕ} (capE : G.distEven e≤k+1) (capF : G.distEven f≤k+1)
    (L : Finset V)
    (near : ∀ y∈B, y∉L → ¬G.Adj p y → ¬G.Adj q y → G.dist p y=2 ∨ G.dist q y=2) :
    B.card+((B.filter (G.Adj p))∩(B.filter (G.Adj q))).card+2
      ≤2*k+(twiceNear (G:=G) B p q).card+L.card := by
  classical
  let P := B.filter (G.Adj p)
  let Q := B.filter (G.Adj q)
  let X := singlyNear (G:=G) B p q
  let Y := singlyNear (G:=G) B q p
  let W := twiceNear (G:=G) B p q
  have simple : Graph189CutSides.CutSides G A B {q,p} := by
    simpa only [Finset.pair_comm] using sides
  have rowP := private_row hc sides ea ep eq Y (filter_subset _ _)
    (fun y hy => ⟨(mem_filter.mp hy).2.2,(mem_filter.mp hy).2.1⟩) capE
  have rowQ := private_row hc simple fa fq fp X (filter_subset _ _)
    (fun y hy => ⟨(mem_filter.mp hy).2.2,(mem_filter.mp hy).2.1⟩) capF
  have cover : B⊆(((P∪Q)∪(X∪Y))∪W)∪L := by
    intro y yb
    by_cases yl : y∈L
    · exact mem_union_right _ yl
    apply mem_union_left
    by_cases py : G.Adj p y
    · exact mem_union_left _ (mem_union_left _ (mem_union_left _ (mem_filter.mpr ⟨yb,py⟩)))
    by_cases qy : G.Adj q y
    · exact mem_union_left _ (mem_union_left _ (mem_union_right _ (mem_filter.mpr ⟨yb,qy⟩)))
    have pne : p≠y := fun h => disjoint_left.mp sides.right_cut yb
      (h ▸ (by simp : p∈({p,q}:Finset V)))
    have qne : q≠y := fun h => disjoint_left.mp sides.right_cut yb
      (h ▸ (by simp : q∈({p,q}:Finset V)))
    have pd := (hc p y).one_lt_dist_of_ne_of_not_adj pne py
    have qd := (hc q y).one_lt_dist_of_ne_of_not_adj qne qy
    rcases near y yb yl py qy with hp|hq
    · by_cases two : G.dist q y=2
      · exact mem_union_right _ (mem_filter.mpr ⟨yb,hp,two⟩)
      · exact mem_union_left _ (mem_union_right _ (mem_union_left _
          (mem_filter.mpr ⟨yb,hp,by omega⟩)))
    · by_cases two : G.dist p y=2
      · exact mem_union_right _ (mem_filter.mpr ⟨yb,two,hq⟩)
      · exact mem_union_left _ (mem_union_right _ (mem_union_right _
          (mem_filter.mpr ⟨yb,hq,by omega⟩)))
  have bound := card_le_card cover
  have pq := card_union_add_card_inter P Q
  have xy := card_union_le X Y
  have a := card_union_le (P∪Q) (X∪Y)
  have b := card_union_le ((P∪Q)∪(X∪Y)) W
  have c := card_union_le (((P∪Q)∪(X∪Y))∪W) L
  change P.card+Y.card+1≤k at rowP
  change Q.card+X.card+1≤k at rowQ
  change B.card+(P∩Q).card+2≤2*k+W.card+L.card
  omega

/-- Summing the anchor rows counts both classes of singly near nonports and
counts each doubly near nonport twice. A fixed ignored subset of A lets the
same assertion serve both the common-free and shallow cases. -/
theorem anchor_census (sides : Graph189CutSides.CutSides G A B {p,q}) (diff : p≠q)
    (L : Finset V) (coverA : ∀ a∈A, a∉L → G.dist p a=2 ∨ G.dist q a=2)
    {k : ℕ} (capP : G.distEven p≤k+1) (capQ : G.distEven q≤k+1) :
    A.card+(singlyNear (G:=G) B p q).card+(singlyNear (G:=G) B q p).card+
      2*(twiceNear (G:=G) B p q).card+2*(if G.dist p q=2 then 1 else 0)
      ≤2*k+L.card := by
  classical
  let X := singlyNear (G:=G) B p q
  let Y := singlyNear (G:=G) B q p
  let W := twiceNear (G:=G) B p q
  let P := A.filter (fun a => G.dist p a=2)
  let Q := A.filter (fun a => G.dist q a=2)
  have xb : X⊆B := filter_subset _ _
  have yb : Y⊆B := filter_subset _ _
  have wb : W⊆B := filter_subset _ _
  have px : ∀ x∈X∪W, G.dist p x=2 := by
    intro x h
    exact (mem_union.mp h).elim (fun hx => (mem_filter.mp hx).2.1) (fun hw => (mem_filter.mp hw).2.1)
  have qy : ∀ y∈Y∪W, G.dist q y=2 := by
    intro y h
    exact (mem_union.mp h).elim (fun hy => (mem_filter.mp hy).2.1) (fun hw => (mem_filter.mp hw).2.2)
  have xw : Disjoint X W := by
    apply Finset.disjoint_left.mpr
    intro x hx hw
    have h := (mem_filter.mp hx).2.2
    have e := (mem_filter.mp hw).2.2
    omega
  have yw : Disjoint Y W := by
    apply Finset.disjoint_left.mpr
    intro x hy hw
    have h := (mem_filter.mp hy).2.2
    have e := (mem_filter.mp hw).2.1
    omega
  have swapped : Graph189CutSides.CutSides G A B {q,p} := by
    simpa only [Finset.pair_comm] using sides
  have pRow := anchor_row sides diff (X∪W) (union_subset xb wb) px capP
  have qRow := anchor_row swapped diff.symm (Y∪W) (union_subset yb wb) qy capQ
  rw [card_union_of_disjoint xw] at pRow
  rw [card_union_of_disjoint yw,dist_comm q p] at qRow
  have cover : A⊆(P∪Q)∪L := by
    intro a aa
    by_cases al : a∈L
    · exact mem_union_right _ al
    rcases coverA a aa al with e|e
    · exact mem_union_left _ (mem_union_left _ (mem_filter.mpr ⟨aa,e⟩))
    · exact mem_union_left _ (mem_union_right _ (mem_filter.mpr ⟨aa,e⟩))
  have count := (card_le_card cover).trans (card_union_le _ _)
  have pair := card_union_le P Q
  change P.card+(X.card+W.card)+(if G.dist p q=2 then 1 else 0)≤k at pRow
  change Q.card+(Y.card+W.card)+(if G.dist p q=2 then 1 else 0)≤k at qRow
  change A.card+X.card+Y.card+2*W.card+2*(if G.dist p q=2 then 1 else 0)≤2*k+L.card
  omega

/-- One common contact counts the union of both opposite port sets. -/
theorem common_ports (hc : G.Connected)
    (sides : Graph189CutSides.CutSides G A B {p,q}) {e : V} (ea : e∈A)
    (ep : G.Adj e p) (eq : G.Adj e q) {k : ℕ} (cap : G.distEven e≤k+1) :
    ((B.filter (G.Adj p))∪(B.filter (G.Adj q))).card≤k := by
  classical
  have seen {a y : V} (yb : y∈B) (ea' : G.Adj e a) (ay : G.Adj a y) :
      y∈evenOthers G e := by
    have ne : e≠y := fun h => disjoint_left.mp sides.apart (h ▸ ea) yb
    have lo := (hc e y).one_lt_dist_of_ne_of_not_adj ne (sides.no_cross e ea y yb)
    have hi := G.dist_le (Walk.cons ea' (.cons ay .nil))
    change G.dist e y≤2 at hi
    exact mem_even_others ne.symm (by rw [show G.dist e y=2 by omega]; exact ⟨1,rfl⟩)
  have sub : (B.filter (G.Adj p))∪(B.filter (G.Adj q))⊆evenOthers G e := by
    intro y hy
    rcases mem_union.mp hy with hp|hq
    · obtain ⟨yb,py⟩ := mem_filter.mp hp
      exact seen yb ep py
    · obtain ⟨yb,qy⟩ := mem_filter.mp hq
      exact seen yb eq qy
  exact (card_le_card sub).trans (even_others_card cap)

variable [Nontrivial V]

/-- If the opposite side has at least k−1 high vertices, a high vertex
must be within distance two of one of the anchors. -/
theorem high_near_anchor (hc : G.Connected) (cap : ∀ v, G.distEven v≤1+G.secondSmallestDegree)
    (sides : Graph189CutSides.CutSides G A B {p,q})
    (small : ∀ T : Finset V, T.card<2 → (G.induce {v : V | v∉T}).Connected)
    (two : 2≤G.secondSmallestDegree)
    (opposite : G.secondSmallestDegree≤(B.filter (fun y => G.secondSmallestDegree≤G.degree y)).card+1)
    {x : V} (xa : x∈A) (high : G.secondSmallestDegree≤G.degree x) :
    G.dist x p≤2 ∨ G.dist x q≤2 := by
  classical
  let D := B.filter (fun y => G.secondSmallestDegree≤G.degree y)
  by_contra! far
  have four (y : V) (yd : y∈D) : G.dist x y=4 := by
    obtain ⟨yb,hy⟩ := mem_filter.mp yd
    obtain ⟨i,si,split⟩ := separator_distance hc sides xa yb
    have ne : i≠y := fun e => disjoint_left.mp sides.right_cut yb (e ▸ si)
    have dy : 0<G.dist i y := Nat.pos_of_ne_zero (fun eq => ne (hc.dist_eq_zero_iff.mp eq))
    have upper := high_distance_four hc cap high hy
    rcases (show i=p ∨ i=q by simpa using si) with rfl|rfl <;> omega
  have budget := four_layer_quota hc small two
    (show G.distEven x≤G.secondSmallestDegree+1 by simpa only [Nat.add_comm 1] using cap x) D four
  change G.secondSmallestDegree≤D.card+1 at opposite
  omega

/-- With a common contact and an opposite side of at least 2k vertices,
every high vertex of A is a port. -/
theorem shallow_if_common (hc : G.Connected) (cap : ∀ v, G.distEven v≤1+G.secondSmallestDegree)
    (sides : Graph189CutSides.CutSides G A B {p,q}) (different : p≠q)
    (small : ∀ T : Finset V, T.card<2 → (G.induce {v : V | v∉T}).Connected)
    (two : 2≤G.secondSmallestDegree) (large : 2*G.secondSmallestDegree≤B.card)
    (common : ∃ e∈A, G.Adj e p ∧ G.Adj e q) :
    ∀ x∈A, G.secondSmallestDegree≤G.degree x → G.Adj x p ∨ G.Adj x q := by
  intro x xa high
  by_contra! miss
  have no : ∀ i∈({p,q}:Finset V), ¬G.Adj x i := by
    intro i hi
    rcases (show i=p ∨ i=q by simpa using hi) with rfl|rfl
    · exact miss.1
    · exact miss.2
  exact (large_pair_nonport hc cap different sides small two large xa high no).2 common

/-- Triangles give a high representative for either label on a common-free
side. This works even if its first selected contact was the low vertex. -/
theorem high_private_representative (sides : Graph189CutSides.CutSides G A B {p,q})
    (different : p≠q)
    (small : ∀ T : Finset V, T.card<2 → (G.induce {v : V | v∉T}).Connected)
    (triangle : ∀ x y, G.Adj x y → ∃ z, G.Adj x z ∧ G.Adj y z)
    (noCommon : ∀ x∈A, G.Adj x p → ¬G.Adj x q) :
    ∃ x∈A, G.Adj x p ∧ G.secondSmallestDegree≤G.degree x := by
  classical
  have size : ({p,q}:Finset V).card=2 := by simp [different]
  have smaller : ∀ T : Finset V, T.card<({p,q}:Finset V).card →
      (G.induce {v : V | v∉T}).Connected := by rwa [size]
  obtain ⟨x,xa,xp⟩ := (sides.contacts_of_minimum smaller (show p∈({p,q}:Finset V) by simp)).1
  by_cases high : G.secondSmallestDegree≤G.degree x
  · exact ⟨x,xa,xp,high⟩
  obtain ⟨y,py,xy⟩ := triangle p x xp.symm
  rcases sides.cover y with ya|yb|ys
  · exact ⟨y,ya,py.symm,(degree_pair (G:=G) x y xy.ne).resolve_left high⟩
  · exact (sides.no_cross x xa y yb xy).elim
  · rcases (show y=p ∨ y=q by simpa using ys) with rfl|rfl
    · exact (G.loopless.irrefl _ py).elim
    · exact (noCommon x xa xp xy).elim

/-- The low-vertex allowances of two genuine sides share one slot. -/
theorem low_counts (sides : Graph189CutSides.CutSides G A B {p,q}) :
    (A.filter (fun x => G.degree x<G.secondSmallestDegree)).card+
    (B.filter (fun x => G.degree x<G.secondSmallestDegree)).card≤1 := by
  classical
  let L := A.filter (fun x => G.degree x<G.secondSmallestDegree)
  let R := B.filter (fun x => G.degree x<G.secondSmallestDegree)
  let T := univ.filter (fun x => G.degree x<G.secondSmallestDegree)
  have tr : T.card≤1 := by
    apply card_le_one.mpr
    intro x hx y hy
    by_contra ne
    obtain h|h := degree_pair (G:=G) x y ne
    · exact (not_lt_of_ge h) (mem_filter.mp hx).2
    · exact (not_lt_of_ge h) (mem_filter.mp hy).2
  have sub : L∪R⊆T := by
    intro x hx
    exact mem_filter.mpr ⟨mem_univ _,
      (mem_union.mp hx).elim (fun hl => (mem_filter.mp hl).2) (fun hr => (mem_filter.mp hr).2)⟩
  have sum := (card_le_card sub).trans tr
  rw [card_union_of_disjoint (sides.apart.mono (filter_subset _ _) (filter_subset _ _))] at sum
  exact sum

/-- The cut census bounds the omissions available to paths from the two
side contacts, including one unused anchor and a possible low vertex in A. -/
theorem common_free_budget (hc : G.Connected)
    (cap : ∀ v, G.distEven v≤1+G.secondSmallestDegree)
    (sides : Graph189CutSides.CutSides G A B {p,q}) (diff : p≠q)
    {e f : V} (ea : e∈A) (fa : f∈A)
    (ep : G.Adj e p) (eq : G.dist e q=2) (fq : G.Adj f q) (fp : G.dist f p=2)
    (large : 7≤G.secondSmallestDegree) (big : 2*G.secondSmallestDegree≤B.card)
    (smallLower : G.secondSmallestDegree≤A.card)
    (aNear : ∀ a∈A, G.secondSmallestDegree≤G.degree a → G.dist p a=2 ∨ G.dist q a=2)
    (bNear : ∀ b∈B, G.secondSmallestDegree≤G.degree b → ¬G.Adj p b → ¬G.Adj q b →
        G.dist p b=2 ∨ G.dist q b=2)
    {j : ℕ} (flag : j≤1)
    (commonDebit : j≤((B.filter (G.Adj p))∩(B.filter (G.Adj q))).card)
    (anchorDebit : j≤(if G.dist p q=2 then 1 else 0)) :
    let k := G.secondSmallestDegree
    let la := (A.filter (fun x => G.degree x<k)).card
    A.card+la≤2*k-2 ∧ B.card+la+1≤(2*k-1-2*j)+(k+1)/2+1 ∧
      (B.filter (fun x => (¬G.Adj x p ∧ ¬G.Adj x q) ∨ G.degree x<k)).card+3*j≤k := by
  classical
  intro k la
  let LA := A.filter (fun x => G.degree x<k)
  let LB := B.filter (fun x => G.degree x<k)
  have cap' (v : V) : G.distEven v≤k+1 := by simpa only [Nat.add_comm 1] using cap v
  have pRow := private_census (k:=k) hc sides ea fa ep eq fq fp (cap' e) (cap' f) LB
    (fun b bb nb => bNear b bb (by
      by_contra lt
      exact nb (mem_filter.mpr ⟨bb,Nat.lt_of_not_ge lt⟩)))
  have aRow := anchor_census (k:=k) sides diff LA
    (fun a aa na => aNear a aa (by
      by_contra lt
      exact na (mem_filter.mpr ⟨aa,Nat.lt_of_not_ge lt⟩))) (cap' p) (cap' q)
  have low := low_counts sides
  change LA.card+LB.card≤1 at low
  have budget := Graph189TwoCutCensusArithmetic.common_free large big smallLower (by omega) flag
    commonDebit pRow (by omega)
  refine ⟨budget.1,budget.2,?_⟩

  let X := singlyNear (G:=G) B p q
  let Y := singlyNear (G:=G) B q p
  let W := twiceNear (G:=G) B p q
  let F := B.filter fun x => (¬G.Adj x p ∧ ¬G.Adj x q) ∨ G.degree x<k
  have subset : F⊆((X∪Y)∪W)∪LB := by
    intro x hx
    obtain ⟨xb,h⟩ := mem_filter.mp hx
    by_cases lower : G.degree x<k
    · exact mem_union_right _ (mem_filter.mpr ⟨xb,lower⟩)
    have ⟨missP,missQ⟩ := h.resolve_right lower
    have pne : p≠x := fun eq => disjoint_left.mp sides.right_cut xb
      (eq ▸ (by simp : p∈({p,q}:Finset V)))
    have qne : q≠x := fun eq => disjoint_left.mp sides.right_cut xb
      (eq ▸ (by simp : q∈({p,q}:Finset V)))
    have pd := (hc p x).one_lt_dist_of_ne_of_not_adj pne (fun e => missP e.symm)
    have qd := (hc q x).one_lt_dist_of_ne_of_not_adj qne (fun e => missQ e.symm)
    apply mem_union_left
    rcases bNear x xb (Nat.le_of_not_gt lower) (fun e => missP e.symm) (fun e => missQ e.symm) with py|qy
    · by_cases yq : G.dist q x=2
      · exact mem_union_right _ (mem_filter.mpr ⟨xb,py,yq⟩)
      · exact mem_union_left _ (mem_union_left _ (mem_filter.mpr ⟨xb,py,by omega⟩))
    · by_cases yp : G.dist p x=2
      · exact mem_union_right _ (mem_filter.mpr ⟨xb,yp,qy⟩)
      · exact mem_union_left _ (mem_union_right _ (mem_filter.mpr ⟨xb,qy,by omega⟩))
  have count := (card_le_card subset).trans (card_union_le _ _)
  have part := card_union_le (X∪Y) W
  have pair := card_union_le X Y
  change F.card+3*j≤k
  change A.card+X.card+Y.card+2*W.card+2*(if G.dist p q=2 then 1 else 0)≤2*k+LA.card at aRow
  change B.card+((B.filter (G.Adj p))∩(B.filter (G.Adj q))).card+2≤2*k+W.card+LB.card at pRow
  omega

#print axioms common_free_budget
#print axioms low_counts
#print axioms shallow_if_common
#print axioms high_private_representative
#print axioms high_near_anchor
#print axioms common_ports
#print axioms anchor_census
#print axioms private_census
#print axioms anchor_row
#print axioms private_row
end Graph189TwoCutCensus
