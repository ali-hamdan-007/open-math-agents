import Graph189LongestDegreeSum

open Finset SimpleGraph
namespace Graph189RootedLongPath

variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V}
variable [DecidableRel G.Adj]

/-- A longest simple path can be oriented to start at an allowed vertex and
end outside the exceptional set under a degree/count allowance. The exceptional
set can contain one low vertex, even when it is a contact. -/
theorem allowed_endpoints {x y : V} (p : G.Walk x y) (hp : p.IsPath) (pos : 0 < p.length)
    (longest : ∀ {u v}, ∀ q : G.Walk u v, q.IsPath → q.length ≤ p.length)
    (T M : Finset V) (little : M.card ≤ 1)
    (ordinary : ∀ z ∈ T, z ∉ M → T.card ≤ G.degree z)
    (special : ∀ z ∈ M, 2 ≤ G.degree z) :
    ∃ a b, a ∉ T ∧ b ∉ M ∧ ∃ q : G.Walk a b, q.IsPath ∧ q.length=p.length := by
  have separate : x ≠ y := by
    intro eq
    exact (Nat.ne_of_gt pos) ((hp.nil_iff_eq.mpr eq).length_eq_zero)
  have choose_exception {a b : V} (r : G.Walk a b) (hr : r.IsPath)
      (size : r.length=p.length) (ha : a ∈ M) :
      ∃ z ∉ M, ∃ s : G.Walk z b, s.IsPath ∧ s.length=p.length := by
    have mx {u v} (q : G.Walk u v) (hq : q.IsPath) : q.length ≤ r.length :=
      (longest q hq).trans_eq size.symm
    have small : (M.erase b).card < G.degree a :=
      lt_of_le_of_lt ((card_le_card (erase_subset _ _)).trans little)
        (lt_of_lt_of_le (by decide : 1 < 2) (special a ha))
    obtain ⟨z,out,s,hs,len,_⟩ := Graph189RootedRotation.outside r hr mx M small
    exact ⟨z,out,s,hs,len.trans size⟩
  have good : ∃ a b, a ∉ M ∧ b ∉ M ∧ ∃ q : G.Walk a b, q.IsPath ∧ q.length=p.length := by
    by_cases hxm : x ∈ M
    · have hym : y ∉ M := fun h => separate (card_le_one.mp little x hxm y h)
      obtain ⟨a,ha,q,hq,len⟩ := choose_exception p hp rfl hxm
      exact ⟨a,y,ha,hym,q,hq,len⟩
    by_cases hym : y ∈ M
    · obtain ⟨a,ha,q,hq,len⟩ :=
        choose_exception p.reverse hp.reverse p.length_reverse hym
      exact ⟨a,x,ha,hxm,q,hq,len⟩
    exact ⟨x,y,hxm,hym,p,hp,rfl⟩
  obtain ⟨a,b,ha,hb,q,hq,len⟩ := good
  by_cases hat : a ∈ T
  · by_cases hbt : b ∈ T
    · have mx {u v} (r : G.Walk u v) (hr : r.IsPath) : r.length ≤ q.length :=
        (longest r hr).trans_eq len.symm
      have size : (T.erase b).card < G.degree a := by
        have cb : 0 < T.card := card_pos.mpr ⟨b,hbt⟩
        rw [card_erase_of_mem hbt]
        have bound := ordinary a hat ha
        omega
      obtain ⟨c,hc,r,hr,rlen,_⟩ := Graph189RootedRotation.outside q hq mx T size
      exact ⟨c,b,hc,hb,r,hr,rlen.trans len⟩
    exact ⟨b,a,hbt,ha,q.reverse,hq.reverse,q.length_reverse.trans len⟩
  exact ⟨a,b,hat,hb,q,hq,len⟩

/-- Route from an allowed vertex of a connected graph using its endpoint degree
floor and the degree/count allowance. -/
theorem route {x y : V} (p : G.Walk x y) (hp : p.IsPath)
    (longest : ∀ {u v}, ∀ q : G.Walk u v, q.IsPath → q.length ≤ p.length)
    (connected : G.Preconnected) (two : 2 ≤ p.length)
    (T M : Finset V) (exclusion : M ⊆ T) (little : M.card ≤ 1)
    (ordinary : ∀ z ∈ T, z ∉ M → T.card ≤ G.degree z)
    (special : ∀ z ∈ M, 2 ≤ G.degree z)
    (d : ℕ) (minimum : ∀ z, z ∉ M → d ≤ G.degree z) :
    ∃ a b, a ∉ T ∧ b ∉ M ∧ ∃ q : G.Walk a b, q.IsPath ∧
      min (Fintype.card V) (2*d+1) ≤ q.support.length := by
  obtain ⟨a,b,ha,hb,q,hq,len⟩ :=
    allowed_endpoints p hp (by omega) longest T M little ordinary special
  refine ⟨a,b,ha,hb,q,hq,?_⟩
  have boundA := minimum a (fun h => ha (exclusion h))
  have boundB := minimum b hb
  have mx {u v} (r : G.Walk u v) (hr : r.IsPath) : r.length ≤ q.length :=
    (longest r hr).trans_eq len.symm
  exact (min_le_min le_rfl (by omega)).trans
    (Graph189LongestDegreeSum.length_bound q hq connected (len.symm ▸ two) mx)


omit [DecidableEq V] [DecidableRel G.Adj] in
/-- The finite family of simple-path lengths has a maximal realization. -/
theorem exists_longest (z : V) :
    ∃ x y, ∃ p : G.Walk x y, p.IsPath ∧
      ∀ {u v}, ∀ r : G.Walk u v, r.IsPath → r.length ≤ p.length := by
  classical
  let Good (n : ℕ) := ∃ a b, ∃ r : G.Walk a b, r.IsPath ∧ r.length=n
  have base : Good 0 := ⟨z,z,.nil,by simp,rfl⟩
  obtain ⟨x,y,p,hp,sz⟩ := Nat.findGreatest_spec (Nat.zero_le (Fintype.card V)) base
  refine ⟨x,y,p,hp,?_⟩
  intro a b r hr
  rw [sz]
  have len := r.length_support
  have card := hr.support_nodup.length_le_card
  exact Nat.le_findGreatest (by omega) (show Good r.length from ⟨a,b,r,hr,rfl⟩)

/-- The graph-facing version requires only the degree and forbidden-count
hypotheses and one vertex, rather than a chosen longest path. -/
theorem route_of_degree (connected : G.Preconnected) (z : V)
    (T M : Finset V) (exclusion : M ⊆ T) (little : M.card ≤ 1)
    (ordinary : ∀ z ∈ T, z ∉ M → T.card ≤ G.degree z)
    (special : ∀ z ∈ M, 2 ≤ G.degree z)
    (d : ℕ) (d2 : 2 ≤ d) (minimum : ∀ z, z ∉ M → d ≤ G.degree z) :
    ∃ a b, a ∉ T ∧ b ∉ M ∧ ∃ q : G.Walk a b, q.IsPath ∧
      min (Fintype.card V) (2*d+1) ≤ q.support.length := by
  obtain ⟨a,b,p,hp,mx⟩ := exists_longest (G:=G) z
  have degreeTwo : 2≤G.degree a := by
    by_cases ha : a∈M
    · exact special a ha
    · exact d2.trans (minimum a ha)
  obtain ⟨E,card,inside,_⟩ := Graph189RootedRotation.endpoint_candidates p hp mx
  have h := card_le_card inside
  rw [card,card_erase_of_mem (List.mem_toFinset.mpr p.end_mem_support),
    List.toFinset_card_of_nodup hp.support_nodup,Walk.length_support] at h
  exact route p hp mx connected (by omega) T M exclusion little ordinary special d minimum

end Graph189RootedLongPath
#print axioms Graph189RootedLongPath.allowed_endpoints
#print axioms Graph189RootedLongPath.route
#print axioms Graph189RootedLongPath.exists_longest
#print axioms Graph189RootedLongPath.route_of_degree
