import Graph189RootedLongPath
import Graph189ExteriorPopulation
import Mathlib.Combinatorics.SimpleGraph.Acyclic

open Finset SimpleGraph
namespace Graph189RootedAfterLeaf

variable {V : Type*} [Fintype V] [DecidableEq V]
variable {G : SimpleGraph V} [DecidableRel G.Adj]

/-- Delete the low leaf and temporarily exclude its unique neighbor as an
endpoint. All other endpoint degrees survive the deletion exactly. -/
theorem route (connected : G.Connected) (leaf : V) (one : G.degree leaf=1)
    (bad : Finset V) (k d : ℕ) (d3 : 3≤d) (few : bad.card+1≤k)
    (ordinary : ∀ v∈bad, v≠leaf → k≤G.degree v)
    (minimum : ∀ v≠leaf, d≤G.degree v) :
    ∃ a b, a∉bad ∧ a≠leaf ∧ ∃ P : G.Walk a b, P.IsPath ∧
      min (Fintype.card V-1) (2*d+1)≤P.support.length := by
  classical
  obtain ⟨w,edge,only⟩ := degree_eq_one_iff_existsUnique_adj.mp one
  let S : Set V := {leaf}ᶜ
  let H := G.induce S
  let z : S := ⟨w,by simpa [S] using edge.ne.symm⟩
  let Bad : Finset S := univ.filter (fun v => v.val∈bad)
  let T := insert z Bad
  let M : Finset S := {z}
  have hc : H.Connected := connected.induce_compl_singleton_of_degree_eq_one one
  let emb : S ↪ V := ⟨Subtype.val,Subtype.val_injective⟩
  have size : Bad.card≤bad.card := by
    have sub : Bad.map emb⊆bad := by
      intro v hv
      obtain ⟨x,hx,rfl⟩ := mem_map.mp hv
      exact (mem_filter.mp hx).2
    simpa using card_le_card sub
  have tSize : T.card≤k := (card_insert_le _ _).trans (by omega)
  have exclude : M⊆T := by
    intro v hv
    have eq : v=z := by simpa [M] using hv
    exact mem_insert.mpr (Or.inl eq)
  have kept (v : S) (ne : v≠z) : G.degree v.val=H.degree v := by
    symm
    apply G.degree_induce_of_neighborSet_subset
    intro u hu
    change u≠leaf
    intro eq
    subst u
    have adj : G.Adj v.val leaf := hu
    exact ne (Subtype.ext (only _ adj.symm))
  have still (v : S) : v.val≠leaf := v.property
  have ord (v : S) (vt : v∈T) (vm : v∉M) : T.card≤H.degree v := by
    have vn : v≠z := by simpa [M] using vm
    have mem : v.val∈bad := (mem_filter.mp ((mem_insert.mp vt).resolve_left vn)).2
    exact tSize.trans ((ordinary v.val mem (still v)).trans_eq (kept v vn))
  have special (v : S) (_ : v∈M) : 2≤H.degree v := by
    have bound := minimum v.val (still v)
    have drop := Graph189ExteriorDegreeCycle.degree_le_deletion_add_one (G:=G) leaf v
    change G.degree v.val≤H.degree v+1 at drop
    omega
  have floor (v : S) (vm : v∉M) : d≤H.degree v := by
    have vn : v≠z := by simpa [M] using vm
    exact (minimum v.val (still v)).trans_eq (kept v vn)
  obtain ⟨a,b,ha,_,P,hP,len⟩ := Graph189RootedLongPath.route_of_degree
    hc.preconnected z T M exclude (by simp [M]) ord special d (by omega) floor
  let f := (SimpleGraph.Embedding.induce (G:=G) S).toHom
  have escape : a.val∉bad := by
    intro av
    exact ha (mem_insert_of_mem (mem_filter.mpr ⟨mem_univ _,av⟩))
  have cnt : Fintype.card S=Fintype.card V-1 := by
    let e : S ≃ (univ.erase leaf : Finset V) :=
      Equiv.subtypeEquivRight (fun v => by simp [S])
    rw [Fintype.card_congr e,Fintype.card_coe,card_erase_of_mem (mem_univ _),card_univ]
  refine ⟨a.val,b.val,escape,still a,P.map f,hP.map Subtype.val_injective,?_⟩
  rw [Walk.support_map,List.length_map,←cnt]
  exact len

end Graph189RootedAfterLeaf
#print axioms Graph189RootedAfterLeaf.route
