# Connectivity two at degree nine without a circumference theorem

This extends the [degree-ten argument](two-cut-fan-free-degree-ten.md) to \(k=9\) by closing the shallow side with common contacts and both private types. All other constructions in the [Fan-free proof](two-cut-fan-free.md) still apply at nine. This is an independently audited parallel route to an already established paper case.

Use the notation of the degree-ten note, with \(p,q\) the two anchors. The order bound is \(n\ge31\), the minimum degree is at least three, and every edge is triangular since \(31>3k+2=29\). The large-side case means \(b\ge18\) and \(A\) was chosen minimum among all genuine two-cut sides. In the balanced mixed case \(b\le17\), \(B\) is common-free and the shallow side \(A\) may be the larger side. As in the degree-ten argument, the high private vertices of \(A\) are two steps from their missing anchor and a low-only private representative is also two steps away. Thus \(a\ge9\) and every high \(B\) nonport is near at least one anchor. The adjacent-anchor branch still gives \(n\le29\), so assume the anchors are nonadjacent. The two census inequalities are

\[
 b\le16+w+\ell-t,\qquad
 n+w\le27+c+L .
\]

## Common points in \(B\)

Here \(a\le9+\ell_A\) since every \(A\) port is charged by a common \(B\) port. The size bounds and \(c\le a-2\) give

\[
 w\ge4+t-(\ell+\ell_A),\qquad
 b+w\le23+L,\qquad b\ge20-\ell_A .
\]

If \(\ell_A=0\), these inequalities imply \(w\le4\). Since \(t\ge1\), equality forces \(t=1,\ \ell=L=1,\ w=4,\ a=9,\ b=20\). In particular \(A\) has exactly nine ports. If \(\ell_A=1\) and the low \(A\) vertex is a port, \(a\le9\) and \(b\ge20\); then \(w\le4\) contradicts \(w\ge4+t\). If the low \(A\) vertex is a nonport, \(c\le a-3\) strengthens \(b+w\le22+L=23\). Then \(b\ge19\) and \(w\le4\), so equality forces \(t=1,\ w=4,\ a=10,\ b=19\). Again \(A\) has exactly nine ports.

In either equality case a common \(B\) port uses its entire even budget on the nine \(A\) ports. It has no internal second-layer vertex and is internally universal by connectedness. Every high \(B\) nonport is therefore near both anchors. Since \(B\) has at most nine ports, the number of such high nonports is at least \(b-9-\ell_B=10\), contrary to \(w=4\).

## Common-free \(B\) and the one unit of census slack

Let \(\alpha,\beta\) be the two \(A\) contact counts, \(\tau\) the number of \(B\) ports, and \(\eta\le\ell_A\) the number of low \(A\) nonports. The contact bounds give \(\alpha,\beta\le8\) and \(\tau\le9\). The exact orders are \(a=\alpha+\beta-c+\eta\) and \(b=\tau+v+w+\ell\).

The two anchor rows count at least \(a-c-\ell_A+v+2w+2\) vertices in total. The last two places are the anchors' mutual distance-two incidences. Keeping the low-nonport debit explicit gives

\[
 n+w\le18+c+\ell_A+\tau+\ell,\qquad
 n\le18+\alpha+\beta-c+w+\ell+\eta .
\]
Consequently
\[
 2n\le36+\alpha+\beta+\tau+\ell_A+\eta+2\ell\le63 .
\]

Thus \(n=31\), at least one \(A\) contact count is eight, the other is at least seven, and \(\tau\ge8\). There must be a low vertex. It cannot be a port in \(B\), since then \(\ell_A+\eta+2\ell=0\) and \(2n\le61\). If it is a port \(z\) in \(A\), then \(\ell_A+\eta+2\ell=1\) and equality throughout forces \(\alpha=\beta=8,\ \tau=9\) and both private representative rows saturated. Every common \(A\) port then uses its quota on the nine \(B\) ports and is adjacent to every other \(A\) port. If \(z\) is common it is therefore internally universal. If \(z\) is private, every high private \(A\) vertex must be adjacent to \(z\) because a common \(A\) port gives an otherwise uncharged distance-two witness. In either case \(z\) has degree at least \(a-1+1\ge9\), a contradiction. The possible low vertex in either side is therefore a nonport.

Let $s=16+w+\ell-b$ be the sum of unused places in the two private representative rows. The first inequality for $n$ remains valid with $n+s$ on its left, so the doubled inequality gives $2n+s\le63$. Thus $s\le1$, and $\tau=8$ lowers the right-hand side to 62 and forces $s=0$. The counts of the charged vertices are the same for any high representative of a given label. If \(\tau=8\), the combined upper bound drops to 62 and both representative rows are saturated. Each high private \(A\) vertex is then adjacent to every common vertex through the shared-label budget. Any two private vertices share a common neighbor, so they must be adjacent as well. A common \(A\) vertex can miss at most one high \(A\) vertex because it already counts eight \(B\) ports. If \(\tau=9\), every common \(A\) vertex is adjacent to every other port and any two private \(A\) vertices share a common neighbor. Each private representative then misses at most one other high \(A\) vertex. In both cases the high core, of order \(m=a-\ell_A\ge8\), has minimum degree at least \(m-2\). Dirac gives an \(A\) path from a high contact of either chosen label, losing at most the low vertex. Both labels have high contacts.

For balanced \(b\le17\), there are at most \(b-\tau\le9\) forbidden \(B\) starts, since every \(B\) port is high. High nonports have internal degree at least nine and the low nonport has internal degree at least three. The ordinary rotation and degree-sum rule spans \(B\) from a high port, since \(2(k-1)+1=17\). Match through the corresponding anchor.

## Large common-free \(B\)

Now \(18\le b\le20\) because \(n=31\) and \(a\ge9\). Choose the label \(p\) with its full eight \(A\) contacts and a high \(B\) port \(x\) of that label. Every \(B\) port is high, and both labels occur at least twice by the triangle condition on each anchor–\(B\) edge. The quota for \(x\) has only one free place after its eight opposite \(A\) ports.

If \(x\) is universal inside \(B\), consider \(B-x\). Every remaining high vertex has degree at least seven there and any low nonport has degree at least two. If \(B-x\) is connected, choose a longest path with both ends high by one rotation away from the low vertex if needed. The degree-sum bound gives at least \(\min(b-1,15)=15\) vertices. Prepending \(x\) yields at least 16, at most four omissions in \(B\). If \(B-x\) is disconnected, each component has a high vertex (the low cannot be a singleton) and therefore order at least eight. There are exactly two components of order at most eleven. Each has a genuine port, because otherwise \(x\) would be a cut vertex of \(G\). The high core in either component has minimum degree at least six and order at most eleven, hence is Hamiltonian by Dirac. Open the first cycle at a genuine port and join through \(x\) to the other opened cycle. At most the low vertex is omitted.

Suppose \(x\) is not universal. It cannot have a neighboring \(q\)-port, because then the missing anchor would use its last quota place and no internal second-layer vertex could exist. Its unique internal second-layer vertex \(g\) therefore separates \(U=N_B[x]\) from \(W=B\setminus(U\cup\{g\})\). No \(q\)-port is in \(U\), and some \(q\)-port is in \(W\). Any \(p\)-port outside \(U\) is at ambient distance two through \(p\) and so must equal \(g\). Thus removing \(p,g\) separates \(U\), and removing \(q,g\) separates \(W\). As \(A\) was chosen minimum, both sets have order at least \(a\). The bounds \(b\ge2a+1,\ n=31,\ a\ge9\) force \(a=9,\ b=20\) and \(9\le|U|,|W|\le10\).

A high vertex has degree at least seven inside its arm after losing at most one anchor contact and \(g\). The high cores have minimum degree at least six after removing the possible low vertex, so they are Hamilton-connected by Ore. The gate has a neighbor in each arm but is not adjacent to \(x\). In \(U\), finish the high-core path from \(x\) at a high gate neighbor if one exists. If the only gate neighbor is the low nonport, its degree at least three gives at least two high neighbors inside \(U\). Choose one different from \(x\) as the path end and then traverse the low vertex to the gate. In \(W\), start a high-core path at a high gate neighbor, or enter through the sole low neighbor and then go to a high neighbor. If the gate itself is low, both arms are entirely high. This route starts at \(x\) and omits at most one \(B\) vertex.

Matching the \(A\) route costs at most one more omitted vertex, plus the unused anchor. Even the 16-vertex route in the universal case therefore omits at most six overall, contradicting the existing gap. The large missing-private cutoff still works since \(3k-7=20>2k+1=19\), and the original balanced routing uses the same strict inequalities at \(k=9\). This completes the Fan-free paper reduction at degree nine. There is no Lean or official verdict for this extension.
