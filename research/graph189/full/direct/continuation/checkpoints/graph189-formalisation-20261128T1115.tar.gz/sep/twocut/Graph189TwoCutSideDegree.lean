import Graph189ExteriorPopulation
import Graph189CutSides

open Finset SimpleGraph Graph189CutSides
namespace Graph189TwoCutSideDegree

variable {V : Type*} [Fintype V] [DecidableEq V]
variable {G : SimpleGraph V} [DecidableRel G.Adj]
variable {A B : Finset V} {p q : V}

/-- Degree loss on an induced side is bounded by actual anchor contacts. -/
theorem loss (sides : CutSides G A B {p,q}) (z : (B : Set V)) :
    G.degree z.val ≤ (G.induce (B : Set V)).degree z +
      (({p,q}:Finset V).filter (G.Adj z.val)).card := by
  classical
  let D := ({p,q}:Finset V).filter (G.Adj z.val)
  let N := G.neighborFinset z.val
  have sub : N⊆(N∩B)∪D := by
    intro v hv
    have zv := (G.mem_neighborFinset _ _).mp hv
    rcases sides.cover v with av|bv|sep
    · exact (sides.no_cross v av z.val z.property zv.symm).elim
    · exact mem_union_left _ (mem_inter.mpr ⟨hv,bv⟩)
    · exact mem_union_right _ (mem_filter.mpr ⟨sep,zv⟩)
  have val : (G.induce (B : Set V)).degree z=(N∩B).card := by
    rw [Graph189ExteriorDegreeCycle.degree_induce_filter]
    congr 1
    ext v
    simp [N]
  change N.card≤(G.induce (B : Set V)).degree z+(D).card
  exact (card_le_card sub).trans (val.symm ▸ card_union_le (N∩B) (D))

omit [Fintype V] in
/-- A common-free side loses at most one anchor contact per vertex. -/
theorem one_anchor
    (free : ∀ x∈B, G.Adj x p → ¬G.Adj x q) (z : V) (zb : z∈B) :
    (({p,q}:Finset V).filter (G.Adj z)).card≤1 := by
  apply card_le_one.mpr
  intro u hu v hv
  have up : u=p ∨ u=q := by simpa using (mem_filter.mp hu).1
  have vp : v=p ∨ v=q := by simpa using (mem_filter.mp hv).1
  rcases up with rfl|rfl <;> rcases vp with rfl|rfl
  · rfl
  · exact (free z zb (mem_filter.mp hu).2 (mem_filter.mp hv).2).elim
  · exact (free z zb (mem_filter.mp hv).2 (mem_filter.mp hu).2).elim
  · rfl

end Graph189TwoCutSideDegree
#print axioms Graph189TwoCutSideDegree.loss
#print axioms Graph189TwoCutSideDegree.one_anchor
