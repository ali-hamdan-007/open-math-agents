import Graph189ExteriorPopulation
import Graph189PrescribedBatch
import Graph189CutSides

open Finset SimpleGraph
open OMA.R_WrittenOnTheWallII_GraphConjecture189_conjecture189_R1
namespace Graph189TwoCutArmOre

variable {V : Type*} [Fintype V] [DecidableEq V] [Nontrivial V]
variable {G : SimpleGraph V} [DecidableRel G.Adj]

/-- A cut arm loses at most its anchor, the gate, and the unique low
vertex. The elementary degree bound yields actual prescribed-endpoint paths. -/
theorem high_core {D : Finset V} {anchor gate : V}
    (border : ∀ x∈D, ∀ y, G.Adj x y → y∉D → y=anchor ∨ y=gate)
    (small : (D.filter (fun x => G.secondSmallestDegree≤G.degree x)).card+1
      ≤ 2*(G.secondSmallestDegree-3)) :
    let C := D.filter (fun x => G.secondSmallestDegree≤G.degree x)
    ∀ u v : (C : Set V), u≠v → ∃ p : (G.induce (C : Set V)).Walk u v, p.IsHamiltonian := by
  classical
  intro C
  let Low := D.filter (fun x => G.degree x<G.secondSmallestDegree)
  have low : Low.card≤1 := by
    apply card_le_one.mpr
    intro x hx y hy
    by_contra ne
    rcases degree_pair (G:=G) x y ne with h|h
    · exact (not_lt_of_ge h) (mem_filter.mp hx).2
    · exact (not_lt_of_ge h) (mem_filter.mp hy).2
  have minimum (x : (C : Set V)) :
      G.secondSmallestDegree-3 ≤ (G.induce (C : Set V)).degree x := by
    let N := G.neighborFinset x.val
    have xD : x.val∈D := (mem_filter.mp x.property).1
    have high : G.secondSmallestDegree≤G.degree x.val := (mem_filter.mp x.property).2
    have sub : N⊆((N∩C)∪Low)∪{anchor,gate} := by
      intro y hy
      by_cases hd : y∈D
      · by_cases hh : G.secondSmallestDegree≤G.degree y
        · exact mem_union_left _ (mem_union_left _ (mem_inter.mpr ⟨hy,mem_filter.mpr ⟨hd,hh⟩⟩))
        · exact mem_union_left _ (mem_union_right _ (mem_filter.mpr ⟨hd,lt_of_not_ge hh⟩))
      · exact mem_union_right _ (by
          rcases border x.val xD y ((G.mem_neighborFinset _ _).mp hy) hd with rfl|rfl <;> simp)
    have card := card_le_card sub
    have union := card_union_le (N∩C) Low
    have total := card_union_le ((N∩C)∪Low) ({anchor,gate}:Finset V)
    have two : ({anchor,gate}:Finset V).card≤2 := by
      by_cases eq : anchor=gate <;> simp [eq]
    have val : (G.induce (C : Set V)).degree x=(N∩C).card := by
      rw [Graph189ExteriorDegreeCycle.degree_induce_filter]
      congr 1
      ext y
      simp [N]
    change G.secondSmallestDegree≤N.card at high
    rw [val]
    omega
  intro u v ne
  apply Graph189TerminalLeafClosure.prescribed_of_supergraph (G:=G.induce (C : Set V)) le_top _
    (Graph189TerminalLeafClosure.complete_prescribed u v ne)
  intro x y _ _
  have d₁ := minimum x
  have d₂ := minimum y
  rw [Fintype.card_coe]
  change C.card+1≤2*(G.secondSmallestDegree-3) at small
  omega


/-- Apply the high-core Ore route directly to a genuine recut arm. -/
theorem high_core_of_cut {D E : Finset V} {anchor gate : V}
    (cut : Graph189CutSides.CutSides G D E {anchor,gate})
    (small : D.card+1≤2*(G.secondSmallestDegree-3)) :
    let C := D.filter (fun x => G.secondSmallestDegree≤G.degree x)
    ∀ u v : (C : Set V), u≠v → ∃ p : (G.induce (C : Set V)).Walk u v, p.IsHamiltonian := by
  classical
  apply high_core (anchor:=anchor) (gate:=gate)
  · intro x xd y edge outside
    rcases cut.cover y with inside|other|separator
    · exact (outside inside).elim
    · exact (cut.no_cross x xd y other edge).elim
    · simpa using separator
  · exact (Nat.add_le_add_right (card_filter_le _ _) 1).trans small

end Graph189TwoCutArmOre
#print axioms Graph189TwoCutArmOre.high_core
#print axioms Graph189TwoCutArmOre.high_core_of_cut
