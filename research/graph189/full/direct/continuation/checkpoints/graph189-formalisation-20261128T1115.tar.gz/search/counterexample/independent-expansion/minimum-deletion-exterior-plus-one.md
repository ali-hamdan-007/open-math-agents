# One more vertex on a minimum-deletion exterior cycle

Paper argument for the exact large parent child. Its pointwise equality and saturation are staged in [Graph189DeletionExteriorEquality.lean](Graph189DeletionExteriorEquality.lean). That source has not undergone a pinned Lean replay.

Let \(G\) be a putative Graph 189 counterexample. Choose a minimum-degree vertex \(w\) and take a longest path \(P\) in the nontraceable deletion \(H=G-w\). Let \(E=H-V(P)\). All vertices of \(H\) have ambient degree at least \(k\). Use the established statements that \(E\) has an edge and every path in \(G\) misses at least \(h+2\) vertices, where \(h=\lceil k/2\rceil\).

## Comparison with the existing frontier

Graph189MinimumOrderViaCycles and its completion transfer produce order at least \(h\) from the uniformly rounded deletion degree. The critical-order theorem treats an arbitrary removable vertex, with a weaker uniform ambient minimum-degree hypothesis. Neither distinguishes which endpoint loses an edge to \(w\), nor the structure at equality. Graph189CrossOrder.cut_product counts populations across a separator and supplies no equality on a specific exterior edge. The near-Hamilton-connected exterior-size note assumes a near Hamilton-connected exterior and a minimum contact cover. The argument below works before either hypothesis. The closest pointwise precedent is Graph189OddExteriorClique.adjacent_of_odd_equality, which applies to a protected path in the original graph and has a two-slot debit. The arbitrary-completion, linked-exterior and high-connectivity notes supply the ordinary exterior-edge count, isolated-vertex count, and shift-run observation used here.

## Exact first-neighborhood debit

For \(x\) in \(E\), let \(q_x=d_E(x)\), \(a_x=|N_H(x)\cap V(P)|\), and \(\eta_x=1\) if \(x\) is adjacent to \(w\) in \(G\), zero otherwise. The edge inequality for adjacent \(x,y\in E\) is
\[
a_x+d_H(y)\ \le\ k+1+|N_E(x)\cap N_E(y)|\ \le\ k+q_x.
\]
The first form is Graph189ExteriorGap.exterior_contact_degree, applied in \(H\) with the induced-distance quota. Every induced distance-two pair remains at distance two in \(G\). The second form also follows from cross_contact_degree.

As \(d_H(x)=d_G(x)-\eta_x\), this yields \(2q_x\ge k-\eta_x-\eta_y\). In particular \(q_x\ge h-1\) at every nonisolated exterior vertex. An entire nontrivial exterior component disjoint from \(N_G(w)\) has minimum degree at least \(h\) in either parity, giving a cycle of order \(h+1\) by the elementary degree-cycle lemma.

For even \(k=2h\), suppose \(q_x=h-1\) and \(xy\) is an exterior edge. Both inequalities are then tight:
\[
\eta_x=\eta_y=1,\quad d_G(x)=d_G(y)=2h,\quad
N_E(x)\cap N_E(y)=N_E(x)\setminus\{y\}.
\]
This holds for all exterior neighbors of \(x\). In particular its closed exterior neighborhood \(B\) is an \(h\)-clique inside \(N_G(w)\), with degree exactly \(k\) at all its members. The induced distance-two quota at \(x\) also attains \(k\). Using its actual size in the first edge inequality forces that size to be at least \(k\). The transfer to \(G\) therefore saturates the ambient positive-even quota as well. The staged source directly deduces a cycle of order \(h+1\) when \(d_G(w)<h\), since there cannot then be such a clique.

## The sharp even row has all its witnesses on the path

Write \(X,Y\) for the contact-index sets of \(x,y\). Every contact is internal, no two members of \(X\) are consecutive, and distinct opposite marks \(i\in X,j\in Y\) are at least three steps apart. These are the hypotheses in Graph189ExteriorGap.cross_position_witnesses. Its witness indices are
\[
X^- \cup (X\cap Y)^+ \cup (Y\setminus X),
\]
of cardinality \(a_x+a_y\). In addition every exterior neighbor of \(y\) outside \(B\) is a distinct off-path witness. There are exactly \(q_y-q_x\) of these by the equality above. Hence these two kinds of witnesses already have total cardinality
\[
a_x+a_y+(q_y-q_x)=h+(2h-1-q_y)+(q_y-h+1)=k.
\]

Suppose a step-two pair occurs in \(X\). Choose the largest \(j\) in \(X\) with \(j-2\in X\). Then \(j+2\notin X\). The successor \(j+1\) is at distance two from \(x\) and lies outside the displayed index set. Indeed it is not the predecessor of an \(X\)-mark by \(j+2\notin X\). It is not the successor of a shared mark since \(j\notin Y\), by separation from \(j-2\). Also \(j+1\notin Y\), by separation from \(j\). This would be an extra witness, impossible.

The predecessor and successor sets of all \(h\) contacts of \(x\) are thus disjoint and already exhaust the \(2h\) even witnesses on \(P\). No neighbor \(y\) of \(x\) can have an exterior neighbor outside \(B\). Consequently \(B\) is an entire exterior component. Its members have \(q_y=h-1\), hence \(h\) contacts each. Those contacts must all match \(X\), since any missed contact of \(y\) is at distance two from \(x\) and lies outside both shifted sets by opposite spacing. In particular, no vertex outside \(P\cup B\) in \(H\) can be adjacent to \(w\). It would be another genuine ambient distance-two witness from \(x\).

## Unconditional even conclusion

Suppose \(k=2h\ge6\) and \(E\) has no cycle of order at least \(h+1\). Every nontrivial component of \(E\) then has a vertex of exterior degree \(h-1\), since a component of minimum degree \(h\) gives a cycle of order \(h+1\). By the sharp-row argument it is an \(h\)-clique contained in \(N_G(w)\). There is at least one nontrivial component, and there cannot be a second because the first component's sharp row forbids any further exterior neighbor of \(w\). If an isolated exterior vertex \(z\) exists, its at least \(k-1\) contacts in \(H\) have predecessor and successor sets with union of cardinality at least \(k\). This leaves exactly \(k-1\) contacts, so \(z\) lost an edge to \(w\). It is again forbidden by the sharp row. Therefore \(H\) has precisely \(h\) exterior vertices and the path \(P\) in \(G\) misses only \(h+1\), a contradiction.

A longest cycle of the completion that makes \(w\) universal contains \(w\). Opening it gives a longest path \(P\) in \(H\), and the exterior cycle above transfers to the completion unchanged. The same proof works in the large child at every even \(k\ge6\).

## Lean dependencies

- Use Graph189MinimumDeletionExterior.minimum_deletion_exterior_edge to obtain the first exterior edge and Graph189ExteriorDegreeCycle.induced_second_layer for its original even-distance budget.
- Use Graph189ExteriorGap.exterior_contact_degree with Graph189ExteriorDegreeCycle.degree_induce_filter and the exact lost-neighbor indicator. The current compact source stages the equality and saturation.
- For strictness, use Graph189ExteriorGap.cross_position_witnesses and adjacent_omitted_contact_spacing, plus the single extra successor index above. The full equality count needs the union of this strengthened path shell with the vertices off \(P\) that are adjacent to \(y\) but not to \(x\).
- Use Graph189ExteriorDegreeCycle.cycle_of_nonisolated_degree for the elementary cycle criterion and existing isolated-exterior shifted-contact witnesses for the neighbor of \(w\).
- Use the established longest-path omission gap in the original graph and Graph189UniversalCycle.longest_in_deletion for the completion wrapper. No Fan theorem, block decomposition, or order upper bound enters this even case.
