import Graph189MinimumDeletionExterior

namespace Graph189DeletionExteriorShift
open SimpleGraph Finset Graph189ExteriorGap

private theorem last_step_two (A : Finset ℕ) (pair : ∃ i ∈ A, i+2 ∈ A) :
    ∃ j, 2 ≤ j ∧ j ∈ A ∧ j-2 ∈ A ∧ j+2 ∉ A := by
  classical
  let L := A.filter (fun j => 2 ≤ j ∧ j-2 ∈ A)
  obtain ⟨i,hi,hj⟩ := pair
  have available : L.Nonempty := ⟨i+2,mem_filter.mpr ⟨hj,by omega,by simpa using hi⟩⟩
  let j := L.max' available
  have hit : j ∈ L := L.max'_mem available
  obtain ⟨hj,two,prev⟩ := mem_filter.mp hit
  refine ⟨j,two,hj,prev,?_⟩
  intro next
  have inL : j+2 ∈ L := mem_filter.mpr ⟨next,by omega,by simpa using hj⟩
  have hmax : j+2 ≤ j := L.le_max' _ inL
  omega

private theorem extra_index (A B : Finset ℕ)
    (sep : ∀ i ∈ A, ∀ j ∈ B, i=j ∨ i+3 ≤ j ∨ j+3 ≤ i)
    {j : ℕ} (two : 2 ≤ j) (mark : j ∈ A) (prev : j-2 ∈ A) (next : j+2 ∉ A) :
    j+1 ∉ crossIndices A B := by
  have jNotB : j ∉ B := by
    intro jB
    rcases sep (j-2) prev j jB with e | e | e <;> omega
  have succNotB : j+1 ∉ B := by
    intro jB
    rcases sep j mark (j+1) jB with e | e | e <;> omega
  intro mem
  rw [crossIndices] at mem
  rcases mem_union.mp mem with mem | mem
  · rcases mem_union.mp mem with pred | succ
    · obtain ⟨i,hi,eq⟩ := mem_image.mp pred
      exact next (by have e : i=j+2 := by omega; rwa [←e])
    · obtain ⟨i,hi,eq⟩ := mem_image.mp succ
      have e : i=j := by omega
      exact jNotB (e ▸ (mem_inter.mp hi).2)
  · exact succNotB (mem_sdiff.mp mem).1

variable {V : Type*} [DecidableEq V] {G : SimpleGraph V} {x y : V}

/-- A step-two pair among the first vertex's contacts adds a genuine
distance-two witness to the existing cross-index construction. -/
theorem strict_path_shell (p : G.Walk x y) (hp : p.IsPath)
    (maximal : ∀ {a b}, ∀ q : G.Walk a b, q.IsPath → q.length ≤ p.length)
    {a b : V} (ha : a ∉ p.support) (hb : b ∉ p.support) (ab : G.Adj a b)
    (pair : ∃ i ∈ contactPositions p a, i+2 ∈ contactPositions p a) :
    (contactPositions p a).card + (contactPositions p b).card + 1 ≤
      (p.support.toFinset.filter (fun v => G.dist a v=2)).card := by
  classical
  let A := contactPositions p a
  let B := contactPositions p b
  obtain ⟨j,two,hit,prev,next⟩ := last_step_two A pair
  obtain ⟨range,hj⟩ := (mem_contactPositions p a j).mp hit
  obtain ⟨_,internal⟩ := omitted_contact_internal p hp maximal ha ⟨j,range⟩
    (by simpa [get_at] using hj)
  have sep (i : ℕ) (hi : i ∈ A) (l : ℕ) (hl : l ∈ B) :
      i=l ∨ i+3 ≤ l ∨ l+3 ≤ i := by
    obtain ⟨ir,ia⟩ := (mem_contactPositions p a i).mp hi
    obtain ⟨lr,lb⟩ := (mem_contactPositions p b l).mp hl
    rcases lt_trichotomy i l with lt | eq | gt
    · exact Or.inr (Or.inl (adjacent_omitted_contact_spacing p hp maximal ha hb ab
        ⟨i,ir⟩ ⟨l,lr⟩ lt (by simpa [get_at] using ia) (by simpa [get_at] using lb)))
    · exact Or.inl eq
    · exact Or.inr (Or.inr (adjacent_omitted_contact_spacing p hp maximal hb ha ab.symm
        ⟨l,lr⟩ ⟨i,ir⟩ gt (by simpa [get_at] using lb) (by simpa [get_at] using ia)))
  have extra : j+1 ∉ crossIndices A B := extra_index A B sep two hit prev next
  have notAdj : ¬ G.Adj a (p.getVert (j+1)) := by
    intro adj
    have far := omitted_contact_spacing p hp maximal ha ⟨j,range⟩ ⟨j+1,internal⟩
      (show j < j+1 by omega) (by simpa [get_at] using hj)
      (by simpa [get_at] using adj.symm)
    omega
  have metric : G.dist a (p.getVert (j+1)) = 2 := by
    have distinct : a ≠ p.getVert (j+1) := fun eq => ha (eq ▸ p.getVert_mem_support _)
    have edge := p.adj_getVert_succ (i:=j) (by have := p.length_support; omega)
    exact two_step_metric distinct notAdj hj.symm edge.symm
  obtain ⟨size,shell⟩ := cross_position_witnesses p hp maximal ha hb ab
  let I := insert (j+1) (crossIndices A B)
  have labeled (i : ℕ) (hi : i ∈ I) : i < p.support.length ∧ G.dist a (p.getVert i)=2 := by
    rcases mem_insert.mp hi with rfl | hi
    · exact ⟨internal,metric⟩
    · exact shell i hi
  have inj : Set.InjOn p.getVert (I : Set ℕ) := by
    intro i hi l hl eq
    apply hp.getVert_injOn _ _ eq
    · change i ≤ p.length
      have := (labeled i hi).1
      have := p.length_support
      omega
    · change l ≤ p.length
      have := (labeled l hl).1
      have := p.length_support
      omega
  have sub : I.image p.getVert ⊆ p.support.toFinset.filter (fun v => G.dist a v=2) := by
    intro z hz
    obtain ⟨i,hi,rfl⟩ := mem_image.mp hz
    exact mem_filter.mpr ⟨List.mem_toFinset.mpr (p.getVert_mem_support i),(labeled i hi).2⟩
  have count := card_le_card sub
  rwa [card_image_of_injOn inj,show I.card = _ from card_insert_of_notMem extra,size] at count

variable [Fintype V] [DecidableRel G.Adj]

/-- The extra path witness is disjoint from the off-path debit, so a
step-two pair strengthens the full exterior-contact inequality by one. -/
theorem strict_exterior_contact_degree (p : G.Walk x y) (hp : p.IsPath)
    (maximal : ∀ {a b}, ∀ q : G.Walk a b, q.IsPath → q.length ≤ p.length)
    {a b : V} (ha : a ∉ p.support) (hb : b ∉ p.support) (ab : G.Adj a b)
    (pair : ∃ i ∈ contactPositions p a, i+2 ∈ contactPositions p a)
    {k : ℕ} (quota : (univ.filter (fun z => G.dist a z=2)).card ≤ k) :
    (G.neighborFinset a ∩ p.support.toFinset).card + G.degree b + 1 ≤
      k+1+((G.neighborFinset b \ p.support.toFinset) ∩ G.neighborFinset a).card := by
  classical
  let P := p.support.toFinset
  let A := G.neighborFinset a
  let B := G.neighborFinset b
  let D := B \ P
  let R := (D.erase a) \ A
  let C := D ∩ A
  let Q := P.filter (fun v => G.dist a v=2)
  have shell := strict_path_shell p hp maximal ha hb ab pair
  rw [contact_card_neighbors p hp a,contact_card_neighbors p hp b] at shell
  change (A∩P).card+(B∩P).card+1 ≤ Q.card at shell
  have aD : a ∈ D := mem_sdiff.mpr ⟨(G.mem_neighborFinset _ _).mpr ab.symm,
    fun h => ha (List.mem_toFinset.mp h)⟩
  have eq : (D.erase a) ∩ A = C := by
    ext z
    simp only [C,mem_inter,mem_erase]
    constructor
    · rintro ⟨⟨_,hd⟩,hn⟩
      exact ⟨hd,hn⟩
    · rintro ⟨hd,hn⟩
      exact ⟨⟨((G.mem_neighborFinset _ _).mp hn).ne.symm,hd⟩,hn⟩
  have dSize := card_sdiff_add_card_inter B P
  have eraseSize := card_erase_add_one aD
  have commonSize := card_sdiff_add_card_inter (D.erase a) A
  rw [eq] at commonSize
  change R.card+C.card=(D.erase a).card at commonSize
  have dis : Disjoint Q R := by
    apply Finset.disjoint_left.mpr
    intro z hq hr
    exact (mem_sdiff.mp (mem_erase.mp (mem_sdiff.mp hr).1).2).2 (mem_filter.mp hq).1
  have sub : Q ∪ R ⊆ univ.filter (fun v => G.dist a v=2) := by
    intro z hz
    apply mem_filter.mpr
    refine ⟨mem_univ _,?_⟩
    rcases mem_union.mp hz with hq | hr
    · exact (mem_filter.mp hq).2
    · obtain ⟨hD,hA⟩ := mem_sdiff.mp hr
      obtain ⟨ne,nb⟩ := mem_erase.mp hD
      have zb := (G.mem_neighborFinset _ _).mp (mem_sdiff.mp nb).1
      exact two_step_metric ne.symm (fun az => hA ((G.mem_neighborFinset _ _).mpr az))
        ab zb.symm
  have bound := (card_le_card sub).trans quota
  rw [card_union_of_disjoint dis] at bound
  change D.card+(B∩P).card=B.card at dSize
  change (A∩P).card+B.card+1 ≤ k+1+C.card
  omega

#print axioms strict_path_shell
#print axioms strict_exterior_contact_degree

end Graph189DeletionExteriorShift
