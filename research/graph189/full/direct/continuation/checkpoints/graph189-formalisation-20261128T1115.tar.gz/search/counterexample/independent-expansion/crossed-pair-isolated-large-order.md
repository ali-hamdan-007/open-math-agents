# A crossed pair and an isolated exterior cycle at \(k\ge157\)

Under the hypotheses of the [short isolated-cycle argument](crossed-pair-isolated-cycle.md), remove the restriction \(|C|\le5\) and assume \(h=\lceil k/2\rceil\ge79\). A path still misses at most \(h+1\) vertices and the gap theorem applies. This is a paper backup for the moderate-order range, with an arithmetic replay.

Write \(k=2h-\epsilon\), \(\epsilon\in\{0,1\}\), and keep \(M,p,r\) from the short proof. In particular \(M+r\le k+1\), every endpoint of \(P\) has no exterior contact, there is a spanning crossed-pair path with high endpoints, and every high vertex of \(C\) has at least \(k-r+1\) contacts in \(P\).

## The isolated cycle has order at most \(h\)

For \(6\le r\le h\), put \(L=h+2-r\ge2\). The strengthened mark-span argument of the short proof still applies: its overlap cases use \(|X|,|Y|\ge r+1\ge7\), and these counts make \(L\ge2\) sufficient. Thus
\[
n\ge2k+3h+8-2r-c+\tau,\qquad
c=\lfloor |A|/2\rfloor+\lfloor |B|/2\rfloor\le h-\lfloor(r+\epsilon)/2\rfloor.
\]
Here \(\tau\) is the sum of the two outer-tail excesses over \(L\). The shorter tail has length \(L+e\), with
\[
0\le e\le\left\lfloor
  (2r-\epsilon-6-\lfloor(r+\epsilon)/2\rfloor)/2
\right\rfloor.
\]
Attach the whole crossed-pair path at the corresponding extreme mark. Its original-path remainder is one interval of order \(N\) with one reserved unmarked endpoint, and \(M\ge2c\ge2h+2\epsilon+12-4r+4e\). Therefore
\[
N=p-(L+e)\le3h-5\epsilon+4r-12-5e.
\]
There are \(h+2+e\) omitted vertices. Each high vertex of \(C\) has at least \(a=h-\epsilon-1-e\) contacts in the interval.

Choose \(H=\min(r-1,\lfloor(r+3-e)/2\rfloor)\) consecutive high vertices on \(C\). The longer arc between any two chosen roots has at least \(r-H+2\) vertices. Two distinct roots with contacts at index difference at most \(D=r-H+2-e\) therefore allow a splice gaining at least \(e+1\) vertices. If no such pair exists, separate singleton runs at distinct roots and make multiple marks their own groups. With \(g\ge1\) groups, \(q\) occupied positions and total weight \(W\), one has
\[
N\ge q+D(g-1)+1,\qquad
Ha\le W\le q+(H-1)g.
\]
The final \(+1\) reserves the original endpoint of \(P\). Since \(D\ge H-1\), we conclude \(H(a-1)\le N-2\).

The [replay](crossed-pair-isolated-large-order.py) checks the strict reverse inequality at \(h=\max(79,r)\) for every \(6\le r\le204\) and admissible \(\epsilon,e\). The difference increases with \(h\) since \(H\ge4\). For \(r\ge205\), the bound \(e\le(3r-11)/4\) gives \(H\ge r/8+19/8\ge28\) and \(a-1\ge(h-1)/4\). Thus \(H(a-1)\ge7h-7>7h-14\ge N-2\). This completes the case \(r\le h\), using the short proof for \(r=3,4,5\).

## The isolated cycle is the larger part

Suppose \(r>h\), so \(M\le h\). Put \(u=k+1-M-r\ge0\). Then \(p\le2k+1+u\), \(u\le h-M\), and each high \(C\)-vertex has at least \(a=M+u\) original-path contacts.

Choose \(H\) consecutive high vertices on \(C\) and put \(D=h+4-M-H\). A distinct-root contact pair at difference at most \(D\) permits a longer-arc splice. This misses at most \(M+(H-2)+(D-1)=h+1\) vertices even if all of \(A,B\) are left out.

If \(M\le9\), take \(H=8\). With no such pair there are at most
\[
g\le 1+\left\lfloor(p-3)/(D+1)\right\rfloor
\]
groups of marks, since both path endpoints are unmarked. Set \(S=\min(8,a)\). If \(S=6\), then \(M=6,u=0\) and \(p-3\le4h-2<5(h-9)=(S-1)(D+1)\). Otherwise \(S\ge7\), and \(p-3\le5h-8<6(h-12)\le(S-1)(D+1)\). Thus \(g<S\), and some root has no singleton group, allowing it at most \(g<a\) contacts. This is impossible.

If \(10\le M\le h-6\), take \(H=\lfloor(h+5-M)/2\rfloor\). Then \(D\ge H-1\). In the absence of the pair, the weight bound as above with two reserved endpoints gives \(H(M+u)\le p+H-3\le 2k+H-2+u\). But \(H(M-1)>4h-2\ge2k-2\): the concave lower bound \((h+4-M)(M-1)/2\) has values \(9(h-6)/2\) and \(5(h-7)\) at the two extremes. This again gives a contradiction.

Finally suppose \(M\ge h-5\). Then \(r\le h+6\), \(M\le h\), and \(p\le4h+6\). Process each exterior cycle of order at least nine, skipping smaller cycles. For every processed cycle choose eight consecutive high vertices. Splice its longer arc using contacts on the same retained \(P\)-interval at index difference at most eight. Earlier splices leave at most three retained intervals and drop at most fourteen original path vertices before any new splice. Every chosen high root therefore has at least \(a=h-20\) contacts among those intervals: the exterior neighbors of \(A,B\) lie in \(A\cup B\), and those of \(C\) lie in \(C\).

For a proposed splice, if no close distinct-root pair exists, let \(J\le3\) be the number of retained intervals and \(g\) the total number of mark groups. The order \(N\) of the intervals is at most \(4h+6\) and \(g\le3+(4h+3)/9<a\). Each root must own a singleton group, so \(g\ge8\) and there are at most \(g-8\) multiple groups. There are at least \(8(a-g+8)+(g-8)\) occupied positions, with at least \(8(g-J)\) additional empty positions across the groups. Hence \(N\ge8a+40\ge8h-120>4h+6\), a contradiction. This proves every proposed splice can be made. It drops at most seven path positions and misses at most six vertices of the processed cycle. Each skipped cycle misses at most eight vertices. Over the three exterior cycles the path misses at most \(39\) vertices, below the gap threshold.
