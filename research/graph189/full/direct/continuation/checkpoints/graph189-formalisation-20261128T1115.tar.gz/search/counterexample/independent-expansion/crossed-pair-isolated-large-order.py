"""Check the finite parameter base of the large isolated-cycle proof."""


def replay():
    checked = 0
    for order in range(6, 205):
        half_degree = max(79, order)
        for parity in (0, 1):
            max_excess = (2 * order - parity - 6 - (order + parity) // 2) // 2
            for excess in range(max_excess + 1):
                roots = min(order - 1, (order + 3 - excess) // 2)
                contacts = half_degree - parity - 1 - excess
                length = 3 * half_degree - 5 * parity + 4 * order - 12 - 5 * excess
                assert roots >= 4
                assert roots * (contacts - 1) > length - 2, (order, parity, excess)
                checked += 1
    print(f"Checked the finite base for all {checked} isolated-cycle shapes")


if __name__ == "__main__":
    replay()
