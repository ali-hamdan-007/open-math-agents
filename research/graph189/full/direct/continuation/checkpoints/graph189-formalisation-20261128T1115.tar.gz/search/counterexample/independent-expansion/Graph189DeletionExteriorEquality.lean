import Graph189DeletionExteriorShift

namespace Graph189DeletionExteriorEquality
open SimpleGraph Finset Graph189ExteriorGap Graph189ExteriorDegreeCycle Graph189DeletionExteriorShift
open OMA.R_WrittenOnTheWallII_GraphConjecture189_conjecture189_R1

variable {V : Type*} [Fintype V] [DecidableEq V]
variable {G : SimpleGraph V} [DecidableRel G.Adj]

private theorem exact_deletion_degree (w : V) (x : {u : V | u ≠ w}) :
    G.degree x.val = (G.induce {u : V | u ≠ w}).degree x +
      if G.Adj x.val w then 1 else 0 := by
  rw [degree_induce_filter,←G.card_neighborFinset_eq_degree]
  have eq : (G.neighborFinset x.val).filter (fun v => v ∈ {u : V | u ≠ w}) =
      (G.neighborFinset x.val).erase w := by ext u; simp [and_comm]
  rw [eq]
  by_cases adj : G.Adj x.val w
  · simp only [if_pos adj]
    exact (card_erase_add_one ((G.mem_neighborFinset _ _).mpr adj)).symm
  · rw [erase_eq_of_notMem (fun hm => adj ((G.mem_neighborFinset _ _).mp hm)),if_neg adj]
    omega

section ChoosePath

variable (w : V)
local notation "U" => {u : V | u ≠ w}
local notation "H" => G.induce U

variable {x y : U} (p : H.Walk x y) (hp : p.IsPath)
variable (maximal : ∀ {i j}, ∀ r : H.Walk i j, r.IsPath → r.length ≤ p.length)

private abbrev outsideNeighbors (a : U) : Finset U := H.neighborFinset a \ p.support.toFinset

private theorem edge_budget {a b : U} (ha : a ∉ p.support) (hb : b ∉ p.support)
    (edge : H.Adj a b) {k : ℕ} (cap : G.distEven a.val ≤ k+1) :
    G.degree a.val + G.degree b.val ≤
      k + 2*(outsideNeighbors w p a).card
      + (if G.Adj a.val w then 1 else 0) + (if G.Adj b.val w then 1 else 0) := by
  classical
  have quota := induced_second_layer (G:=G) U a cap
  have contact := cross_contact_degree p hp maximal ha hb edge quota
  have split := card_sdiff_add_card_inter (H.neighborFinset a) p.support.toFinset
  rw [H.card_neighborFinset_eq_degree] at split
  change (outsideNeighbors w p a).card +
    (H.neighborFinset a ∩ p.support.toFinset).card = H.degree a at split
  change (H.neighborFinset a ∩ p.support.toFinset).card + H.degree b ≤
    k + (outsideNeighbors w p a).card at contact
  have da := exact_deletion_degree (G:=G) w a
  have db := exact_deletion_degree (G:=G) w b
  omega

private theorem edge_equality {a b : U} (ha : a ∉ p.support) (hb : b ∉ p.support)
    (edge : H.Adj a b) {h : ℕ} (cap : G.distEven a.val ≤ 2*h+1)
    (da : 2*h ≤ G.degree a.val) (db : 2*h ≤ G.degree b.val)
    (q : (outsideNeighbors w p a).card + 1 = h) :
    G.Adj a.val w ∧ G.Adj b.val w ∧ G.degree a.val = 2*h ∧ G.degree b.val = 2*h ∧
      (outsideNeighbors w p b ∩ outsideNeighbors w p a) = (outsideNeighbors w p a).erase b := by
  classical
  have budget := edge_budget w p hp maximal ha hb edge cap
  have aw : G.Adj a.val w := by
    by_contra ne
    by_cases bw : G.Adj b.val w <;> simp [ne,bw] at budget <;> omega
  have bw : G.Adj b.val w := by
    by_contra ne
    simp [aw,ne] at budget
    omega
  simp only [if_pos aw,if_pos bw] at budget
  have eqA : G.degree a.val = 2*h := by omega
  have eqB : G.degree b.val = 2*h := by omega
  refine ⟨aw,bw,eqA,eqB,?_⟩
  let S := outsideNeighbors w p a
  let T := outsideNeighbors w p b
  have quota := induced_second_layer (G:=G) U a cap
  have raw := exterior_contact_degree p hp maximal ha hb edge quota
  have commonEq : T ∩ H.neighborFinset a = T ∩ S := by
    ext z
    simp only [S,T,outsideNeighbors,mem_inter,mem_sdiff]
    tauto
  change (H.neighborFinset a ∩ p.support.toFinset).card + H.degree b ≤
    2*h+1+(T ∩ H.neighborFinset a).card at raw
  rw [commonEq] at raw
  have split := card_sdiff_add_card_inter (H.neighborFinset a) p.support.toFinset
  rw [H.card_neighborFinset_eq_degree] at split
  change S.card + (H.neighborFinset a ∩ p.support.toFinset).card = H.degree a at split
  change S.card+1=h at q
  have ad := exact_deletion_degree (G:=G) w a
  have bd := exact_deletion_degree (G:=G) w b
  simp only [eqA,eqB,if_pos aw,if_pos bw] at ad bd
  have bS : b ∈ S := mem_sdiff.mpr ⟨(H.mem_neighborFinset _ _).mpr edge,
    fun hm => hb (List.mem_toFinset.mp hm)⟩
  have sub : T ∩ S ⊆ S.erase b := by
    intro z hz
    have ⟨ht,hs⟩ := mem_inter.mp hz
    have adj := (H.mem_neighborFinset _ _).mp (mem_sdiff.mp ht).1
    exact mem_erase.mpr ⟨adj.ne.symm,hs⟩
  have count := card_erase_add_one bS
  exact eq_of_subset_of_card_le sub (by omega)

/-- The sharp even-degree row exhausts its ambient positive-even quota using
only actual distance-two vertices that survive the deletion. -/
theorem extremal_exterior_saturation {a b : U} (ha : a ∉ p.support) (hb : b ∉ p.support)
    (edge : H.Adj a b) {h : ℕ} (cap : G.distEven a.val ≤ 2*h+1)
    (da : 2*h ≤ G.degree a.val) (db : 2*h ≤ G.degree b.val)
    (q : (outsideNeighbors w p a).card + 1 = h) :
    (exactTwo H a).card = 2*h ∧ G.distEven a.val = 2*h+1 := by
  classical
  obtain ⟨wa,wb,eqA,eqB,common⟩ := edge_equality w p hp maximal ha hb edge cap da db q
  have budget := exterior_contact_degree p hp maximal ha hb edge
    (k:=(exactTwo H a).card) (by rfl)
  have commonEq : (outsideNeighbors w p b ∩ H.neighborFinset a) =
      (outsideNeighbors w p a).erase b := by
    rw [← common]
    ext z
    simp only [outsideNeighbors,mem_inter,mem_sdiff]
    tauto
  rw [commonEq] at budget
  have bM : b ∈ outsideNeighbors w p a :=
    mem_sdiff.mpr ⟨(H.mem_neighborFinset _ _).mpr edge,fun hb' => hb (List.mem_toFinset.mp hb')⟩
  have cM := card_erase_add_one bM
  have split := card_sdiff_add_card_inter (H.neighborFinset a) p.support.toFinset
  rw [H.card_neighborFinset_eq_degree] at split
  have ad := exact_deletion_degree (G:=G) w a
  have bd := exact_deletion_degree (G:=G) w b
  simp only [eqA,eqB,if_pos wa,if_pos wb] at ad bd
  have lower : 2*h ≤ (exactTwo H a).card := by
    change (outsideNeighbors w p a).card+(H.neighborFinset a ∩ p.support.toFinset).card = H.degree a at split
    omega
  have fit := induced_second_layer (G:=G) U a cap
  have nonzero : 1 ≤ G.distEven a.val := by
    change 1 ≤ (Finset.univ.filter (fun v => Even (G.dist a.val v))).card
    exact Nat.succ_le_of_lt (Finset.card_pos.mpr ⟨a.val,by simp⟩)
  have ambient := induced_second_layer (G:=G) U a (k:=G.distEven a.val-1) (by omega)
  exact ⟨by omega,by omega⟩

/-- In a sharp even row the contact positions have pairwise spacing at
least three. A two-step pair would spend an additional even-distance place. -/
theorem extremal_exterior_no_step_two {a b : U} (ha : a ∉ p.support) (hb : b ∉ p.support)
    (edge : H.Adj a b) {h : ℕ} (cap : G.distEven a.val ≤ 2*h+1)
    (da : 2*h ≤ G.degree a.val) (db : 2*h ≤ G.degree b.val)
    (q : (outsideNeighbors w p a).card + 1 = h) :
    ¬ ∃ i ∈ contactPositions p a, i+2 ∈ contactPositions p a := by
  classical
  intro pair
  obtain ⟨wa,wb,eqA,eqB,common⟩ := edge_equality w p hp maximal ha hb edge cap da db q
  have quota := induced_second_layer (G:=G) U a cap
  have budget := strict_exterior_contact_degree p hp maximal ha hb edge pair quota
  have commonEq : (outsideNeighbors w p b ∩ H.neighborFinset a) =
      (outsideNeighbors w p a).erase b := by
    rw [← common]
    ext z
    simp only [outsideNeighbors,mem_inter,mem_sdiff]
    tauto
  rw [commonEq] at budget
  have hit : b ∈ outsideNeighbors w p a :=
    mem_sdiff.mpr ⟨(H.mem_neighborFinset _ _).mpr edge,fun hb' => hb (List.mem_toFinset.mp hb')⟩
  have count := card_erase_add_one hit
  have split := card_sdiff_add_card_inter (H.neighborFinset a) p.support.toFinset
  rw [H.card_neighborFinset_eq_degree] at split
  change (outsideNeighbors w p a).card+(H.neighborFinset a ∩ p.support.toFinset).card = H.degree a at split
  have ad := exact_deletion_degree (G:=G) w a
  have bd := exact_deletion_degree (G:=G) w b
  simp only [eqA,eqB,if_pos wa,if_pos wb] at ad bd
  omega

/-- At even degree, a sharp exterior degree forces a clique of high vertices
already adjacent to the removed vertex in the original graph. -/
theorem extremal_exterior_clique {a b : U} (ha : a ∉ p.support) (hb : b ∉ p.support)
    (edge : H.Adj a b) {h : ℕ} (cap : G.distEven a.val ≤ 2*h+1)
    (high : ∀ v : U, 2*h ≤ G.degree v.val)
    (q : (outsideNeighbors w p a).card + 1 = h) :
    ∃ K : Finset V, K.card = h ∧ K ⊆ G.neighborFinset w ∧
      G.IsClique (K : Set V) ∧ ∀ v ∈ K, G.degree v = 2*h := by
  classical
  let S := outsideNeighbors w p a
  let f : U ↪ V := ⟨Subtype.val,Subtype.val_injective⟩
  let K := (insert a S).map f
  have center := edge_equality w p hp maximal ha hb edge cap (high a) (high b) q
  have noCenter : a ∉ S := by
    intro hm
    exact H.irrefl ((H.mem_neighborFinset _ _).mp (mem_sdiff.mp hm).1)
  have each {z : U} (hz : z ∈ S) :
      G.Adj a.val w ∧ G.Adj z.val w ∧ G.degree a.val = 2*h ∧ G.degree z.val = 2*h ∧
      (outsideNeighbors w p z ∩ S) = S.erase z := by
    obtain ⟨hn,off⟩ := mem_sdiff.mp hz
    exact edge_equality w p hp maximal ha (fun h => off (List.mem_toFinset.mpr h))
      ((H.mem_neighborFinset _ _).mp hn) cap (high a) (high z) q
  refine ⟨K,by simpa [K,card_insert_of_notMem noCenter] using q,?_,?_,?_⟩
  · intro z hz
    obtain ⟨i,hi,rfl⟩ := mem_map.mp hz
    apply (G.mem_neighborFinset _ _).mpr
    rcases mem_insert.mp hi with rfl | hs
    · exact center.1.symm
    · exact (each hs).2.1.symm
  · intro u hu v hv diff
    obtain ⟨u',hu,rfl⟩ := mem_map.mp hu
    obtain ⟨v',hv,rfl⟩ := mem_map.mp hv
    rcases mem_insert.mp hu with rfl | hu <;> rcases mem_insert.mp hv with rfl | hv
    · exact (diff rfl).elim
    · exact (H.mem_neighborFinset _ _).mp (mem_sdiff.mp hv).1
    · exact ((H.mem_neighborFinset _ _).mp (mem_sdiff.mp hu).1).symm
    · have diff' : v' ≠ u' := fun eq => diff (congrArg Subtype.val eq.symm)
      have mem : v' ∈ outsideNeighbors w p u' ∩ S := by
        rw [(each hu).2.2.2.2]
        exact mem_erase.mpr ⟨diff',hv⟩
      exact (H.mem_neighborFinset _ _).mp (mem_sdiff.mp (mem_inter.mp mem).1).1
  · intro v hv
    obtain ⟨z,hz,rfl⟩ := mem_map.mp hv
    rcases mem_insert.mp hz with rfl | hs
    · exact center.2.2.1
    · exact (each hs).2.2.2.1

/-- A component of the deletion exterior that avoids the removed vertex's
neighborhood has the improved cycle order in either parity. -/
theorem component_cycle_plus_one (S : Set U)
    (off : ∀ a ∈ S, a ∉ p.support)
    (closed : ∀ {a b : U}, a ∈ S → H.Adj a b → b ∉ p.support → b ∈ S)
    (notNeighbor : ∀ a ∈ S, ¬ G.Adj a.val w)
    (edge : ∃ a ∈ S, ∃ b ∈ S, H.Adj a b)
    {k : ℕ} (high : ∀ a ∈ S, k ≤ G.degree a.val)
    (two : 2 ≤ (k+1)/2) (cap : ∀ a ∈ S, G.distEven a.val ≤ k+1) :
    ∃ a, ∃ Q : (H.induce S).Walk a a, Q.IsCycle ∧ (k+1)/2+1 ≤ Q.length := by
  classical
  apply cycle_of_nonisolated_degree two
  · obtain ⟨a,ha,b,hb,adj⟩ := edge
    exact ⟨⟨a,ha⟩,⟨b,hb⟩,adj⟩
  · intro a b adj
    rw [degree_induce_filter]
    have same : (H.neighborFinset a.val).filter (fun v => v ∈ S) = outsideNeighbors w p a.val := by
      ext z
      simp only [outsideNeighbors,mem_filter,mem_sdiff]
      constructor
      · rintro ⟨hz,hs⟩
        exact ⟨hz,fun h => off z hs (List.mem_toFinset.mp h)⟩
      · rintro ⟨hz,hq⟩
        exact ⟨hz,closed a.property ((H.mem_neighborFinset _ _).mp hz)
          (fun h => hq (List.mem_toFinset.mpr h))⟩
    rw [same]
    have degree := edge_budget w p hp maximal (off a.val a.property) (off b.val b.property) adj
      (cap a.val a.property)
    simp only [if_neg (notNeighbor a.val a.property),if_neg (notNeighbor b.val b.property),
      Nat.add_zero] at degree
    have := high a.val a.property
    have := high b.val b.property
    omega

end ChoosePath

/-- In the even case a minimum degree less than half the second degree
improves the deletion-exterior cycle length by one. -/
theorem minimum_deletion_even_plus_one [Nontrivial V]
    (w : V) (minw : G.degree w = G.minDegree)
    {x y : {u : V | u ≠ w}} (p : (G.induce {u : V | u ≠ w}).Walk x y) (hp : p.IsPath)
    (maximal : ∀ {i j}, ∀ r : (G.induce {u : V | u ≠ w}).Walk i j,
      r.IsPath → r.length ≤ p.length)
    (notTrace : ¬ ∃ a b, ∃ q : G.Walk a b, q.IsHamiltonian)
    (notH : ¬ ∃ a b, ∃ q : (G.induce {u : V | u ≠ w}).Walk a b, q.IsHamiltonian)
    {h : ℕ} (two : 2 ≤ h) (even : G.secondSmallestDegree = 2*h) (small : G.degree w < h)
    (cap : ∀ v, G.distEven v ≤ G.secondSmallestDegree+1) :
    ∃ a, ∃ Q : ((G.induce {u : V | u ≠ w}).induce {v | v ∉ p.support.toFinset}).Walk a a,
      Q.IsCycle ∧ h+1 ≤ Q.length := by
  classical
  let U : Set V := {u | u ≠ w}
  let H := G.induce U
  let J : Set U := {v | v ∉ p.support.toFinset}
  have actualEdge := minimum_deletion_exterior_edge w minw p hp maximal notTrace notH (by omega) cap
  have high (v : U) : 2*h ≤ G.degree v.val := by
    rw [←even]
    rcases degree_pair (G:=G) v.val w v.property with e | e
    · exact e
    · rw [minw] at e
      exact e.trans (G.minDegree_le_degree v.val)
  apply cycle_of_nonisolated_degree two
  · obtain ⟨a,ha,b,hb,edge⟩ := actualEdge
    exact ⟨⟨a,fun hm => ha (List.mem_toFinset.mp hm)⟩,⟨b,fun hm => hb (List.mem_toFinset.mp hm)⟩,edge⟩
  · intro a b adj
    change h ≤ (H.induce J).degree a
    rw [degree_induce_filter]
    have same : (H.neighborFinset a.val).filter (fun v => v ∈ J) = outsideNeighbors w p a.val := by
      ext v
      simp [J,outsideNeighbors]
    rw [same]
    have ha : a.val ∉ p.support := fun hm => a.property (List.mem_toFinset.mpr hm)
    have hb : b.val ∉ p.support := fun hm => b.property (List.mem_toFinset.mpr hm)
    have quota : G.distEven a.val.val ≤ 2*h+1 := by simpa [even] using cap a.val.val
    have degree := edge_budget w p hp maximal ha hb adj quota
    have eA := high a.val
    have eB := high b.val
    by_contra! fail
    have qa : (outsideNeighbors w p a.val).card + 1 = h := by
      split_ifs at degree <;> omega
    obtain ⟨K,ks,sub,_,_⟩ := extremal_exterior_clique w p hp maximal ha hb adj quota high qa
    have fit := card_le_card sub
    rw [ks,G.card_neighborFinset_eq_degree] at fit
    omega

#print axioms extremal_exterior_clique
#print axioms extremal_exterior_saturation
#print axioms extremal_exterior_no_step_two
#print axioms component_cycle_plus_one
#print axioms minimum_deletion_even_plus_one

end Graph189DeletionExteriorEquality
