"""Replay only the unresolved profiles from the weaker four-cut model."""

import argparse
from pathlib import Path

from check_degree29_masks import run
from four_cut_masks import live


def unresolved(file):
    for line in file.read_text().splitlines():
        words = line.split()
        if len(words) == 5 and words[-1] in {"sat", "unknown"}:
            yield tuple(map(int, words[:4]))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("logs", type=Path, nargs="+")
    parser.add_argument("--port-degree", action="store_true")
    args = parser.parse_args()
    if not live():
        raise SystemExit("Graph 189 paused")
    still_open = []
    rows = sorted({row for file in args.logs for row in unresolved(file)})
    limits = ["--weak-edge-order", "--low-witness"]
    if args.port_degree:
        limits.append("--port-degree")
    for k in sorted({row[0] for row in rows}):
        control = run([k, k - 3, k - 3, "--positive-control", *limits])
        assert control == "sat"
        print(k, "positive", control, flush=True)
    for k, x, y, full in rows:
        result = run([k, x, y, "--full-a", full, "--timeout", 15000, *limits])
        print(k, x, y, full, result, flush=True)
        if result == "unsat":
            continue
        check = [k, x, y, "--full-a", full, "--timeout", 15000, *limits]
        uniform = run([*check, "--terminal", "uniform"])
        recut = run([*check, "--terminal", "recut"])
        print(k, x, y, full, "terminal", uniform, recut, flush=True)
        if uniform != "unsat" or recut != "unsat":
            still_open.append((k, x, y, full, uniform, recut))
    print("remaining", still_open, flush=True)


if __name__ == "__main__":
    main()
