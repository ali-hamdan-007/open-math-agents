# The low-anchor equality at degree 14

The low-on-minimum-four-cut exclusion also holds at $k=14$, once $n\ge5k-11=59$ is known. If every opposite pair of neighbors of the low vertex $z$ has four common anchors, use the same universal-port proof as in four-cut-low-degree-vertex.md. Otherwise fix an opposite pair $a,b$ with at most three common anchors.

The exact prescribed-pair low-cut debit has
$$n+k(k-\deg z)\le2k+(k+1)|N(a)\cap N(b)|.$$
It forces equality at $k=14$, with $n=59$, $\deg z=k-1$ and three common anchors. The proof of the debit in turn forces degrees $k$ at both endpoints and
$$W=N(z)\cup N(a)\cup N(b)=\{a,b\}\cup N(a)\cup N(b),\qquad |W|=2k-1,$$
as well as a full even quota at $z$. The wedge inequality is tight.

For a vertex $v$, write $E_v$ for its even ball, including $v$. In the wedge proof the set
$$D=E_z\setminus(N(a)\cup N(b))$$
has at most one vertex, since
$$|D|+|W|\le |E_z|+\deg z=2k.$$
Let $T$ consist of vertices that are at odd distance at least three from each of $a,b,z$. The wedge proof covers $T$ by rows based on $D$, each of capacity $k$. Equality throughout the wedge counting forces $|D|=1$, $|T|=k$, and $E_z\cap(E_a\cup E_b)=\varnothing$: the proof bounds the latter union of even balls by their summed sizes, apart from the two forced duplicate counts $a,b$ in $E_a\cap E_b$.

Every member of $T$ is high because $z$ is the only low vertex. Its distance from $a$ is therefore at most four, so its distance from $a$ is exactly three. The original edge $za$ then gives distance at most four from $z$, hence exactly three. Each member of $T$ has a geodesic predecessor in $D$ by the wedge proof. In particular the unique vertex $v$ of $D$ lies at distance two from $z$, and is adjacent to all of $T$.

Choose $u$ on a length-two path $z,u,v$. Since $v$ lies outside $N(a)\cup N(b)$, $u$ cannot equal either endpoint. If $u$ is adjacent to both endpoints, $v$ lies at distance exactly two from both, contradicting the disjointness of the even balls above. Otherwise one endpoint lies at distance exactly two from $u$ via $z$. Every member of $T$ is also at distance exactly two from $u$ via $v$, because it is in the third layer of $z$. Together these are $k+1$ positive even witnesses at $u$, impossible.

The same equality argument rejects the $n=55$ endpoint for $k=13$ with a low anchor, but not the one-place slack at $n=54$.
