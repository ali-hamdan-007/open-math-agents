# Connectivity four results

The graph-facing theorem Graph189FourCut.traceable in Graph189FourConnectivityJoint.lean proves the original Graph 189 conclusion at connectivity four and every second-smallest degree $k\ge37$. It checks in the pinned Lean environment using propext, Classical.choice and Quot.sound. Graph189DebitedCutProduct.with_columns is the separately checked exact rectangle bound used in the smaller-degree calculations.

The additional paper arguments start with four-cut-high-degree.md and the corresponding notes for degrees 31, 30, 29, 24–25 and 23 through 18. The lower-degree procedure keeps the order and all degree hypotheses on the original graph. It excludes a low separator vertex, obtains the order interval using the two minimum-deletion alternatives, classifies the large populations, and calculates exact integer relaxations for the finite remaining populations. The recut is valid once the two-common-label conclusion is uniform over all possible oriented minimum cuts.

The solver uses exact QF_LIA through libz3.so.4. While the matching Graph 189 lease is healthy, reproduce the finite filter and the corresponding checked rows with:

    python3 four_cut_strict_product.py
    python3 check_degree29_masks.py
    python3 check_degree26_28_masks.py --degrees 21 22 23 24 25 26 27 28
    python3 check_degree26_28_masks.py --degrees 20 > four-cut-degree20-masks.log
    python3 check_low_mask_witnesses.py four-cut-degree20-masks.log
    python3 check_degree26_28_masks.py --degrees 19 > four-cut-degree19-masks.log
    python3 check_low_mask_witnesses.py four-cut-degree19-masks.log

The positive controls use two cliques of order $k-3$ each with all four separator contacts. The split profiles distinguish the number of small-side anchor contact sets of size $k$, so every relabeling is included. For lower degrees, four-cut-terminal-masks.md explains the strengthened exact retry and how its two terminal UNSAT queries imply an original-graph contradiction via recut. The command for degree 18's retry includes the port-degree option.

The paper proofs and Z3 computations are research evidence. The whole connectivity-four theorem below the local Lean threshold still needs integration into the pinned kernel. The full parent conjecture and its official status are tracked by the coordinator.
