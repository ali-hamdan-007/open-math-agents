# A low-degree vertex cannot belong to a minimum four-cut

Let $k$ be the second-smallest degree in the original graph. Assume the original even-distance condition, a minimum vertex cut $S$ of size four partitioning the remaining vertices into anticomplete sides, $k\ge15$, and $n\ge5k-11$.

Suppose $z\in S$ has degree below $k$. The prescribed-opposite-neighbor form of the low-cut debit bounds $n+k(k-\deg z)$ by $2k+(k+1)|R|$, where $R$ is the common neighborhood of any chosen opposite neighbors of $z$. Since $R\subseteq S$, the order lower bound forces $|R|=4$. Each side has a neighbor of $z$ by minimality of $S$. Thus every neighbor of $z$ outside $S$ touches all four anchors.

A universal port on one side spends an even place on every port of the other side. There are at most $k$ ports on each side. If both sides contain nonports, a nonport on one side sees every nonport on the other at distance four. A compulsory second layer of at least four vertices inside its own side together with $S$ leaves at most $k-4$ nonports on the opposite side. This would give $n\le4k-4$. Hence one side, say $X$, consists entirely of ports.

Every vertex of $X$ has degree at least $k$ since $z$ is the unique low vertex, so $|X|\ge k-3$. Take a universal port $b$ in the other side $Y$. All of $X$ is at distance two from $b$, leaving at most three vertices of $Y$ at distance two from $b$. If the set of vertices in $Y$ at distance at least three from $b$ were nonempty, no vertex in it could have a neighbor in $X$ or $S$. By the triangle inequality every edge from this set to the rest of $Y$ must end at distance two from $b$. Deleting those at most three vertices would disconnect the graph. Thus this far set is empty.

Write $e$ for the number of vertices of $Y$ at distance two from $b$. Then $|X|+e\le k$ and $\deg b=4+|Y|-1-e=n-1-|X|-e\ge n-1-k$. The original degree ceiling $\Delta\le3k$ gives $n\le4k+1$, contradicting $n\ge5k-11$ and $k\ge15$.

`Graph189FourLowCeiling.lean` is a source draft of this shorter approach. Its final wrapper still needs a Lean compile.
