import Graph189MaximumDegree
import Graph189PositiveEvenCut
import Graph189PortDifference
import Graph189MinimumCutOrder
import Graph189Removable

open Finset SimpleGraph Graph189CutSides Graph189PositiveEvenCut
open OMA.R_WrittenOnTheWallII_GraphConjecture189_conjecture189_R1

namespace Graph189FourCut

variable {V : Type*} [Fintype V] [DecidableEq V] [Nontrivial V]
variable {G : SimpleGraph V} [DecidableRel G.Adj]
variable {A B S : Finset V}

/-- The low-cut debit at a prescribed pair of opposite neighbors of the
low separator vertex. The deficit argument uses their actual common set. -/
theorem low_pair_debit (sides : CutSides G A B S) (hc : G.Connected)
    (cap : ∀ v, G.distEven v≤1+G.secondSmallestDegree) {z a b : V}
    (hz : z∈S) (low : G.degree z<G.secondSmallestDegree)
    (ha : a∈A) (hb : b∈B) (az : G.Adj a z) (bz : G.Adj b z) :
    let R := G.neighborFinset a ∩ G.neighborFinset b
    R ⊆ S ∧
    Fintype.card V + G.secondSmallestDegree * (G.secondSmallestDegree - G.degree z) ≤
      2 * G.secondSmallestDegree + (G.secondSmallestDegree+1)*R.card := by
  classical
  let k := G.secondSmallestDegree
  intro R
  let U := G.neighborFinset a ∪ G.neighborFinset b
  let W := G.neighborFinset z ∪ U
  have ah : k ≤ G.degree a := (degree_pair (G := G) a z az.ne).resolve_right (not_le.mpr low)
  have bh : k ≤ G.degree b := (degree_pair (G := G) b z bz.ne).resolve_right (not_le.mpr low)
  have neq : a ≠ b := fun e => disjoint_left.mp sides.apart (e ▸ ha) hb
  have ne := sides.no_cross a ha b hb
  have cap' (v : V) : G.distEven v ≤ k+1 := by simpa only [k,Nat.add_comm 1] using cap v
  have rsub : R ⊆ S := by
    intro v hv
    obtain ⟨av,bv⟩ := mem_inter.mp hv
    rcases sides.cover v with h | h | hs
    · exact (sides.no_cross v h b hb ((G.mem_neighborFinset _ _).mp bv).symm).elim
    · exact (sides.no_cross a ha v h ((G.mem_neighborFinset _ _).mp av)).elim
    · exact hs
  refine ⟨rsub,?_⟩
  have aabs : a ∉ U := by
    intro h
    rcases mem_union.mp h with h|h
    · exact (G.loopless.irrefl a) ((G.mem_neighborFinset _ _).mp h)
    · exact ne ((G.mem_neighborFinset _ _).mp h).symm
  have babs : b ∉ U := by simp [U,G.mem_neighborFinset,ne]
  have anot : a ∉ insert b U := by simp [neq,aabs]
  have included : insert a (insert b U) ⊆ W := by
    intro v hv
    rcases mem_insert.mp hv with rfl | hv
    · exact mem_union_left _ ((G.mem_neighborFinset _ _).mpr az.symm)
    rcases mem_insert.mp hv with rfl | hv
    · exact mem_union_left _ ((G.mem_neighborFinset _ _).mpr bz.symm)
    · exact mem_union_right _ hv
  have size := card_le_card included
  rw [card_insert_of_notMem anot,card_insert_of_notMem babs] at size
  have ui := card_union_add_card_inter (G.neighborFinset a) (G.neighborFinset b)
  rw [G.card_neighborFinset_eq_degree,G.card_neighborFinset_eq_degree] at ui
  change U.card + R.card = G.degree a + G.degree b at ui
  have wad := Nat.mul_le_mul_left (k+1)
    (show G.degree a + G.degree b + 2 ≤ W.card + R.card by omega)
  have ew := Graph189WedgeOrder.wedge_order hc az.symm bz.symm ne cap'
  change Fintype.card V + (k+1)*W.card ≤
    3*k+2 + k*(G.degree z+G.distEven z) + G.degree a + G.degree b at ew
  have eps := Nat.mul_le_mul_left k (cap' z)
  have deg := Nat.mul_le_mul_left k (show 2*k ≤ G.degree a+G.degree b by omega)
  have dif := congrArg (fun t : ℕ => k*t) (show G.degree z+(k-G.degree z)=k by omega)
  change Fintype.card V + k*(k-G.degree z) ≤ 2*k+(k+1)*R.card
  nlinarith only [ew,wad,eps,deg,dif]

/-- Once the parameter-four order lower bound holds, every contact of the
low separator vertex is adjacent to every separator vertex. -/
theorem universal_low_contacts (sides : CutSides G A B S) (hc : G.Connected)
    (cap : ∀ v, G.distEven v≤1+G.secondSmallestDegree)
    (smaller : ∀ T : Finset V, T.card<S.card → (G.induce {v : V | v∉T}).Connected)
    (four : S.card=4) (upperDegree : 15≤G.secondSmallestDegree)
    (order : 5*G.secondSmallestDegree≤Fintype.card V+11) {z : V}
    (hz : z∈S) (low : G.degree z<G.secondSmallestDegree) :
    ∀ x∈A, G.Adj x z → ∀ i∈S, G.Adj x i := by
  classical
  intro a ha az i hi
  obtain ⟨b,hb,bz⟩ := (sides.contacts_of_minimum smaller hz).2
  obtain ⟨sub,debit⟩ := low_pair_debit sides hc cap hz low ha hb az bz
  let k := G.secondSmallestDegree
  let R := G.neighborFinset a ∩ G.neighborFinset b
  have d : 1≤k-G.degree z := by dsimp [k]; omega
  have d' := Nat.mul_le_mul_left k d
  have large : 4≤R.card := by
    by_contra! small
    have count : R.card≤3 := by omega
    have r3 := Nat.mul_le_mul_left (k+1) count
    change Fintype.card V+k*(k-G.degree z)≤2*k+(k+1)*R.card at debit
    omega
  have eq : R=S := eq_of_subset_of_card_le sub (by omega)
  have h : i∈R := eq.symm ▸ hi
  exact (G.mem_neighborFinset _ _).mp (mem_inter.mp h).1

private noncomputable def ports (S X : Finset V) : Finset V := by
  classical exact X.filter (fun x => ∃ i∈S, G.Adj x i)

private theorem port_count (hc : G.Connected) (sides : CutSides G A B S)
    (cap : ∀ x, G.distEven x≤1+G.secondSmallestDegree) {a : V}
    (ha : a∈A) (whole : ∀ i∈S, G.Adj a i) : (ports (G:=G) S B).card≤G.secondSmallestDegree := by
  classical
  have sub : ports (G:=G) S B ⊆ evenOthers G a := by
    intro y hy
    obtain ⟨yb,i,hi,edge⟩ := (mem_filter.mp hy)
    have d := Graph189PortDifference.cross_two hc sides ha yb (whole i hi) edge.symm
    exact mem_even_others (by rintro rfl; simp at d) (by rw [d]; decide)
  exact (card_le_card sub).trans (even_others_card (by simpa only [Nat.add_comm 1] using cap a))

/-- A minimum separator containing the low vertex has a side consisting
entirely of ports once the original graph has the baseline lower order. -/
theorem low_cut_shallow (hc : G.Connected) (sides : CutSides G A B S)
    (cap : ∀ v, G.distEven v≤1+G.secondSmallestDegree)
    (smaller : ∀ T : Finset V, T.card<S.card → (G.induce {v : V | v∉T}).Connected)
    (four : S.card=4) (hk : 15≤G.secondSmallestDegree)
    (base : 5*G.secondSmallestDegree≤Fintype.card V+11)
    {z : V} (hz : z∈S) (low : G.degree z<G.secondSmallestDegree) :
    ∃ X Y, CutSides G X Y S ∧ (∀ x∈X, ∃ i∈S, G.Adj x i) := by
  classical
  let k := G.secondSmallestDegree
  have k15 : 15≤k := hk
  have sk : S.card≤k := by omega
  have high (v : V) (ne : v≠z) : k≤G.degree v :=
    (degree_pair (G:=G) v z ne).resolve_right (not_le.mpr low)
  have onLeft {X Y : Finset V} (cut : CutSides G X Y S) :
      ∀ v∈X, k≤G.degree v := by
    intro v hv
    exact high v (fun eq => disjoint_left.mp cut.left_cut hv (eq.symm ▸ hz))
  have count {X Y : Finset V} (cut : CutSides G X Y S) :
      (ports (G:=G) S Y).card≤k := by
    obtain ⟨u,ux,uz⟩ := (cut.contacts_of_minimum smaller hz).1
    exact port_count hc cut cap ux (universal_low_contacts cut hc cap smaller four hk base hz low u ux uz)
  have portSub (X : Finset V) : ports (G:=G) S X ⊆ X := filter_subset _ _
  have deep {X : Finset V} {x : V} (hx : x∈X \ ports (G:=G) S X) :
      ∀ i∈S, ¬G.Adj x i := by
    intro i hi xi
    exact (mem_sdiff.mp hx).2 (mem_filter.mpr ⟨(mem_sdiff.mp hx).1,i,hi,xi⟩)
  have both {X Y : Finset V} (cut : CutSides G X Y S) {x : V}
      (outside : x∈X \ ports (G:=G) S X) :
      (Y \ ports (G:=G) S Y).card+S.card≤k := by
    have hx := (mem_sdiff.mp outside).1
    exact opposite_nonports hc cap cut smaller sk hx (onLeft cut x hx) (deep outside)
      (Y \ ports (G:=G) S Y) sdiff_subset (fun y hy => ⟨onLeft cut.swap y (mem_sdiff.mp hy).1,deep hy⟩)
  by_cases a : (A \ ports (G:=G) S A).Nonempty
  · by_cases b : (B \ ports (G:=G) S B).Nonempty
    · obtain ⟨u,hu⟩ := a
      obtain ⟨v,hv⟩ := b
      have ac := both sides.swap hv
      have bc := both sides hu
      have ap := count sides.swap
      have bp := count sides
      have asplit := card_sdiff_add_card_eq_card (portSub A)
      have bsplit := card_sdiff_add_card_eq_card (portSub B)
      have full := (sides.low_cut_product hc smaller cap hz low).1
      omega
    · refine ⟨B,A,sides.swap,?_⟩
      intro x hx
      have hx' : x∈ports (G:=G) S B := by
        by_contra miss
        exact b ⟨x,mem_sdiff.mpr ⟨hx,miss⟩⟩
      exact (mem_filter.mp hx').2
  · refine ⟨A,B,sides,?_⟩
    intro x hx
    have hx' : x∈ports (G:=G) S A := by
      by_contra miss
      exact a ⟨x,mem_sdiff.mpr ⟨hx,miss⟩⟩
    exact (mem_filter.mp hx').2

/-- A degree below the second-smallest degree cannot occur on a minimum
four-cut above the edge-order baseline. -/
theorem low_cut_impossible (hc : G.Connected) (sides : CutSides G A B S)
    (cap : ∀ v, G.distEven v≤1+G.secondSmallestDegree)
    (smaller : ∀ T : Finset V, T.card<S.card → (G.induce {v : V | v∉T}).Connected)
    (four : S.card=4) (hk : 15≤G.secondSmallestDegree)
    (base : 5*G.secondSmallestDegree≤Fintype.card V+11) {z : V}
    (hz : z∈S) (low : G.degree z<G.secondSmallestDegree) : False := by
  classical
  let k := G.secondSmallestDegree
  obtain ⟨X,Y,cut,shallow⟩ := low_cut_shallow hc sides cap smaller four hk base hz low
  obtain ⟨b,hb,bz⟩ := (cut.contacts_of_minimum smaller hz).2
  have full := universal_low_contacts cut.swap hc cap smaller four hk base hz low b hb bz
  obtain ⟨a,ha⟩ := cut.left_nonempty
  have az : a ≠ z := fun eq => disjoint_left.mp cut.left_cut (eq ▸ ha) hz
  have high : k ≤ G.degree a :=
    (degree_pair (G := G) a z az).resolve_right (not_le.mpr low)
  have degree := Graph189Removable.degree_in_side cut ha
  have xLower : k ≤ X.card+3 := by omega
  let E := Y.filter fun v => G.dist b v = 2
  have esub : E ⊆ Y := filter_subset _ _
  have apart : Disjoint X E := cut.apart.mono_right esub
  have eOut : b ∉ E := by simp [E]
  have crowd : X ∪ E ⊆ evenOthers G b := by
    intro v hv
    rcases mem_union.mp hv with hx|he
    · obtain ⟨i,hi,vi⟩ := shallow v hx
      have dist := Graph189PortDifference.cross_two hc cut.swap hb hx (full i hi) vi.symm
      have ne : v ≠ b := fun eq => disjoint_left.mp cut.apart (eq ▸ hx) hb
      apply mem_even_others ne
      rw [dist]
      decide
    · apply mem_even_others (fun eq => eOut (eq ▸ he))
      have dist := (mem_filter.mp he).2
      rw [dist]
      decide
  have budget := (card_le_card crowd).trans (even_others_card (by simpa [k,Nat.add_comm] using cap b))
  rw [card_union_of_disjoint apart] at budget
  have small : E.card < S.card := by omega
  have noFar (v : V) (hv : v∈Y) : G.dist b v≤2 := by
    by_contra! far
    let D : Set V := {w | w∉E}
    have vOut : v∉E := fun h => by
      have d := (mem_filter.mp h).2
      omega
    obtain ⟨walk⟩ := smaller E small (⟨v,vOut⟩ : D) (⟨b,eOut⟩ : D)
    obtain ⟨u,w,hu,hw,step,_⟩ := Graph189CutSides.walk_exits
      (G := G.induce D) (fun t : D => t.val∈Y ∧ 3≤G.dist b t.val) walk
      ⟨hv,by omega⟩ (by simp)
    have edge : G.Adj u.val w.val := step
    have dist := hc.dist_triangle (u:=b) (v:=w.val) (w:=u.val)
    rw [dist_eq_one_iff_adj.mpr edge.symm] at dist
    rcases cut.cover w.val with hX|hY|hS
    · exact (cut.no_cross _ hX _ hu.1 edge.symm).elim
    · have short : ¬ 3 ≤ G.dist b w.val := fun h => hw ⟨hY,h⟩
      have wTwo : G.dist b w.val = 2 := by omega
      exact w.property (mem_filter.mpr ⟨hY,wTwo⟩)
    · have d := dist_eq_one_iff_adj.mpr (full w.val hS)
      omega
  let close := Y \ insert b E
  have partition := card_sdiff_add_card_eq_card (insert_subset hb esub : insert b E ⊆ Y)
  rw [card_insert_of_notMem eOut] at partition
  have neighbors : close ∪ S ⊆ G.neighborFinset b := by
    intro w hw
    apply (G.mem_neighborFinset b w).mpr
    rcases mem_union.mp hw with h|hs
    · obtain ⟨wy,miss⟩ := mem_sdiff.mp h
      have ne : b≠w := fun eq => miss (by simp [eq])
      have nonzero : G.dist b w≠0 := fun eq => ne (hc.dist_eq_zero_iff.mp eq)
      have nontwo : G.dist b w≠2 := fun eq => miss (mem_insert_of_mem (mem_filter.mpr ⟨wy,eq⟩))
      have short := noFar w wy
      exact dist_eq_one_iff_adj.mp (by omega)
    · exact full w hs
  have degreeLower := card_le_card neighbors
  have dis : Disjoint close S := cut.right_cut.mono_left sdiff_subset
  rw [card_union_of_disjoint dis, G.card_neighborFinset_eq_degree] at degreeLower
  have ceiling := (G.degree_le_maxDegree b).trans
    (Graph189DegreeCeiling.maxDegree_le_three_mul_secondSmallestDegree hc cap)
  have total := (cut.low_cut_product hc smaller cap hz low).1
  change close.card+(E.card+1)=Y.card at partition
  change Fintype.card V=S.card+X.card+Y.card at total
  omega

#print axioms Graph189FourCut.low_cut_impossible

end Graph189FourCut
