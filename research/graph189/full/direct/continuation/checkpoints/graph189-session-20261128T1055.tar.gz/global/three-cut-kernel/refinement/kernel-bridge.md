# Three-cut formalization frontier

The earlier all-degree paper argument is in global/cut3/three-cut-all-degrees.md and uses exact-real SMT. The files below develop a separate route to the original Lean theorem. No checker verdict has been issued for these fork modules.

## Local kernel results

* Graph189ThreeConnectivity.traceable_ge37 proves a Hamiltonian path from the original cap for vertex connectivity three and second-smallest degree at least 37. Its audit is in original.log.
* Graph189LowConnectivityLift.minimum_deletion gives n≥5k−11 in the nontraceable minimum-deletion case for κ=3 and k≥20. It uses the independently written Graph189CompletionLinkedFour.critical_fixed. Both local audits are in lift.log and critical.log.
* Graph189AlmostFullColumn.opposite_population is valid for every minimum separator and arbitrary X⊆A, Y⊆B. If a label has at least k−t neighbors in X and 2t<s, then |Y|≤k+|Y_i|+t. Its audit is in near-column.log.
* The previous layer's Graph189CrossBoundaryProduct.high_product is a certified uniform upper bound xy+sx≤kx+sk(k+1). Graph189ThreeCutThresholds.quotas handles the first round of finite thresholds. All these local audits print precisely propext, Classical.choice, Quot.sound.

## General source awaiting compilation

Graph189ThreePrivateDensity.dense_private_quota is the next compilation target. It derives 2x+3y+12≤12k if each high A vertex has at most one label and |A|<2k. Each representative's same-side distance-two cost cancels the size of its closed high neighborhood against the corresponding anchor's remaining second layer. The isolated dense/ snapshot uses this to extend the top-level threshold to 33.

Graph189CutColumnCaps turns the almost-full-column theorem into a uniform column deficit on either side. Graph189StrictPopulation applies those caps to the four-cut worker's checked exact column-charge theorem. When x,y>2k+1 it gives xy+3x≤kx+3(k−2)(k+1). Graph189ThreeCutBalancedTable and Graph189ThreeCutBalancedFacts feed this inequality into the next snapshot. Its nine arithmetic windows were replayed in Python. The balanced/ snapshot joins those facts and the common-column bound x≤k−2 to the same recut proof, targeting 29. It retains the earlier theorem names. The snapshots preserve the k≥37 certified sources until the new assemblies pass.

Graph189ClosedSide records the generalized contact-level second-layer estimate underlying the degree-24 table. Graph189TwoResidual records the strict singleton-common residual inequality 2y+2≤6k+x. They support later stages and are independent of the k≥29 adapter.

## Paper checks beyond the compiled range

three-cut-saturation.md and three_cut_saturation.py give the degree-25 proof. three-cut-degree24.md and three_cut_columns.py handle the two remaining degree-24 populations. Both stages were independently reviewed. The current column test leaves (31,69) and (50,50) at k=23; an occupancy profile alone does not exhibit a graph.

The direct degree-25 source assembly is in `saturation/`. It imports
`Graph189ThreeCutSaturationFacts.lean` and `Graph189ThreeCutSaturationTable.lean`
and uses `Graph189ThreePrivateDensity` and the dense threshold version.
The latter table needs the finite rectangle only between the simultaneous order
and orientation floors and `y=3k+floor(x/2)`. Above it all the required
inequalities follow linearly. The level bounds and two asymmetric charges
suffice throughout degrees 25 through 36. At degree 24 those same tests
leave (22,83) and (33,72). These are the exact two stronger column/overlap
cases handled in the separately audited paper replay. The degree-25 Lean
assembly has not been compiled.

The independent verifier validated a direct paper exclusion of (33,72)
in `three-cut-33-72.md`. Its source implementation is partitioned into
`Graph189ThreeNearArithmetic.lean`, `Graph189ThreeNearSupports.lean`, and
`Graph189ThreeNearGraph.lean`. The `Graph189ThreeCutSaturation24.lean`
table leaves only (33,72) after applying the strict residual bound, and
then uses the near-column graph argument. The all-order original-graph
source is `saturation24/Graph189ThreeConnectivity.lean`. Its joint imports
`Graph189TwoResidual.lean` to close the strict common-label branch. None
of these degree-24 modules has been compiled yet. The prior cutoff
`traceable_ge37` and generic `opposite_population` remain the current
verified Lean results.
