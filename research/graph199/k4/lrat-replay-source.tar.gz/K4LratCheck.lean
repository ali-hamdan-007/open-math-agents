import Std.Sat.CNF
import Std.Tactic.BVDecide.LRAT

open Std.Sat
open Std.Tactic.BVDecide

def parseDimacs (input : String) : Except String (CNF Nat) := do
  let mut header : Option (Nat × Nat) := none
  let mut clauses : Array (CNF.Clause Nat) := #[]
  for line in input.splitOn "\n" do
    let tokens := (line.splitOn " ").filter (· ≠ "")
    match tokens with
    | [] | "c" :: _ => pure ()
    | ["p", "cnf", vars, count] =>
      if header.isSome then throw "multiple headers"
      let some vars := vars.toNat? | throw "invalid variable count"
      let some count := count.toNat? | throw "invalid clause count"
      header := some (vars, count)
    | _ =>
      let some (vars, _) := header | throw "missing header"
      let "0" :: body := tokens.reverse | throw "unterminated clause"
      let mut clause := []
      for text in body do
        let some lit := text.toInt? | throw "invalid literal"
        let idx := lit.natAbs
        if idx = 0 || idx > vars then throw "out-of-range literal"
        clause := (idx - 1, decide (lit > 0)) :: clause
      clauses := clauses.push clause
  let some (_, count) := header | throw "missing header"
  if clauses.size != count then throw "clause count mismatch"
  return ⟨clauses⟩

def main : List String → IO UInt32
  | [cnfPath, proofPath] => do
    let input ← IO.FS.readFile cnfPath
    let .ok cnf := parseDimacs input | throw (.userError "invalid DIMACS input")
    let proof ← LRAT.loadLRATProof proofPath
    if LRAT.check proof cnf then
      IO.println s!"verified {cnf.clauses.size} clauses and {proof.size} LRAT actions"
      return 0
    else
      IO.eprintln "LRAT verification failed"
      return 1
  | _ => do
    IO.eprintln "usage: lean --run K4LratCheck.lean input.cnf proof.lrat"
    return 2

#print axioms LRAT.check_sound
