"""Emit a one-step LRAT refutation if the input is unit-inconsistent."""
from pathlib import Path
import sys


def unit_refutation(clauses):
    assigned = set()
    hints = []
    while True:
        progress = False
        for index, clause in enumerate(clauses, 1):
            if any(lit in assigned for lit in clause):
                continue
            unset = [lit for lit in clause if -lit not in assigned]
            if not unset:
                return hints + [index]
            if len(unset) == 1:
                assigned.add(unset[0])
                hints.append(index)
                progress = True
        if not progress:
            raise ValueError("no unit refutation")


if __name__ == "__main__":
    cnf, proof = map(Path, sys.argv[1:])
    lines = cnf.read_text().splitlines()
    clauses = [tuple(map(int, line.split()[:-1])) for line in lines[1:]]
    hints = unit_refutation(clauses)
    proof.write_text(f"{len(clauses) + 1} 0 {' '.join(map(str, hints))} 0\n")
