#!/usr/bin/env bash
set -euo pipefail

if [[ $# -ne 2 ]]; then
  echo "usage: $0 extracted-smt-directory output-directory" >&2
  exit 2
fi

scripts="$(cd -- "$(dirname -- "$0")" && pwd)"
input="$(cd -- "$1" && pwd)"
mkdir -p -- "$2"
output="$(cd -- "$2" && pwd)"
if [[ "$input" == "$output" ]]; then
  echo "input and output directories must be distinct" >&2
  exit 2
fi
lean="${K4_LEAN:-lean}"
cadical="${K4_CADICAL:-$("$lean" --print-prefix)/bin/cadical}"
jobs="${K4_JOBS:-2}"

export K4_REPLAY_SCRIPTS="$scripts" K4_REPLAY_INPUT="$input" K4_REPLAY_OUTPUT="$output"
export K4_REPLAY_LEAN="$lean" K4_REPLAY_CADICAL="$cadical"

if [[ -f "$scripts/k4-smt.sha256" ]]; then
  (cd -- "$input" && sha256sum -c "$scripts/k4-smt.sha256")
fi

for n in {11..17}; do
  for overlap in 0 1 2; do
    printf 'k4-%s-%s\n' "$n" "$overlap"
  done
done | xargs -n 1 -P "$jobs" bash -c '
  set -euo pipefail
  stem="$1"
  source="$K4_REPLAY_OUTPUT/$stem.smt2"
  cnf="$K4_REPLAY_OUTPUT/$stem.cnf"
  proof="$K4_REPLAY_OUTPUT/$stem.lrat"
  cp -- "$K4_REPLAY_INPUT/$stem.smt2" "$source"
  python3 "$K4_REPLAY_SCRIPTS/cnf_k4.py" "$source"
  rm -f -- "$proof"
  code=0
  "$K4_REPLAY_CADICAL" --lrat "$cnf" "$proof" > "$K4_REPLAY_OUTPUT/$stem.cadical.log" || code=$?
  if [[ "$code" != 20 ]]; then
    echo "$stem: CaDiCaL exited $code (expected 20)" >&2
    exit 1
  fi
  if [[ ! -s "$proof" ]]; then
    python3 "$K4_REPLAY_SCRIPTS/unit_lrat.py" "$cnf" "$proof"
  fi
  "$K4_REPLAY_LEAN" --run "$K4_REPLAY_SCRIPTS/K4LratCheck.lean" "$cnf" "$proof" > "$K4_REPLAY_OUTPUT/$stem.check.log"
  report="$(grep "^verified " "$K4_REPLAY_OUTPUT/$stem.check.log")"
  printf "%s: %s\n" "$stem" "$report"
' _

if [[ -f "$scripts/k4-cnf.sha256" ]]; then
  (cd -- "$output" && sha256sum -c "$scripts/k4-cnf.sha256")
fi
