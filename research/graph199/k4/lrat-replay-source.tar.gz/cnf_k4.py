"""Translate the finite graph instances into DIMACS via definitional extensions."""
from functools import cache
from pathlib import Path
import re
import sys


def parse(line):
    stack = [[]]
    for token in re.findall(r"[^()\s]+|[()]", line):
        if token == "(":
            stack.append([])
        elif token == ")":
            expression = tuple(stack.pop())
            stack[-1].append(expression)
        else:
            stack[-1].append(token)
    if len(stack) != 1 or len(stack[0]) != 1:
        raise ValueError(line)
    return stack[0][0]


class CNF:
    def __init__(self):
        self.last = 1
        self.clauses = [(1,)]
        self.variables = {}

    def fresh(self):
        self.last += 1
        return self.last

    def clause(self, *literals):
        unique = tuple(dict.fromkeys(lit for lit in literals if lit != -1))
        if 1 in unique or any(-lit in unique for lit in unique):
            return
        self.clauses.append(unique)

    @cache
    def disj(self, literals):
        literals = tuple(dict.fromkeys(lit for lit in literals if lit != -1))
        if 1 in literals or any(-lit in literals for lit in literals):
            return 1
        if not literals:
            return -1
        if len(literals) == 1:
            return literals[0]
        v = self.fresh()
        for p in literals:
            self.clause(-p, v)
        self.clause(-v, *literals)
        return v

    def conj(self, literals):
        return -self.disj(tuple(-x for x in literals))

    @cache
    def threshold(self, k, literals):
        if k <= 0:
            return 1
        if k > len(literals):
            return -1
        tail, last = literals[:-1], literals[-1]
        return self.disj((self.threshold(k, tail), self.conj((last, self.threshold(k - 1, tail)))))

    @cache
    def literal(self, expr):
        if expr == "true":
            return 1
        if expr == "false":
            return -1
        if isinstance(expr, str):
            return self.variables[expr]
        op, *args = expr
        lits = tuple(self.literal(arg) for arg in args)
        if op == "not" and len(lits) == 1:
            return -lits[0]
        if op == "and":
            return self.conj(lits)
        if op == "or":
            return self.disj(lits)
        if op == "=>" and len(lits) == 2:
            return self.disj((-lits[0], lits[1]))
        if op == "=" and len(lits) == 2:
            a, b = lits
            return self.conj((self.disj((-a, b)), self.disj((a, -b))))
        if isinstance(op, tuple) and len(op) == 3 and op[0] == "_":
            k = int(op[2])
            if op[1] == "at-least":
                return self.threshold(k, lits)
            if op[1] == "at-most":
                return -self.threshold(k + 1, lits)
        raise ValueError(expr)

    def assert_expr(self, expr):
        if isinstance(expr, tuple) and expr[0] == "or":
            self.clause(*(self.literal(a) for a in expr[1:]))
        elif isinstance(expr, tuple) and expr[0] == "=>":
            self.clause(-self.literal(expr[1]), self.literal(expr[2]))
        else:
            self.clause(self.literal(expr))

    def read(self, path):
        for line in path.read_text().splitlines():
            op, *args = parse(line)
            if op == "declare-const":
                if args[1] != "Bool" or args[0] in self.variables:
                    raise ValueError(line)
                self.variables[args[0]] = self.fresh()
            elif op == "assert":
                self.assert_expr(args[0])
            elif op != "check-sat":
                raise ValueError(line)

    def write(self, path):
        with path.open("w") as stream:
            print(f"p cnf {self.last} {len(self.clauses)}", file=stream)
            for clause in self.clauses:
                print(*clause, 0, file=stream)


if __name__ == "__main__":
    for argument in sys.argv[1:]:
        source = Path(argument)
        formula = CNF()
        formula.read(source)
        target = source.with_suffix(".cnf")
        formula.write(target)
        print(f"{target}: {formula.last} variables, {len(formula.clauses)} clauses")
        formula.literal.cache_clear()
        formula.disj.cache_clear()
        formula.threshold.cache_clear()
