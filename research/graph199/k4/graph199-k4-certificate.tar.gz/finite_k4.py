"""Exact lazy SMT search for triangle-free Graph 199 structural candidates at k=4."""
import argparse
import ctypes
from itertools import combinations, permutations
import json
from pathlib import Path
import re
from time import monotonic

Z3 = ctypes.CDLL("libz3.so.4")
for name, argtypes, restype in (
    ("mk_config", [], ctypes.c_void_p),
    ("mk_context", [ctypes.c_void_p], ctypes.c_void_p),
    ("del_config", [ctypes.c_void_p], None),
    ("eval_smtlib2_string", [ctypes.c_void_p, ctypes.c_char_p], ctypes.c_char_p),
):
    function = getattr(Z3, "Z3_" + name)
    function.argtypes = argtypes
    function.restype = restype


def edge(x, y):
    return f"e{min(x, y)}_{max(x, y)}"


def conjunction(parts):
    return "(and " + " ".join(parts) + ")"


def disjunction(parts):
    return "(or " + " ".join(parts) + ")"


def neg(part):
    return f"(not {part})"


def cardinal(bound, kind, literals):
    return f"((_ at-{kind} {bound}) {' '.join(literals)})"


def lex_constraint(a, b, n):
    tail = "true"
    for other in reversed(range(n)):
        if other in (a, b):
            continue
        x, y = edge(a, other), edge(b, other)
        tail = disjunction((conjunction((neg(x), y)), conjunction((f"(= {x} {y})", tail))))
    return tail


def initial(n, overlap, symmetry=True):
    vertices = range(n)
    cycle_pairs = set(combinations(range(5), 2))
    cycle_edges = {(0, 1), (1, 2), (2, 3), (3, 4), (0, 4)}
    on_cycle = ((), (0,), (0, 2))[overlap]
    independent = on_cycle + tuple(range(5, 11 - overlap))
    outside = tuple(v for v in vertices if v not in independent)
    fixed = {pair: pair in cycle_edges for pair in cycle_pairs}
    fixed.update({pair: False for pair in combinations(independent, 2)})
    fixed = {tuple(sorted(pair)): value for pair, value in fixed.items()}
    pairs = list(combinations(vertices, 2))
    yield from (f"(declare-const {edge(a, b)} Bool)" for a, b in pairs)
    for (a, b), value in fixed.items():
        yield f"(assert {edge(a, b) if value else neg(edge(a, b))})"
    for v in vertices:
        adjacent = [edge(v, u) for u in vertices if v != u and fixed.get(tuple(sorted((v, u)))) is not False]
        yield f"(assert {cardinal(4, 'least', adjacent)})"
        yield f"(assert {cardinal(5, 'most', adjacent)})"
    for a, b, c in combinations(vertices, 3):
        triangle = ((a, b), (a, c), (b, c))
        if not any(fixed.get(pair) is False for pair in triangle):
            yield f"(assert {disjunction(neg(edge(*pair)) for pair in triangle)})"

    # A fixed independent set supplies leaves on every induced path in its complement.
    for length in (2, 3, 4):
        for path in permutations(outside, length):
            if path[0] > path[-1]:
                continue
            links = {tuple(sorted((a, b))) for a, b in zip(path, path[1:])}
            conditions = []
            for a, b in combinations(sorted(path), 2):
                required = (a, b) in links
                if (a, b) in fixed:
                    if fixed[a, b] != required:
                        break
                else:
                    conditions.append(edge(a, b) if required else neg(edge(a, b)))
            else:
                leaves = []
                for i in independent:
                    incidence = [edge(v, i) for v in path if fixed.get(tuple(sorted((v, i)))) is not False]
                    if len(incidence) == 1:
                        leaves.append(incidence[0])
                    elif len(incidence) > 1:
                        leaves.append(conjunction((cardinal(1, "least", incidence), cardinal(1, "most", incidence))))
                allowance = 6 - length
                if len(leaves) > allowance:
                    count = cardinal(allowance, "most", leaves)
                    body = f"(=> {conjunction(conditions)} {count})" if conditions else count
                    yield f"(assert {body})"

    # Lex-minimal representative under permutations of non-cycle vertices
    # within each fixed independent-set membership class.
    if symmetry:
        for group in (tuple(v for v in independent if v >= 5), tuple(v for v in outside if v >= 5)):
            for a, b in zip(group, group[1:]):
                yield f"(assert {lex_constraint(a, b, n)})"


def bits(mask):
    while mask:
        bit = mask & -mask
        yield bit.bit_length() - 1
        mask ^= bit


def tree_witnesses(adj, subsets, cap=400):
    output = []
    for mask, vertices in subsets:
        if sum((adj[v] & mask).bit_count() for v in vertices) != 12:
            continue
        seen = 1 << vertices[0]
        frontier = seen
        while frontier:
            added = 0
            for v in bits(frontier):
                added |= adj[v] & mask
            frontier = added & ~seen
            seen |= frontier
        if seen == mask:
            output.append((vertices, tuple(combinations(vertices, 2))))
            if len(output) == cap:
                break
    return output


def run(n, overlap, output, symmetry):
    config = Z3.Z3_mk_config()
    context = Z3.Z3_mk_context(config)
    Z3.Z3_del_config(config)
    start = monotonic()
    def evaluate(script):
        return Z3.Z3_eval_smtlib2_string(context, script.encode()).decode()
    def add(lines):
        script = "\n".join(lines)
        print(script, file=output, flush=True)
        error = evaluate(script)
        if error:
            raise RuntimeError(error)
    add(initial(n, overlap, symmetry))
    pairs = tuple(combinations(range(n), 2))
    allvars = " ".join(edge(*pair) for pair in pairs)
    subsets = [(sum(1 << v for v in group), group) for group in combinations(range(n), 7)]
    for count in range(1_000_000):
        verdict = evaluate("(check-sat)").strip()
        if verdict != "sat":
            print("(check-sat)", file=output, flush=True)
            print(f"{n=} {overlap=} {count=} {verdict} seconds={monotonic() - start:.2f}", flush=True)
            return verdict
        model = dict(re.findall(r"\((e\d+_\d+) (true|false)\)", evaluate(f"(get-value ({allvars}))")))
        assert len(model) == len(pairs)
        adjacency = [0] * n
        for a, b in pairs:
            if model[edge(a, b)] == "true":
                adjacency[a] |= 1 << b
                adjacency[b] |= 1 << a
        witnesses = tree_witnesses(adjacency, subsets)
        if not witnesses:
            print(f"{n=} {overlap=} {count=} candidate {json.dumps(adjacency)}", flush=True)
            return "candidate"
        add(f"(assert {disjunction(neg(edge(a, b)) if adjacency[a] & (1 << b) else edge(a, b) for a, b in edges)})"
            for _, edges in witnesses)
        if count % 100 == 0:
            print(f"{n=} {overlap=} {count=} elapsed={monotonic() - start:.2f}", flush=True)
    raise RuntimeError("Iteration cap reached")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("n", type=int)
    parser.add_argument("overlap", type=int, choices=(0, 1, 2))
    parser.add_argument("--no-symmetry", action="store_true")
    args = parser.parse_args()
    if not 11 <= args.n <= 17:
        parser.error("order must lie between 11 and 17")
    prefix = "k4-unpruned" if args.no_symmetry else "k4"
    with Path(f"{prefix}-{args.n}-{args.overlap}.smt2").open("w") as output:
        verdict = run(args.n, args.overlap, output, not args.no_symmetry)
    raise SystemExit(0 if verdict == "unsat" else 1)
