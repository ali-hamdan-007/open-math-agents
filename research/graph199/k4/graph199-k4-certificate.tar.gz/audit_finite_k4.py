"""Validate every learned obstruction as a seven-vertex tree and replay UNSAT."""
from itertools import combinations
from pathlib import Path
import re
import sys

from finite_k4 import Z3, initial


def verify_tree_clause(line, order):
    head = "(assert (or "
    if not line.startswith(head) or not line.endswith("))"):
        raise ValueError(f"not an obstruction clause: {line}")
    literals = re.findall(r"\(not e(\d+)_(\d+)\)|e(\d+)_(\d+)", line[len(head):-2])
    vertices = set()
    positive = set()
    negative = set()
    canonical_literals = []
    for nx, ny, px, py in literals:
        if nx:
            pair = (int(nx), int(ny))
            negative.add(pair)
            canonical_literals.append(f"(not e{nx}_{ny})")
        else:
            pair = (int(px), int(py))
            positive.add(pair)
            canonical_literals.append(f"e{px}_{py}")
        if not 0 <= pair[0] < pair[1] < order:
            raise ValueError(f"bad pair: {pair}")
        vertices.update(pair)
    if " ".join(canonical_literals) != line[len(head):-2]:
        raise ValueError(f"unparsed tokens in {line}")
    if len(vertices) != 7 or len(literals) != 21 or len(negative) != 6:
        raise ValueError(f"not a seven-vertex tree pattern: {line}")
    if negative & positive or positive | negative != set(combinations(sorted(vertices), 2)):
        raise ValueError(f"not a complete induced pattern: {line}")
    components = {v: v for v in vertices}
    for x, y in negative:
        old, new = components[x], components[y]
        if old == new:
            raise ValueError(f"forbidden pattern is cyclic: {line}")
        components = {v: new if value == old else value for v, value in components.items()}
    if len(set(components.values())) != 1:
        raise ValueError(f"forbidden pattern is disconnected: {line}")


def audit(path):
    n, overlap = map(int, path.stem.rsplit("-", 2)[-2:])
    symmetry = "-unpruned-" not in path.name
    lines = path.read_text().splitlines()
    prefix = list(initial(n, overlap, symmetry))
    if lines[:len(prefix)] != prefix or lines[-1] != "(check-sat)":
        raise ValueError(f"base instance or final query differs: {path}")
    clauses = lines[len(prefix):-1]
    for clause in clauses:
        verify_tree_clause(clause, n)
    cfg = Z3.Z3_mk_config()
    ctx = Z3.Z3_mk_context(cfg)
    Z3.Z3_del_config(cfg)
    result = Z3.Z3_eval_smtlib2_string(ctx, path.read_bytes()).decode().strip()
    Z3.Z3_del_context(ctx)
    if result != "unsat":
        raise ValueError(f"unexpected solver result for {path}: {result}")
    print(f"{path.name}: {len(clauses)} certified tree clauses; replay {result}")


if __name__ == "__main__":
    for name in sys.argv[1:]:
        audit(Path(name))
